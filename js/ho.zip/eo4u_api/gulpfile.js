/** Import */
let Gulp = require('gulp');
let TypeScript = require('gulp-typescript');
let Del = require('del');
let VinylPaths = require('vinyl-paths')
let Nodemon = require("gulp-nodemon");
let TaskTime = require('gulp-total-task-time');
var sourcemaps = require('gulp-sourcemaps');
const changed = require('gulp-changed');
/** Variables */
let TypeScriptProject = TypeScript.createProject('tsconfig.json');
let OutputFolder = "./dist/";
var spawn = require('child_process').spawn;
var node;
/** Log total task run time */
TaskTime.init();

Gulp.task('clean:build', function () {
    return Gulp.src(OutputFolder + "*")
        .pipe(VinylPaths(Del));
})

/** Gulp Task: Compile source code */
Gulp.task('compile', function () {
    return TypeScriptProject.src()
        .pipe(sourcemaps.init())
        .pipe(TypeScriptProject())
        .js.pipe(sourcemaps.write('.', { includeContent: false, sourceRoot: '../src' }))
        .pipe(Gulp.dest('dist'));
});

/** Gulp Task: Copy db_schema */
Gulp.task('copy:db_schema', Gulp.series("clean:build"), function () {
    return Gulp.src("./db-schema/**/*")
        .pipe(Gulp.dest(OutputFolder + "db-schema"));
})

/** Gulp Task: Watch the source change and compile */
Gulp.task('watch', function () {
    Gulp.watch("src/**/*.ts").on("change", function () {
        if (!process.env['compilingWeb'] || process.env['compilingWeb'] == 'false') {
            process.env['compilingWeb'] = true;
            var compilationResults = Gulp.src("src/**/*.ts")
                .pipe(changed("./dist"))
                .pipe(sourcemaps.init())
                .pipe(TypeScriptProject())
                .pipe(sourcemaps.write('.', { includeContent: false, sourceRoot: '../src' }))
                .pipe(Gulp.dest("./dist"))
                .on('end', function () {
                    if (process.env['compilingWeb'] == true) {
                        process.env['compilingWeb'] = false;
                        if (node) node.kill()
                        node = spawn('node', ['./dist/server.js'], { stdio: 'inherit' })
                    } else {
                        process.env['compilingWeb'] = false;
                        if (node) node.kill()
                        node = spawn('node', ['./dist/server.js'], { stdio: 'inherit' })
                    }
                });
        }
    });
});

Gulp.task('server', function () {
    if (node) node.kill()
    node = spawn('node', ['./dist/server.js'], { stdio: 'inherit' })
    node.on('close', function (code) {
        if (code === 8) {
            Gulp.log('Error detected, waiting for changes...');
        }
    });
})

/** Gulp Task: Build application */
Gulp.task('build', Gulp.series("clean:build", "compile"));

/** Gulp Task: Build application and run. Watch for ts file change */
Gulp.task("serve", Gulp.series('build', Gulp.parallel("watch", "server")))

process.on('exit', function () {
    if (node) {
        node.kill();
    }
});