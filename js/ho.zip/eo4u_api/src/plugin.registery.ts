import * as FastifyBlipp from "fastify-blipp";
import * as FastifyBoom from "fastify-boom";
import * as FastifyCors from "fastify-cors";
import * as fastifyForm from "fastify-formbody";
import * as FastifyHelmet from "fastify-helmet";
import * as FastifyMulter from "fastify-multer";
import * as FastifyRedis from "fastify-redis";
import * as FastifySwagger from "fastify-swagger";
import * as Redis from "ioredis";
import cartRoute from "./modules/cart/route/cart.route";
import eoRoute from "./modules/eo/route/eo.route";
import inventoryRoute from "./modules/inventory/route/inventory.route";
import orderRoute from "./modules/order/route/order.route";
import paymentRoute from "./modules/payment/route/payment.route";
import relativesRoute from "./modules/relatives/route/relatives.route";
import superAdminRoute from "./modules/super-admin/route/super-admin.route";
import supplierRoute from "./modules/supplier/route/supplier.route";
import userRoutes from "./modules/user/route/user.route";
import wishlistRoute from "./modules/wishlist/route/wishlist.route";
import { Env } from "./configure-environment";
const fastifyRateLimit = require("fastify-rate-limit");

export class PluginRegistery {
  public config: any;

  constructor() {
    this.config = Env.Instance.Config;
  }
  public registerPlugins(server) {
    // Custom content parser
    // server.addContentTypeParser("application/octet-stream", {parseAs: "buffer", bodyLimit: 10000000000000}, (req, body, done) => {
    //   fs.writeFileSync("mohit.jpg",body)
    //   done(null,body);
    // })

    // Predefined defined plugins
    server
      .register(FastifyBlipp)
      .register(FastifyBoom)
      .register(FastifyHelmet)
      .register(fastifyRateLimit, {max: 1000, timeWindow: "1 minute", redis: new Redis(this.config["CACHE_CONFIG"])})
      .register(FastifyMulter.contentParser)
      .register(FastifyRedis, this.config["CACHE_CONFIG"])
      .register(FastifySwagger, this.config["SWAGGER_CONFIG"])
      .register(FastifyCors)
      .register(fastifyForm)
      // User defined plugins
      .register(userRoutes) // , {prefix: "/v1"} -> prefixes are not available with fastify-plugin
      .register(supplierRoute)
      .register(relativesRoute)
      .register(wishlistRoute)
      .register(inventoryRoute)
      .register(cartRoute)
      .register(eoRoute)
      .register(paymentRoute)
      .register(superAdminRoute)
      .register(orderRoute)

      .after((err) => {
        if (err) {
          server.log.error({user: ""}, "Error in registering plugins");
          throw err;
        } else {
          server.log.info({user: ""}, "Registering of plugins completed successfully!");
        }
      })
      .ready((err) => {
        if (err) {
          server.log.error({user: ""}, "Error in Executing  plugins");
          throw err;
        } else {
          server.log.info({user: ""}, "Execution of plugins completed successfully!");
        }
      });
    const { redis } = server;
  }
}