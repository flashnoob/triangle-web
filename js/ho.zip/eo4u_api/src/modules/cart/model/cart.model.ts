export interface cartItem {
    img: string;
    unit: string;
    quantity: string;
    price: string;
    supplier: string;
    sku: string;
    productName: string;
    objectId: string;
    percentDiscount: string;
}