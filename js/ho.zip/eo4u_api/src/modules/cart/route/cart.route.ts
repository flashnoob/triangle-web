import * as fastifyPlugin from "fastify-plugin";
import { CartController } from "../controller/cart.controller";

export default fastifyPlugin(
  async (server, opts, next) => {
    const cartController = new CartController();

    /**
     * @description This route returns the user by user_id.
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       /get-cart-products/:id
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/get-cart-products/:id",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "pass the UID to retrieve the user details",
        tags: ["cart"],
        summary: "API to get user",
        params: {
          type:"object",
          required:["id"],
          properties:{
            id: {
              type: "string",
              description: "unique-id",
              minLength:20,
              maxLength:40,
            },
          }
        },
        querystring:{
          type: "object",
          required: ["currencyCode"],
          properties:{
            currencyCode:{
              type: "string",
              description: "currency code",
            }
          }
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await cartController.getCartProducts(server, request, reply);
      },
    });

    /**
     * @description This remove item from cart
     *
     * @since       1.1.0
     * @author      Devendra Gaud
     *
     * @request     PUT
     * @route       /check-sku-in-cart
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/check-sku-in-cart",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
        description: "add the product in cart",
        tags: ["cart"],
        summary: "API endpoint to  add product",
        params: {},
        body: {
          type: "object",
          required:["status", "EoName", "supplier", "size", "uid"],
          properties: {
            status: {
              type: "string",
              example:"IN_CART",
              minLength:3,
              maxLength:15
            },
            EoName: {
              type: "string",
              description:"name of essential oil",
              example:"Bergamot",
              minLength:3,
              maxLength:55
            },
            supplier: {
              type: "string",
              description:"name of supplier",
              example:"escents" ,
              minLength:3,
              maxLength:15
            },
            sku: {
              type: "string",
              description:"sku no.",
              example:"30790001",
              minLength:2,
              maxLength:10,
            },
            uid: {
              type: "string",
              description: "unique-id",
              minLength:28,
              maxLength:28,
            },
          },
        },
      } /*  */,
      handler: async (request, reply) => {
        await cartController.getSkuInCart(server, request, reply);
      },
    });

    /**
     * @description This update unit of cart-product
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       /update-unit
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/update-unit",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Update product units in cart",
        tags: ["cart"],
        summary: "API endpoint to  update units",
        params: {},
        body: {
          type: "object",
          required: ["status", "EoName", "supplier", "sku", "uid", "updatedUnits"],
          properties: {
            status: {
              type: "string",
              example: "IN_CART",
              minLength:3,
              maxLength:20,
            },
            EoName: {
              type: "string",
              description:"name of essential oil",
              example: "Bergamot",
              minLength:3,
              maxLength:200,
            },
            supplier: {
              type: "string",
              description:"name of supplier",
              example: "doTERRA",
              minLength:3,
              maxLength:100,
            },
            sku: {
              type: "string",
              description:"sku no.",
              example:"30790001",
              minLength:2,
              maxLength:50,
            },
            uid: {
              type: "string",
              description: "unique-id",
              minLength:28,
              maxLength:28,
            },
            updatedUnits: {
              type : "string",
              description: "units of product in cart",
              example:"2",
              minLength:1,
              maxLength:2
            }
          },
        },
      },
      handler: async (request, reply) => {
        await cartController.updateUnits(server, request, reply);
      }
    });

    next();
  },
  {
    fastify: "2.x",
    name: "cart-plugin",
    decorators: {
      fastify: [],
      reply: [],
    },
    dependencies: ["fastify-redis", "fastify-swagger"],
  }
);
