import * as fastify from "fastify";
import { CartService } from "../service/cart.service";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";

export class CartController {
  private cartService: CartService;

  constructor() {
    this.cartService = new CartService();
  }

  /**
   * @description Returns the cart products
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    CartController
   */

  public async getCartProducts(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_CART_PRODUCTS);
      const cartData = await this.cartService.getCartProducts(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_CART_PRODUCTS);
      return reply.send(cartData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_CART_PRODUCTS);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description create relation between user and sku
   *              for inventory and cart
   *
   * @since       1.1.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    CartController
   */

  public async getSkuInCart(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_PRODUCT);
      const userSkurelation = await this.cartService.getSkus(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_PRODUCT);
      return reply.send(userSkurelation);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_PRODUCT);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description update units of sku in cart
   *
   * @since       1.1.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    CartController
   */
  public async updateUnits(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_UNITS);
      const userSkurelation = await this.cartService.updateUnits(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_UNITS);
      return reply.send(userSkurelation);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_UNITS);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }
}


