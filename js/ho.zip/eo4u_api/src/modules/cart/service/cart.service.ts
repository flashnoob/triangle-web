import * as _ from "lodash";
import { cartItem } from "../model/cart.model";
import { Promise } from "bluebird";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { User } from "../../supplier/model/user.interface";

export class CartService {
  private commonDbService: Service.commonDbService;
  private cartDbService: Service.cartDbService;
  private redis: RedisService;

  constructor() {
    this.commonDbService = new Service.CommonDbService();
    this.cartDbService = new Service.CartDbService();
    this.redis = new RedisService();
  }

  /**
   * @description Calls the querySelector method of eo4u_core"s commonDbService.
   *              It returns the list of cart products.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    CartService
   */

  public async getCartProducts(server: any, request: any): Promise<any> {
    const id = request.params.id;
    const currencyCode = request.query.currencyCode;
    try {
      const label = "IN_CART";
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = {
        uid: id,
        currencyCode
      };
      const operation = "readCart";
      const cartItems: cartItem[] = await this.commonDbService.querySelector(operation, properties, label, userData);
      for (const item of cartItems) {
        if (item.percentDiscount) {
          const [priceCode, amount] = item.price.split(/(?=[0-9])(.+)?/);
          item.price = `${priceCode}${Math.round(Number(amount) * (1 - (Number(item.percentDiscount) / 100)))}`;
        }
      }
      return cartItems;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the getSkusInCart method of eo4u_core"s cartDbService. 
   *              Return the quantity of sku in cart
   *
   * @since       1.1.0
   * @access      public
   * @author      Devendra Gaud
   * 
   * @param       server - server instance
   * @param       request - HTTP request object
   * 
   * @returns     {Promise}
   * @memberof    CartService
   */

  public async getSkus(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const skuQty = await this.cartDbService.getSkusInCart(data, userData);
      return skuQty;
    } catch (error) {
      throw error;
    }
  }
  /**
   * @description Calls the updateUnits method of eo4u_core"s cartDbService.
   *              It update the units of product in cart.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   * 
   * @param       server - server instance
   * @param	      request - HTTP request object
   * 
   * @returns     {Promise}
   * @memberof    CartService
   */

  public async updateUnits(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.cartDbService.updateUnits(data, userData);
      return result;
    } catch (error) {
      throw error;
    }
  }
}