import * as fastify from "fastify";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";
import { PaymentService } from "../service/payment.service";
import { Stripe } from "stripe";

export class PaymentController {
  private paymentService: PaymentService;
  constructor() {
    this.paymentService = new PaymentService();
  }

  /**
   * @description Update essential oil in the database.
   *              and return the updated eo
   *
   * @since       1.1.4
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instence of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    EoController
   */

  public async createPaymentIntent(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      const data = request.body;
      server.log.info({user: request.req.user.uid}, InfoMsg.CREATE_PAYMENT_INTENT);
      const eoData = await this.paymentService.createPaymentIntent(server, request.req.user.uid, data);
      server.log.info({user: request.req.user.uid}, SuccessMsg.CREATE_PAYMENT_INTENT);
      return eoData;
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.CREATE_PAYMENT_INTENT);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);

    }
  }

  /**
   * @description call the confirmPaymentIntent of PaymentService
   *
   * @since       1.1.4
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instence of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    PaymentController
   */

  public async confirmPaymentIntent(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      const data = request.body;
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_EO);
      const eoData = await this.paymentService.confirmPaymentIntent(data);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_EO);
      return eoData;
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_EO);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);

    }
  }

  public async createSetupIntent(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      const data = request.body;
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_EO);
      const eoData: Stripe.SetupIntent = await this.paymentService.createSetupIntent(data);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_EO);
      return eoData;
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_EO);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);

    }
  }


  async getCustomerSourceList(server: any, request: any, reply: fastify.FastifyReply<any>) {
    try {
      const customerId = request.params.customerId;
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_CUSTOMER_SOURCE_LIST);
      const customerSourceList = await this.paymentService.getCustomerSourceList(server, request.req.user.uid, customerId);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_CUSTOMER_SOURCE_LIST);
      return customerSourceList;
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_CUSTOMER_SOURCE_LIST);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);

    }
  }

  public async createCustomer(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      const data = request.body;
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_CUSTOMER);
      const customerObject: Stripe.Customer = await this.paymentService.createCustomer(server, request.req.user.uid, data);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_CUSTOMER);
      return customerObject;
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_CUSTOMER);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);

    }
  }

  public async addCustomerCardSource(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      const { token, customerId } = request.body;
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_CUSTOMER_SOURCE);
      const customerSource: Stripe.CustomerSource = await this.paymentService.addCustomerCardSource(server, request.req.user.uid, token, customerId);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_CUSTOMER_SOURCE);
      return customerSource;
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_CUSTOMER_SOURCE);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  public async updateMembership(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      const data = request.body;
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_USER_MEMBERSHIP);
      const userInfo = await this.paymentService.updateMembership(server, request.req.user.uid, data);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_USER_MEMBERSHIP);
      return userInfo;
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_USER_MEMBERSHIP);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);

    }
  }

}
