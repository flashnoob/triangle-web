import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { User } from "../../supplier/model/user.interface";
export class PaymentService {
    private paymentDbService: Service.paymentDbService;
    private redis: RedisService;

    constructor() {
        this.paymentDbService = new Service.PaymentDbService();
        this.redis = new RedisService();

    }
    /**
     * @description Calls the createPaymentIntent method of eo4u_core's paymenttDbService.
     *              It returns  the payment intent  from the database.
     *
     * @since       1.1.4
     * @access      public
     * @author      Sachin Kotian
     * 
     * @param       request - request instance
     * @param 	    server  - server instance
     * @param 	    uid  -uid
     * @param 	    data -object
     * 
     * @returns     {Promise}
     * @memberof    PaymentService
     */
    public async createPaymentIntent(server: any, uid: string, data: any): Promise<any> {
        try {
            const userData: User = await this.redis.get(server, uid);
            const result = await this.paymentDbService.createPaymentIntent(
                data, userData
            );
            return result;

        } catch (error) {
            throw error;
        }
    }
    /**
     * @description Calls the createPaymentIntent method of eo4u_core's paymenttDbService.
     *              It returns  the updated essential oil from the database.
     *   
     *
     * @since       1.1.4
     * @access      public
     * @author      Sachin Kotian
     * 
     * @param       request - request instance
     * @param 	    server  - server instance
     * @param 	    data- object
     *
     * @deprecated
     * @returns     {Promise}
     * @memberof    PaymentService
     */

    public async confirmPaymentIntent(data: object): Promise<any> {
        try {
            const result = await this.paymentDbService.confirmPaymentIntent(
                data
            );
            return result;

        } catch (error) {
            throw error;
        }
    }
    /**
     * @description Calls the createSetupIntent method of eo4u_core's paymenttDbService.
     *              It returns  SetupIntent from the database.
     *
     * @since       1.1.4
     * @access      public
     * @author      Sachin Kotian
     * @deprecated 
     * @param       request - request instance
     * @param 	    server  - server instance
     * @param 	    data- object
     *
     * @returns     {Promise}
     * @memberof    PaymentService
     */

    public async createSetupIntent(data: any): Promise<any> {
        try {
            const result = await this.paymentDbService.createSetupIntent(
                data
            );
            return result;
        } catch (error) {
            throw error;
        }
    }

    /**
     * @description Calls the createCustomer method of eo4u_core's paymenttDbService.
     *              It returns  the customer object  from the database.
     *
     * @since       1.1.4
     * @access      public
     * @author      Sachin Kotian
     * 
     * @param       request - request instance
     * @param 	    server  - server instance
     *
     * @returns     {Promise}
     * @memberof    PaymentService
     */

    public async createCustomer(server: any, uid: string, data: any): Promise<any> {
        try {
            const userData: User = await this.redis.get(server, uid);
            const result = await this.paymentDbService.createCustomer(
                data, userData
            );
            return result;
        } catch (error) {
            throw error;
        }

    }
    /**
     * @description Calls the getCustomerSourceList method of eo4u_core's paymenttDbService.
     *              It returns  customer source list  from the database.
     *
     * @since       1.1.4
     * @access      public
     * @author      Sachin Kotian
     * 
     * @param       request - request instance
     * @param 	    server  - server instance
     * @param 	    {string}  -uid
     * @param 	    {string}  -customerId
     *
     * @returns     {Promise}
     * @memberof    PaymentService
     */

    public async getCustomerSourceList(server: any, uid: string, customerId: string): Promise<any> {
        try {
            const userData: User = await this.redis.get(server, uid);
            const result = await this.paymentDbService.getCustomerSourceList(
                customerId, userData
            );
            return result;
        } catch (error) {
            throw error;
        }
    }


    /**
     * @description Calls the addCustomerCardSource method of eo4u_core's paymenttDbService.
     *              It returns  customer source list  from the database.
     *
     * @since       1.1.4
     * @access      public
     * @author      Sachin Kotian
     * 
     * @param       request - request instance
     * @param 	    server  - server instance
     * @param 	    {string}  -uid
     * @param 	    {string}  -customerId
     * @param 	    {string}  -token
     *
     * @returns     {Promise}
     * @memberof    PaymentService
     */

    public async addCustomerCardSource(server: any, uid: string, token: string, customerId: string): Promise<any> {
        try {
            const userData: User = await this.redis.get(server, uid);
            const result = await this.paymentDbService.addCustomerCardSource(
                token,
                customerId, userData
            );
            return result;
        } catch (error) {
            throw error;
        }
    }

    /**
     * @description Calls the updateMembership method of eo4u_core's paymenttDbService.
     *              It returns  customer source list  from the database.
     *
     * @since       1.1.4
     * @access      public
     * @author      Sachin Kotian
     * 
     * @param       request - request instance
     * @param 	    server  - server instance
     * @param 	    {string}  -uid
     * @param 	    {string}  -customerId
     * @param 	    {string}  -token
     *
     * @returns     {Promise}
     * @memberof    PaymentService
     */

    public async updateMembership(server: any, uid: string, data: any): Promise<any> {
        try {
            const userData: User = await this.redis.get(server, uid);
            const result = await this.paymentDbService.updateMembership(
                data.uid,
                userData
            );
            this.redis.set(server, uid, result.properties);
            return result;
        } catch (error) {
            throw error;
        }
    }
}
