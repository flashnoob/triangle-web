import * as fastifyPlugin from "fastify-plugin";
import multer from "fastify-multer";
import { PaymentController } from "../controller/payment.controller";
// const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const upload = multer();

export default fastifyPlugin(
  async (server, opts, next) => {
    const paymentController = new PaymentController();
    /**
     * @description This route creates setup intent for a customer from stripe.
     *
     * @since       1.1.4
     * @author      Sachin Kotian
     *
     * @request     POST
     * @memberof    fastifyPlugin
     * @route       /create_setup_intent/
     */

    server.route({
      url: "/api/create_setup_intent",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Create setup intent for a customer from stripe.",
        summary: "API to create setup intent for a customer from stripe.",
        tags: ["payment"],
        body: {
          type: "object",
          properties: {
            userDetails: {
              type: "object",
            },
          },
        },
      },
      preHandler: upload.any(),
      handler: async (request, reply) => {
        const response = await paymentController.createSetupIntent(server, request, reply);
        return reply.send(response);
      },
    });
    /**
     * @description       This route  confirms a payment intent for a customer source in stripe api.
     *
     * @since             1.1.4
     * @author            Sachin Kotian
     * 
     * @request           POST
     * @route             /confirm_payment_intent
     * @memberof          fastifyPlugin
     */

    server.route({
      url: "/api/confirm_payment_intent",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "confirms a payment intent for a customer.",
        summary: "API to confirms a payment intent for a customer.",
        tags: ["payment"],
        body: {
          type: "object",
          properties: {
            userDetails: {
              type: "object",
            },
          },
        },
      },
      handler: async (request, reply) => {
        const response = await paymentController.confirmPaymentIntent(server, request, reply);
        return reply.send(response);
      },
    });

    /**
     * @description       This route  adds a payment source for a customer source in stripe api.
     *
     * @since             1.1.4
     * @author            Sachin Kotian
     * 
     * @request           POST
     * @route             /add_customer_source
     * @memberof          fastifyPlugin
     */
    server.route({
      url: "/api/add_customer_source",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Add payment source for a user.",
        summary: "API to Add payment source for a user",
        tags: ["payment"],
        body: {
          type: "object",
          properties: {
            properties: {
              token: { type: "string" },
              customerId: { type: "string" },

            },
          },
        },
      },
      handler: async (request, reply) => {
        const response = await paymentController.addCustomerCardSource(server, request, reply);
        return reply.send(response);
      },
    });
    /**
     * @description       This route  create a payment intent for a customer source in stripe api.
     *
     * @since             1.1.4
     * @author            Sachin Kotian
     * 
     * @request           POST
     * @route             /create_payment_intent
     * @memberof          fastifyPlugin
     */

    server.route({
      url: "/api/create_payment_intent",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Create a payment intent for a customer source.",
        summary: "API to create a payment intent for a customer source.",
        tags: ["payment"],
        body: {
          type: "object",
          properties: {
            userDetails: {
              type: "object",
            },
          },

        },
      },
      handler: async (request, reply) => {
        const response = await paymentController.createPaymentIntent(server, request, reply);
        return reply.send(response);
      },
    });

    /**
     * @description       This route  creates a customer in stripe api.
     *
     * @since             1.1.4
     * @author            Sachin Kotian
     * 
     * @request           POST
     * @route             create_customer/
     * @memberof          fastifyPlugin
     */

    server.route({
      url: "/api/create_customer",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Add a customer to stripe for payment",
        summary: "API to add a customer to stripe for payment",
        tags: ["payment"],
        body: {
          type: "object",
          properties: {
            name: { type: "string" },
            phoneNumber: { type: "string" },
            email: { type: "string" },
          },
        },
      },
      handler: async (request, reply) => {
        const response = await paymentController.createCustomer(server, request, reply);
        return reply.send(response);
      },
    });

    /**
     * @description       This route  gets payment source list of specific member in the database.
     *
     * @since             1.1.4
     * @author            Sachin Kotian
     * 
     * @request           GET
     * @route             get-customer-source-list/:customerId
     * @memberof          fastifyPlugin
     */
    server.route({
      url: "/api/get-customer-source-list/:customerId",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "Get source list(payment methods) for specific user",
        summary: "API to get source list(payment methods) for specific user",
        tags: ["payment"],
        params: {
          type: "object",
          required: ["customerId"],
          properties:{
            customerId: {
              type: "string",
              description: "customer id",
            },
          }
        },
      },
      handler: async (request, reply) => {
        const response = await paymentController.getCustomerSourceList(server, request, reply);
        return reply.send(response);
      },
    });

    /**
     * @description       This route  updates membership of a user in the database.
     *
     * @since             1.0.3
     * @author            Sachin Kotian
     * 
     * @request           POST
     * @route             update-membership/
     * @memberof          fastifyPlugin
     */
    server.route({
      url: "/api/update-membership",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "update membership  for specific user",
        summary: "API to update membership for specific user",
        tags: ["payment"],
        params: {
       customerId: {
            type: "string",
            description: "customer id",
          },
        },
      },
      handler: async (request, reply) => {
        const response = await paymentController.updateMembership(server, request, reply);
        return reply.send(response);

      },
    });

    next();
  },
  {
    fastify: "2.x",
    name: "payment-plugin",
    decorators: {
      fastify: [],
      reply: [],
    },
    dependencies: ["fastify-redis", "fastify-swagger"],
  }
);
