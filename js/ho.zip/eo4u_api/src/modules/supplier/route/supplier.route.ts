import * as fastifyPlugin from "fastify-plugin";
import * as fs from "fs";
import multer from "fastify-multer";
import { SupplierController } from "../controller/supplier.controller";
const upload = multer();

export default fastifyPlugin(async (server, opts, next) => {
  const supplierController = new SupplierController();


 /**
	 * @description This route adds Supplier with admin in the database.
	 *  
	 * @since      1.0.0
	 * @author     Sachin Kotian
	 * 
	 * @request POST
	 * @route add-supplier
	 * @memberof fastifyPlugin
	 */
  server.route({
    url: "/api/add-supplier",
    logLevel: "warn",
    method: ["POST"],
    schema: {
      description: "Add a new supplier",
      consumes: ['multipart/form-data', 'application/json'],

      summary: "API to add new supplier",
      tags: ["supplier"],
      body: {
        // type: "object",
        // properties: {
        //   role: { type: "string" },
        //   supplier_info: {
        //     type: "object",
        //     properties: {
        //       uid: { type: "string" },
        //       name: { type: "string" },
        //       contactNo: { type: "string" },
        //       birthday: { type: "string" },
        //       email: { type: "string" },
        //       address: { type: "string" },
        //       street1: { type: "string" },
        //       street2: { type: "string" },
        //       postalCode: { type: "string" },
        //       city: { type: "string" },
        //       state: { type: "string" },
        //       country: { type: "string" },
        //       inventorySource: { type: "string" },
        //       apiKey: { type: "string" },
        //       apiSecretKey: { type: "string" },
        //       storeName: { type: "string" },
        //     }
        //   }
        // }
      },
    },
    preHandler: upload.any(),
    handler: async (request, reply) => {
      if (request.files.length) {
        fs.writeFileSync(
          request.files[0]["originalname"],
          request.files[0].buffer
        );
      }

      await supplierController.addSupplier(server, request, reply);
    }
  });

    /**
     * @description This route returns list of all the users by their labels.
     *
     * @since       1.0.0
     * @author      Mohit Sharma(mhtsharma)
     *
     * @request     GET
     * @route       /get-users-image/:imageName
     * @memberof    fastifyPlugin
     */
  server.route({
    url: "/api/get-supplier-image/:imageName",
    logLevel: "warn",
    method: ["GET"],
    schema: {
      description: "get list of users on user-role",
      tags: ["supplier"],
      summary: "API to get user(s)",
      params: {
        type: "object",
        required: ["imageName"],
        properties: {
          imageName: {
            type: "string",
            description: "image-name",
            minlength: 5,
            maxlength: 50,
            value: "userName.png"
          },
        }
      },
      response: {
        201: {
          description: "Successful response",
          type: "object",
          properties: {
          },
        },
      },
      security: [
        {
          apiKey: [],
        },
      ],
    },
    handler: async (request, reply) => {
      await supplierController.getSupplierImage(server, request, reply);
    },
  });

 /**
	 * @description This route adds admin of specific supplier in the database.
	 *  
	 * @since      1.0.0
	 * @author     Sachin Kotian
	 * 
	 * @request POST
	 * @route add-admin
	 * @memberof fastifyPlugin
	 */

  server.route({
    url: "/api/add-admin",
    logLevel: "warn",
    method: ["POST"],
    schema: {
      description: "Add a new admin",
      summary: "API to add new admin of specific supplier",
      tags: ["supplier"],
      body: {
        type: "object",
        properties: {
          role: { type: "string" },
          supplier: { type: "string" },
          admin_info: {
            type: "object",
            properties: {
              fullName: { type: "string" },
              uid: { type: "string" },
              email: { type: "string" },
              userName: { type: "string" },
            }
          }
        }
      },
    },
    handler: async (request, reply) => {
      await supplierController.addAdmin(server, request, reply);
    }
  });

 /**
  * @description This route returns the admin by user_id.
  * 
  * @since      1.0.0
  * @author     Devendra
  * 
  * @request    GET 
  * @route      get-admin/
  * @memberof   fastifyPlugin
  */
  server.route({
    url: "/api/get-admin",
    logLevel: "warn",
    method: ["GET"],
    schema: {
      description: "pass the UID to retrieve the admin details",
      tags: ["supplier"],
      summary: "API to get admin",
      response: {
        201: {
          description: "Successful response",
          type: "object",
          properties: {
          }
        }
      },
      security: [
        {
          "apiKey": []
        }
      ]
    },
    // preHandler: [authorization],

    handler: async (request, reply) => {
      await supplierController.getAdmin(server, request, reply);
    }
  });

 /**
  * @description This route returns the supplier by user_id.
  * 
  * @since      1.0.0
  * @author     sachin kotian
  * 
  * @request    GET 
  * @route      get-supplier/:id
  * @memberof   fastifyPlugin
  */
  server.route({
    url: "/api/get-supplier/:id",
    logLevel: "warn",
    method: ["GET"],
    schema: {
      description: "pass the UID to retrieve the supplier details",
      tags: ["supplier"],
      summary: "API to get supplier",
      params: {
        type: "object",
        required: ["id"],
        properties: {
          id: {
            type: "string",
            description: "admin id",
            minLength: 28,
            maxLength: 28,
          }
        }
      },
      response: {
        201: {
          description: "Successful response",
          type: "object"
        }
      },
      security: [
        {
          "apiKey": []
        }
      ]
    },
    handler: async (request, reply) => {
      await supplierController.getSupplier(server, request, reply);
    }
  });

 /**
	 * @description This route to get the list of suppliers with array of admins
	 * 
	 * @since      1.0.0
	 * @author     Devendra
	 * 
	 * @request    GET 
	 * @route      get-suppliers
	 * @memberof   fastifyPlugin
	 */
  server.route({
    url: "/api/get-suppliers",
    logLevel: "warn",
    method: ["GET"],
    schema: {
      description: "pass the UID to retrieve the supplier details",
      tags: ["supplier"],
      summary: "API to get supplier",
      querystring: {
        type: "object",
        required: ["limit", "offset"],
        properties: {
          limit: {
            type: "number",
            description: "limit",
            maxLength: 2,
            minimum: 0
          },
          offset: {
            type: "number",
            description: "offset",
            minimum: 0
          },
        }
      },
      response: {
        201: {
          description: "Successful response",
          type: "object"
        }
      },
      security: [
        {
          "apiKey": []
        }
      ]
    },
    handler: async (request, reply) => {
      await supplierController.getSupplierList(server, request, reply);
    }
  });

 /**
	 * @description This route gets metadata of users	 * 
	 * @since      1.0.0
	 * @author     Devendra
	 * 
	 * @request    GET 
	 * @route      get-metadata
	 * @memberof   fastifyPlugin
	 */
  server.route({
    url: "/api/get-metadata",
    logLevel: "warn",
    method: ["GET"],
    schema: {
      description: "retrieve length of all user list",
      tags: ["supplier"],
      summary: "API to get meta data of users",
      response: {
        201: {
          description: "Successful response",
          type: "object"
        }
      },
      security: [
        {
          "apiKey": []
        }
      ]
    },
    handler: async (request, reply) => {
      await supplierController.getMetaData(server, request, reply);
    }
  });

 /**
	 * @description This route to get the list of users
	 * 
	 * @since      1.0.0
	 * @author     Devendra
	 * 
	 * @request    GET 
	 * @route      get-suppliers
	 * @memberof   fastifyPlugin
	 */
  server.route({
    url: "/api/get-userlist",
    logLevel: "warn",
    method: ["GET"],
    schema: {
      description: " retrieves all user list",
      tags: ["supplier"],
      summary: "API to get all users",
      querystring: {
        type: "object",
        required: ["limit", "offset"],
        properties: {
          limit: {
            type: "number",
            description: "limit",
            maxLength: 2,
            minimum: 0
          },
          offset: {
            type: "number",
            description: "offset",
            minimum: 0
          },
        }
      },
      response: {
        201: {
          description: "Successful response",
          type: "object"
        }
      },
      security: [
        {
          "apiKey": []
        }
      ]
    },
    handler: async (request, reply) => {
      await supplierController.getUsersList(server, request, reply);
    }
  });

 /**
	 * @description This route add the sku
	 * 
	 * @since      1.1.5
	 * @author     Devendra Gaud
	 * 
	 * @request    POST 
	 * @route      /add-sku
	 * @memberof   fastifyPlugin
	 */
  server.route({
    url: "/api/add-sku",
    logLevel: "warn",
    method: ["POST"],
    schema: {
      description: " Add the shopify skus in database and create the relation between the essential oil and supplier",
      tags: ["supplier"],
      summary: "API to add sku",
      body:{
        type:"object",
        properties:{
          storeTypeLabel:{
            type:"string",
            description: "Label related to that store",
            maxLength: 100,
            minLength:3,
            example:"SHOPIFY_SKU_NL"
          },
          productId:{
            type:"string",
            description: "Product-id",
            maxLength:50,
            minLength:1,
            example:"5323419091101"
          },
          skus:{
            type:"array",
            items:{
              type:"object",
              properties:{
                price_USD: { type:"string", description: "Sku price in US$", example:"US$200"},
                item: { type:"string", description: "Name of eo which sku is going to be add",  example:"Bergamot"},
                non_gmo: { type:"string", description: "Even Client doesn't know, how would I?", example:"NA"},
                blends_well_with: { type:"string", description: "id(s) of eo which can be blend with this sku's eo", example:"SHOPIFY_SKU_NL"},
                price_INR: { type:"string", description: "Sku price in IN₹", example:"₹100"},
                equipment: { type:"string", description: "In contains", example:"Carrying Cases"},
                duration: { type:"string", description: "Availability of sku", example:"While supplies last"},
                usda_organic_cert: { type:"string", description: "Even Client doesn't know, how would I?", example:"NA"},
                size: { type:"string", description: "Quantity of sku", example:"15 mL"},
                blend_composition: { type:"string", description: "Name of herbs can be blend", example:"Bergamot;cedarwood;clary sage;cypress"},
                price: { type:"string", description: "Sku price in CA$", example:"CA$100"},
                supplier: { type:"string", description: "Supplier Name of Sku", example:"Young Living"},
                id: { type:"string", description: "Id of sku", example:"23424"},
                sku: { type:"string", description: "Sku no of sku", example:"9333"},
                prime_per_ml: { type:"string", description: "Sku Price per ml", example:"NA"},
                promotional: { type:"string", description: "Promotional availability of sku", example:"Limited Time"},
                genus_specie: { type:"string", description: "Eo genus-specie id", example:"5"},
              }
            }
          },
          updateProductImg :{
            type:"string",
            description: "updated image src of product",
            example:"http://img.src"
          }
        }
      },
      response: {
        201: {
          description: "Successful response",
          type: "object"
        }
      },
      security: [
        {
          "apiKey": []
        }
      ]
    },
    handler: async (request, reply) => {
      await supplierController.addSku(server, request, reply);
    }
  });
  /**
   * @description This route add the discount on skus
   * 
   * @since      1.1.6
   * @author     Devendra Gaud
   * 
   * @request    PUT 
   * @route      /add-sku-discount
   * @memberof   fastifyPlugin
   */
  server.route({
    url: "/api/add-sku-discount",
    logLevel: "warn",
    method: ["PUT"],
    schema: {
      description: " retrieves all user list",
      tags: ["supplier"],
      summary: "API to get all users",
      body:{
        type:"object",
        properties:{
          supplier:{
            type:"string",
            description: "Name of supplier",
            maxLength: 100,
            minLength:3,
            example:"Young Living"
          },
          productName:{
            type:"string",
            description: "Product Name",
            maxLength:200,
            minLength:3,
            example:"Bergamot"
          },
          discount: {
          type:"string",
          maxLength:6,
          minLength:1,
          example:"15.04"
          }
        }
      },
      response: {
        201: {
          description: "Successful response",
          type: "object"
        }
      },
      security: [
        {
          "apiKey": []
        }
      ]
    },
    handler: async (request, reply) => {
      await supplierController.addDiscountOnSku(server, request, reply);
    }
  });
  next();
}, {
  fastify: "2.x",
  name: "supplier-plugin",
  decorators: {
    fastify: [],
    reply: []
  },
  dependencies: ["fastify-redis", "fastify-swagger"]
});