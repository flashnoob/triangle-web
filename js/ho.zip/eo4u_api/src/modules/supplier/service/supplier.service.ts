import * as _ from "lodash";
import * as Boom from "boom";
import * as msg from "../../../msg/index.msg";
import * as uuidv4 from "uuid/v4";
import { AdminInfo, User } from "./../model/user.interface";
import { Env } from "../../../configure-environment";
import { Promise } from "bluebird";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { UserService } from "../../user/service/user.service";
import fastify = require("fastify");

import {
  ContainerClient, newPipeline, BlobServiceClient, StorageSharedKeyCredential,
} from "@azure/storage-blob";

export class SupplierService {
  private supplierDbService: Service.SupplierDbService;
  private redis: RedisService;
  private userService: UserService
  private containerClient: ContainerClient;
  pipeline: any;
  private sharedKeyCredential: StorageSharedKeyCredential;
  blobServiceClient: any;
  config: any;

  constructor() {
    this.config = Env.Instance.Config;
    this.supplierDbService = new Service.SupplierDbService();
    this.redis = new RedisService();
    this.userService = new UserService()
    this.sharedKeyCredential = new StorageSharedKeyCredential(
      this.config.STORAGE["AZURE_STORAGE_ACCOUNT_NAME"],
      this.config.STORAGE["AZURE_STORAGE_ACCOUNT_ACCESS_KEY"]
    );
    this.pipeline = newPipeline(this.sharedKeyCredential);
    this.blobServiceClient = new BlobServiceClient(
      this.config.STORAGE["AZURE_STORAGE_URL"],
      this.pipeline
    );
    this.containerClient = this.blobServiceClient.getContainerClient(
      this.config.STORAGE["AZURE_STORAGE_USER_IMAGE_CONTAINER_NAME"]
    );
  }

  /**
   *
   * @description It adds the Supplier in database.
   *  It returns the added user from the database.
   *
   * @since    1.0.0
   * @access   public
   * @author   Sachin Kotian
   *
   * @param    server - server instance
   * @param    request - HTTP request object
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async addSupplier(server: any, request: any, blobData?: any): Promise<any> {
    const data = request.body;
    try {
      if (blobData) {
        const imageData = await this.userService.uploadImageToBlob(blobData);
      }
      const operation: string = "create";
      const supplierObject = JSON.parse(data.supplierData);
      const properties = supplierObject.supplier_info;
      const userData: User = await this.redis.get(server, request.req.user.uid);
      properties["created_at"] = new Date().toISOString();
      properties["modified_by"] = "";
      properties.storeLogo = blobData ? blobData.originalname : "TestImageFileName";
      properties["role"] = supplierObject.role;
      properties["object_id"] = uuidv4();
      const result = await this.supplierDbService.querySelector(operation, properties, supplierObject.role, userData);
      return result;
    } catch (error) {
      throw error;
    }
  }
  /**
   * @description Calls the querySelector method of eo4u_core's supplierDbService.
   * It returns the admin from the database.
   *
   * @since    1.0.0
   * @access   public
   * @author   Devendra
   *
   * @param    {Headers} headers -header from request
   * @param    server - server instance
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async getAdmin(server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = {
        uid: request.req.user.uid
      };
      const operation: string = "read";
      const result = await this.supplierDbService.querySelector(
        operation,
        properties,
        "USER_NL",
        userData
      );
      const savedUser = await this.redis.set(server, request.req.user.uid, result);
      return result;
    } catch (error) {
      throw error;
    }
  }
  /**
   * @description Calls the querySelector method of eo4u_core's supplierDbService.
   * It returns the added user from the database.
   *
   * @since    1.0.0
   * @access   public
   * @author   sachin kotian
   *
   * @param    server - server instance
   * @param    request - HTTP request object
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async addSupplierAdmin(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      const operation: string = "create";
      const properties: AdminInfo = {};
      const userData: User = await this.redis.get(server, request.req.user.uid);
      properties.firstName = data.admin_info.firstName;
      properties.lastName = data.admin_info.lastName;
      properties.email = data.admin_info.email;
      properties.supplier = data.supplier;
      properties["uid"] = data.uid;
      properties.role = "ADMIN";
      const result = await this.supplierDbService.querySelector(
        operation,
        properties,
        data.role,
        userData
      );
      return result;
    } catch (error) {
      return error;
    }
  }
  /**
   * @description Calls the querySelector method of eo4u_core's supplierDbService.
   * It returns the user from the database.
   *
   * @since    1.0.0
   * @access   public
   * @author   sachin kotian
   *
   * @param    server - server instance
   * @param    request - HTTP request object
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async getSupplier(server: any, request: any): Promise<any> {
    try {
      const operation: string = "read";
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = {
        uid: request.params.id
      };
      const result = await this.supplierDbService.querySelector(
        operation,
        properties,
        "SUPPLIER",
        userData
      );
      if (!_.isEmpty(result)) {
        return result;
      } else {
        throw Boom.forbidden(msg["ErrorMsg"]["SUPPLIER_NOT_FOUND"]);
      }
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the querySelector method of eo4u_core's supplierDbService.
   * It returns the user from the database.
   *
   * @since    1.0.0
   * @access   public
   * @author   sachin kotian
   *
   * @param    server - server instance
   * @param    request - HTTP request object
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async getSupplierList(server, request, limit: number, offset: number, currentSort: string, sortType: string, currentFilter: string): Promise<any> {
    try {
      const operation: string = "supplierList";
      if (offset === 1) {
        limit = Number.MAX_SAFE_INTEGER;
      }
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = { limit, offset, sortType, currentSort, currentFilter };

      const result = await this.supplierDbService.querySelector(
        operation,
        properties,
        "Supplier",
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the querySelector method of eo4u_core's supplierDbService.
   * It returns the admins of suppliers.
   *
   * @since    1.0.0
   * @access   public
   * @author   sachin kotian
   *
   * @param    server - server instance
   * @param    request - HTTP request object
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async getSupplierAdminList(server, request, limit: number, offset: number): Promise<any> {
    try {
      const operation: string = "supplierList";
      if (offset === 1) {
        limit = Number.MAX_SAFE_INTEGER;
        offset = 0;
      }
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = { limit, offset, sortType: "", currentSort: "", currentFilter: "" };

      const result = await this.supplierDbService.querySelector(
        operation,
        properties,
        "Supplier",
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }
  /**
   * @description Calls the querySelector method of eo4u_core's supplierDbService.
   * It returns the users list from the database.
   *
   * @since    1.0.0
   * @access   public
   * @author   sachin kotian
   *
   * @param    {number} limit - limit of number of item to get
   * @param    {number} offset - number of item to skip
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async getUsersList(server, request, limit: number, offset: number, currentSort: string, sortType: string, currentFilter: string): Promise<any> {
    try {
      if (offset === 1) {
        limit = Number.MAX_SAFE_INTEGER;
        offset = 0
      }
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const operation: string = "usersList";
      const properties = { limit, offset, sortType, currentSort, currentFilter };
      const result = await this.supplierDbService.querySelector(
        operation,
        properties,
        "Users"
        , userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }
  /**
   * @description Calls the addSku method of eo4u_core's supplierDbService.
   * 			It returns the added sku from the database.
   *
   * @since    1.1.5
   * @access   public
   * @author   Devendra Gaud
   *
   * @param 	server
   * @param 	request
   *
   * @returns  {Promise}
   * @memberof SupplierService
   */
  public async addSku(server: any, request: any): Promise<any> {
    try {
      const skus = request.body.skus;
      const label = request.body.storeTypeLabel;
      const productId = request.body.productId;
      const imgSrc = request.body.updateProductImg;
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.supplierDbService.addSku(skus, label, productId, imgSrc, userData);
      if (!_.isEmpty(result)) {
        return result;
      } else {
        throw Boom.forbidden(msg.ErrorMsg.ADD_SKU);
      }
    } catch (error) {
      throw error;
    }
  }
  /**
   * @description Calls the updateProductSupplierSkus method of eo4u_core's supplierDbService.
   * 			It returns the no. of updated skus from the database.
   *
   * @since    1.1.6
   * @access   public
   * @author   Devendra Gaud
   *
   * @param 	server
   * @param 	request
   *
   * @returns  {Promise}
   * @memberof SupplierService
   */
  public async addDiscountOnSku(server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.supplierDbService.applyDiscount(request.body.supplier, request.body.productName, request.body.discount, userData);
      if (!_.isEmpty(result)) {
        return result;
      } else {
        throw Boom.forbidden(msg.ErrorMsg.ADD_SKU);
      }
    } catch (error) {
      throw error;
    }
  }


  /**
   * @description Calls the querySelector method of eo4u_core"s commonDbService.
   *              It returns the user-image from the azure.
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       {string} imgName - name of user image
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getSupplierImage(imgName: string): Promise<any> {
    try {
      const blockBlobClient = await this.containerClient.getBlockBlobClient(
        imgName
      );
      const downloadBlockBlobResponse = await blockBlobClient.download(0);
      return downloadBlockBlobResponse["readableStreamBody"];
    } catch (error) {
      throw error;
    }
  }

}
