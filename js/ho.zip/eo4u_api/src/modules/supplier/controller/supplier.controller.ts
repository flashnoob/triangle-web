import * as fastify from "fastify";
import * as uuidv4 from "uuid/v4";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";
import { SupplierService } from "../service/supplier.service";

export class SupplierController {
  private supplierService: SupplierService;

  constructor() {
    this.supplierService = new SupplierService();
  }

  /**
   * @description Adds supplier in the database and cache.
   * and return the added node
   *
   * @since    1.0.0
   * @access   public
   * @author    Sachin Kotian
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async addSupplier(
    server: any,
    request: any,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      const imageObject = request.files[0];
      const supplierObject = JSON.parse(request.body.supplierData);
      if (imageObject) {
        imageObject.originalname = supplierObject.supplier_info.name;
      }
      server.log.info({ user: request.req.user.uid }, InfoMsg.ADD_SUPPLIER);
      const userData = await this.supplierService.addSupplier(
        server,
        request,
        request.files.length > 0 ? imageObject : undefined
      );
      server.log.info({ user: request.req.user.uid }, SuccessMsg.ADD_SUPPLIER);
      return reply.send(userData);
    } catch (error) {
      server.log.error({ user: request.req.user.uid }, ErrorMsg.ADD_SUPPLIER);
      server.log.error({ user: request.req.user.uid }, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Adds supplier admin in the database and cache.
   * and return the added node
   *
   * @since    1.0.0
   * @access   public
   * @author    Sachin Kotian
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async addAdmin(
    server: any,
    request: any,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info(
        { user: request.req.user.uid },
        InfoMsg.ADD_SUPPLIER_ADMIN
      );
      const userData = await this.supplierService.addSupplierAdmin(
        server,
        request
      );
      server.log.info(
        { user: request.req.user.uid },
        SuccessMsg.ADD_SUPPLIER_ADMIN
      );
      return reply.send(userData);
    } catch (error) {
      server.log.error(
        { user: request.req.user.uid },
        ErrorMsg.ADD_SUPPLIER_ADMIN
      );
      server.log.error({ user: request.req.user.uid }, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns the admin
   *
   * @since    1.0.0
   * @access   public
   * @author   Devendra
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async getAdmin(
    server: any,
    request: any,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info({ user: request.req.user.uid }, InfoMsg.GET_ADMIN);
      const userData = await this.supplierService.getAdmin(
        server,
        request
      );
      server.log.info({ user: request.req.user.uid }, SuccessMsg.GET_ADMIN);
      return reply.send(userData);
    } catch (error) {
      server.log.error({ user: request.req.user.uid }, ErrorMsg.GET_ADMIN);
      server.log.error({ user: request.req.user.uid }, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns the supplier
   *
   * @since    1.0.0
   * @access   public
   * @author   Sachin Kotian
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async getSupplier(
    server: any,
    request: any,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info({ user: request.req.user.uid }, InfoMsg.GET_SUPPLIER);
      const userData = await this.supplierService.getSupplier(server, request);
      server.log.info({ user: request.req.user.uid }, SuccessMsg.GET_SUPPLIER);
      return reply.send(userData);
    } catch (error) {
      server.log.error({ user: request.req.user.uid }, ErrorMsg.GET_SUPPLIER);
      server.log.error({ user: request.req.user.uid }, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns the list of supplier of with admin array
   *
   * @since    1.0.0
   * @access   public
   * @author   Devendra
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async getSupplierList(
    server: any,
    request: any,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info(
        { user: request.req.user.uid },
        InfoMsg.GET_SUPPLIER_LIST
      );
      const limit = Number(request.query.limit);
      const offset = Number(request.query.offset);
      const currentSort = String(request.query.currentSort);
      const sortType = String(request.query.sortType);
      const currentFilter = String(request.query.currentFilter);

      const userData = await this.supplierService.getSupplierList(
        server,
        request,
        limit,
        offset,
        currentSort,
        sortType,
        currentFilter
      );
      server.log.info(
        { user: request.req.user.uid },
        SuccessMsg.GET_SUPPLIER_LIST
      );
      return reply.send(userData);
    } catch (error) {
      server.log.error(
        { user: request.req.user.uid },
        ErrorMsg.GET_SUPPLIER_LIST
      );
      server.log.error({ user: request.req.user.uid }, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns the metadata of users
   *
   * @since    1.0.0
   * @access   public
   * @author   Devendra
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async getMetaData(
    server: any,
    request: any,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info({ user: request.req.user.uid }, InfoMsg.GET_META_DATA);
      const limit = 0;
      const offset = 1;
      const supplierData = await this.supplierService.getSupplierAdminList(
        server,
        request,
        limit,
        offset
      );
      const supplierNameList = Array.from(
        new Set(supplierData.map((a) => a.supplier))
      );

      const userData = await this.supplierService.getUsersList(
        server,
        request,
        limit,
        offset,
        "",
        "",
        ""
      );
      server.log.info({ user: request.req.user.uid }, SuccessMsg.GET_META_DATA);
      return reply.send({
        userCount: userData.length,
        supplierCount: supplierData.length,
        supplierNameList,
      });
    } catch (error) {
      server.log.error({ user: request.req.user.uid }, ErrorMsg.GET_META_DATA);
      server.log.error({ user: request.req.user.uid }, error.message);
      return reply.send(error);
    }
  }
  /**
   * @description Returns the list of all users
   * @since    1.0.0
   * @access   public
   * @author   Devendra
   *
   * @param    {fastify.FastifyInstance} server    Instence of fastify server.
   * @param    {fastify.FastifyRequest}  request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async getUsersList(
    server: any,
    request: fastify.FastifyRequest,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info({ user: request.req["user"].uid }, InfoMsg.GET_USER_LIST);
      const offset = Number(request.query.offset);
      const currentSort = String(request.query.currentSort);
      const currentFilter = String(request.query.currentFilter);
      const sortType = String(request.query.sortType);
      const limit = Number(request.query.limit);
      const userData = await this.supplierService.getUsersList(
        server,
        request,
        limit,
        offset,
        currentSort,
        sortType,
        currentFilter
      );
      server.log.info(
        { user: request.req["user"].uid },
        SuccessMsg.GET_USER_LIST
      );
      return reply
        .send(userData);
    } catch (error) {
      server.log.error(
        { user: request.req["user"].uid },
        ErrorMsg.GET_USER_LIST
      );
      server.log.error({ user: request.req["user"].uid }, error.message);
      return reply.send(error);
    }
  }
  /**
   * @description Returns the added SKU.
   * @since    1.1.5
   * @access   public
   * @author   Devendra Gaud
   *
   * @param    {fastify.FastifyInstance} server    Instence of fastify server.
   * @param    {fastify.FastifyRequest}  request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async addSku(
    server: any,
    request: fastify.FastifyRequest,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info({ user: request.req["user"].uid }, InfoMsg.ADD_SKU);
      const addedSku = await this.supplierService.addSku(server, request);
      server.log.info({ user: request.req["user"].uid }, SuccessMsg.ADD_SKU);
      return reply.send(addedSku);
    } catch (error) {
      server.log.error({ user: request.req["user"].uid }, ErrorMsg.ADD_SKU);
      server.log.error({ user: request.req["user"].uid }, error.message);
      return reply.send(error);
    }
  }
  /**
   * @description Return the no. of updated Skus
   * @since    1.1.6
   * @access   public
   * @author   Devendra Gaud
   *
   * @param    {fastify.FastifyInstance} server    Instence of fastify server.
   * @param    {fastify.FastifyRequest}  request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SupplierController
   */

  public async addDiscountOnSku(
    server: any,
    request: fastify.FastifyRequest,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info(
        { user: request.req["user"].uid },
        InfoMsg.ADD_SKU_DISCOUNT
      );
      const addedSku = await this.supplierService.addDiscountOnSku(
        server,
        request
      );
      server.log.info(
        { user: request.req["user"].uid },
        SuccessMsg.ADD_SKU_DISCOUNT
      );
      return reply.send(addedSku);
    } catch (error) {
      server.log.error(
        { user: request.req["user"].uid },
        ErrorMsg.ADD_SKU_DISCOUNT
      );
      server.log.error({ user: request.req["user"].uid }, error.message);
      return reply.send(error);
    }
  }

  public async getSupplierImage(
    server: any,
    request: any,
    reply: fastify.FastifyReply<any>
  ): Promise<any> {
    try {
      server.log.info({ user: "" }, InfoMsg.GET_USER_IMAGE);
      const userData = await this.supplierService.getSupplierImage(
        request.params.imageName
      );
      server.log.info({ user: "" }, SuccessMsg.GET_USER_IMAGE);
      return reply.send(userData);
    } catch (error) {
      server.log.error({ user: "" }, ErrorMsg.GET_USER_IMAGE);
      server.log.error({ user: "" }, error.message);
      return reply.send(error);
    }
  }
}
