import * as fastifyPlugin from "fastify-plugin";
import { WishlistController } from "../controller/wishlist.controller";

export default fastifyPlugin(
  async (server, opts, next) => {
    const wishlistController = new WishlistController();

    /**
     * @description       This route  adds wishlist of specific member in the database.
     *
     * @since             1.0.2
     * @author            Sachin Kotian
     *
     * @version           1.0.2
     * @request           POST
     * @route             add-wishlist/
     * @memberof          fastifyPlugin
     */
    server.route({
      url: "/api/add-wishlist",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Add a wishlist product for specific user",
        summary: "API to add wishlist",
        tags: ["wishlist"],
        body: {
          type: "object",
          properties: {
            productId: { type: "string" },
            userId: { type: "string" },
          },
        },
      },
      handler: async (request, reply) => {
        await wishlistController.addWishList(server, request, reply);
      },
    });

    /**
     * @description       This route  removes wishlist of specific member in the database.
     *
     * @since             1.0.2
     * @author            Sachin Kotian
     *
     * @request           PUT
     * @route             remove-wishlist/
     * @memberof          fastifyPlugin
     */
    server.route({
      url: "/api/remove-wishlist",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
        description: "Remove a wishlist product for specific user",
        summary: "API to remove wishlist",
        tags: ["wishlist"],
        body: {
          type: "object",
          properties: {
            productId: { type: "string" },
            userId: { type: "string" },
          },
        },
      },
      handler: async (request, reply) => {
        await wishlistController.removeWishList(server, request, reply);
      },
    });

    /**
     * @description       This route  gets wishlist of specific member in the database.
     *
     * @since             1.0.2
     * @author            Sachin Kotian
     * 
     * @request           GET
     * @route             get-wishlist/
     * @memberof          fastifyPlugin
     */
    server.route({
      url: "/api/get-wishlist",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "get product wishlist for specific user",
        summary: "API to get wishlist",
        tags: ["wishlist"],
        querystring: {
          type: "object",
          required: ["userId"],
          properties: {
            userId: {
              type: "string",
              description: "uid of member",
              minLength:28,
              maxLength:28,
            }
          }
        },
      },
      handler: async (request, reply) => {
        await wishlistController.getWishList(server, request, reply);
      },
    });

    next();
  },
  {
    fastify: "2.x",
    name: "user-plugin",
    decorators: {
      fastify: [],
      reply: [],
    },
    dependencies: ["fastify-redis", "fastify-swagger"],
  }
);