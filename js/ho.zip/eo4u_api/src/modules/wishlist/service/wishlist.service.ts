import * as _ from "lodash";
import * as Boom from "boom";
import * as msg from "../../../msg/index.msg";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { User } from "modules/supplier/model/user.interface";

export class WishlistService {
  private commonDbService: Service.commonDbService;
  private redis: RedisService;
  private wishlistService: Service.wishlistDbService;
  constructor() {
    this.commonDbService = new Service.CommonDbService();
    this.wishlistService = new Service.WishlistDbService();
    this.redis = new RedisService();
  }

  /**
   * @description Calls the addWishlist method of eo4u_core"s wishlistService.
   *              It adds wishlist to the database.
   *
   * @since       1.0.2
   * @access      public
   * @author      Sachin kotian
   *
   * @param       server - server instance
   * @param	      {bodyData} object- HTTP request object
   *
   * @returns     {Promise}
   * @memberof    WishlistService
   */

  public async addWishList(server: any, request: any, bodyData: any): Promise<any> {
    const { userId, productId } = bodyData;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.wishlistService.addWishlist(userId, productId, userData);
      return result;
    } catch (error) {
      throw error;
    }
  }


  /**
   * @description Calls the removeWishlist method of eo4u_core"s wishlistService.
   *              It remove wishlist from the database.
   *
   * @since       1.0.2
   * @access      public
   * @author      Sachin kotian
   *
   * @param       server - server instance
   * @param	      {bodyData} object- HTTP request object
   *
   * @returns     {Promise}
   * @memberof    WishlistService
   */

  public async removeWishList(server: any, request: any, paramsData: any): Promise<any> {
    const { userId, productId } = paramsData;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.wishlistService.removeWishlist(
        userId,
        productId, userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the getWishList method of eo4u_core"s wishlistService.
   *              It returns wishlist eos from the database.
   *
   * @since       1.0.2
   * @access      public
   * @author      Sachin kotian
   *
   * @param       server - server instance
   * @param	      {bodyData} object- HTTP request object
   *
   * @returns     {Promise}
   * @memberof    WishlistService
   */

  public async getWishList(server: any, request:any, userId: string): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.wishlistService.getWishList(userId, userData);
      return result;
    } catch (error) {
      throw error;
    }
  }

}
