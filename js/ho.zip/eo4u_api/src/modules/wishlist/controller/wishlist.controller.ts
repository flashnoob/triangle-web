import * as fastify from "fastify";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";
import { WishlistService } from "../service/wishlist.service";

export class WishlistController {
  private wishlistService: WishlistService;

  constructor() {
    this.wishlistService = new WishlistService();
  }

  /**
   * @description Adds relation between user and eo in the database and return the user
   *
   * @since       1.0.2
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    WishlistController
   */

  public async addWishList(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_WISHLIST);
      const bodyData = request.body;
      const userData = await this.wishlistService.addWishList(server, request, bodyData);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_WISHLIST);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_WISHLIST);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Remove relation between user and wishlisted eo in the database.
   *
   * @since       1.0.2
   * @access      public
   * @author      Sachin Kotian
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    WishlistController
   */

  public async removeWishList(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.REMOVE_WISHLIST);
      const paramsObject = request.body;
      const userData = await this.wishlistService.removeWishList(server, request, paramsObject);
      server.log.info({user: request.req.user.uid}, SuccessMsg.REMOVE_WISHLIST);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.REMOVE_WISHLIST);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Get wishlisted eo list from database
   *
   * @since       1.0.2
   * @access      public
   * @author      Sachin Kotian
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    WishlistController
   */

  public async getWishList(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_WISHLIST);
      const paramsObject = request.query.userId;
      const userData = await this.wishlistService.getWishList(server, request, paramsObject);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_WISHLIST);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_WISHLIST);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }
}