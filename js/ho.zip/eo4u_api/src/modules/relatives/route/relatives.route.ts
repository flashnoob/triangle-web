import * as fastifyPlugin from "fastify-plugin";
import { RelativesController } from "../controller/relatives.controller";

export default fastifyPlugin(
  async (server, opts, next) => {
    const relativesController = new RelativesController();

    /**
     * @description This route adds relative in the database
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       add-forf
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/add-forf",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Add a new member",
        summary: "API to add new friend or family",
        tags: ["relative"],
        body: {
          type: "object",
          required: ["label", "user_info"],
          properties: {
            label: { type: "string", example: "FOF" },
            user_info: {
              type: "object",
              required: ["relation", "firstName"],
              properties: {
                relation: {type: "string", example: "Daughter"},
                firstName: {type: "string", example: "Nancy"},
                lastName: {type: "string", example: "Cooper"},
                phone: {type: "string", example: "9782728866"},
                birthday: {type: "string", example: "04-09-1995"},
                email: {type: "string", example: "ncooper@eo4u.ca"},
                street1: {type: "string", example: "10/32, Block A"},
                street2: {type: "string", example: "Henery Street"},
                zip: {type: "string", example: "26451"},
                city: {type: "string", example: "Toronto"},
                state: {type: "string", example: "temp"},
                healthStatus: {type: "string", example: "11a;11c"},
              },
            },
          },
        },
      },
      handler: async (request, reply) => {
        await relativesController.addRelative(server, request, reply);
      },
    });


    /**
     * @description This route returns relatives array of user
     *
     * @since       1.0.0
     * @author      Mohit Sharma(mhtsharma)
     *
     * @request     GET
     * @route       /get-relatives/:uid
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/get-relatives/:uid",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "It takes UID of logged-in user and returns list of all the relatives.",
        tags: ["relative"],
        summary: "Returns list of all the relatives of current user.",
        params: {
          type: "object",
          required: ["uid"],
          properties:{
            uid: {
              type: "string",
              description: "user's uid",
              minLength:28,
              maxLength:28,
            },
          }
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await relativesController.getRelativeList(server, request, reply);
      },
    });


    /**
     * @description   This route updates relative details.
     *
     * @since         1.0.2
     * @author        Devendra Gaud
     *
     * @request       PUT
     * @route         update-relative/
     * @memberof      fastifyPlugin
     */

    server.route({
      url: "/api/update-relative",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
        description: "Update a relative",
        summary: "API to update friend or family",
        tags: ["relative"],
        body: {
          type: "object",
          required: ["relation", "firstName", "object_id"],
          properties: {
            relation: {type: "string", example: "Daughter"},
            firstName: {type: "string", example: "Nancy"},
            lastName: {type: "string", example: "Cooper"},
            phone: {type: "string", example: "9782728866"},
            birthday: {type: "string", example: "04-09-1995"},
            email: {type: "string", example: "ncooper@eo4u.ca"},
            street1: {type: "string", example: "10/32, Block A"},
            street2: {type: "string", example: "Henery Street"},
            zip: {type: "string", example: "26451"},
            city: {type: "string", example: "Toronto"},
            state: {type: "string", example: "temp"},
            healthStatus: {type: "string", example: "11a;11c"},
            object_id: { type: "string", example:"9d30a212-bb26-4432-9ead-df5bcf00820c"},
          },
        },
      },
      handler: async (request, reply) => {
        await relativesController.updateFamilyMember(server, request, reply);
      },
    });

    /**
     * @description   This route remove the relative of passed object-id.
     *
     * @since         1.0.2
     * @author        Devendra Gaud
     *
     * @version       1.0.2
     * @request       PUT
     * @route         remove-relative/:objectId
     * @memberof      fastifyPlugin
     */

    server.route({
      url: "/api/remove-relative/:objectId",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "Removes the Relative.",
        tags: ["relative"],
        summary: "API endpoint to delete a relative",
        params: {
          type: "object",
          required: ["objectId"],
          properties:{
            objectId: {
              type: "string",
              description: "object-id of relative",
              minLength:36,
              maxLength:36,
              value:"9d30a212-bb26-4432-9ead-df5bcf00820c"
            },
          }
        },
      },
      handler: async (request, reply) => {
        await relativesController.removeUserRelation(server, request, reply);
      },
    });


    next();
  },
  {
    fastify: "2.x",
    name: "relatives-plugin",
    decorators: {
      fastify: [],
      reply: [],
    },
    dependencies: ["fastify-redis", "fastify-swagger"],
  }
);
