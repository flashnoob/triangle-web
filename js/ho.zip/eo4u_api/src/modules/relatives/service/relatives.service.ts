import * as _ from "lodash";
import * as msg from "../../../msg/index.msg";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { User } from "/modules/supplier/model/user.interface";
import { v4 } from "uuid";

export class RelativesService {
  private commonDbService: Service.commonDbService;
  private redis: RedisService;
  private relativeDbService: Service.realtiveDbService;
  constructor() {
    this.commonDbService = new Service.CommonDbService();
    this.relativeDbService = new Service.RelativeDbService();
    this.redis = new RedisService();
  }

  /**
   *
   * @description It adds the relatives in database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       server
   * @param       request
   *
   * @returns     {Promise}
   * @memberof    UserService
   */
  public async addRelative(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = data.user_info;
      const label = data.role ? data.role : data.label;
      properties["created_by"] = properties["created_by"]
        ? properties["created_by"]
        : data.user_info.uid;
      properties["created_at"] = new Date().toISOString();
      properties["modified_by"] = "";
      properties["modified_at"] = "";
      properties.role = "RELATIVE";
      properties["object_id"] = v4();
      const result = await this.relativeDbService.addRelative(
        properties,
        label,
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the getRelatives method of eo4u_core"s relativeDbService.
   *              It returns relatives of user from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       {string} label - label of user-relative
   * @param 	    {string} uid 	- user-id
   * @param  	    server 		- server instance
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getRelatives(
    label: string,
    uid: string,
    server: any
  ): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, uid);
      const properties = {
        uid,
      };
      const result = await this.relativeDbService.getRelatives(
        properties,
        label,
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the updateRelative method of eo4u_core"s relativeDbService.
   *              It returns updated relative details from the database.
   *
   * @since       1.0.2
   * @access      public
   * @author      Sachin kotian
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async updateRelative(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      if (data) {
        const userData: User = await this.redis.get(
          server,
          request.req.user.uid
        );
        const properties = data;
        properties["modified_by"] = properties["modified_by"]
          ? properties["modified_by"]
          : "By User";
        properties["modified_at"] = new Date().toISOString();
        const result = await this.relativeDbService.updateRelative(
          properties,
          userData
        );
        return result;
      }
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the deleteRelative method of eo4u_core"s relativeDbService.
   *              Remove the relative.
   *
   * @since       1.0.2
   * @access      public
   * @author      Sachin kotian
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async deleteRelation(
    server: any,
    request: any,
    id: any
  ): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.relativeDbService.deleteRelative(
        { object_id: id },
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }
}
