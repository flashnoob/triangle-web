import * as fastify from "fastify";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";
import { RelativesService } from "../service/relatives.service";

export class RelativesController {
  private relativesService: RelativesService;

  constructor() {
    this.relativesService = new RelativesService();
  }

  /**
   * @description Adds relative in the database and cache, and return the added node
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    RelativesController
   */
  public async addRelative(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_RELATIVE);
      const userData = await this.relativesService.addRelative(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_RELATIVE);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_RELATIVE);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns list of all the relatives.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    RelativesController
   */
  public async getRelativeList(server: any,request: any,reply: fastify.FastifyReply<any>):Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_RELATIVE_LIST);
      const userList = await this.relativesService.getRelatives("FOF", request.params.uid, server);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_RELATIVE_LIST);
      return reply.send(userList);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_RELATIVE_LIST);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description update relative details and return the updated relative details.
   *
   * @since       1.0.2
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       request   HTTP request object
   * @param       server    Instance of fastify server.
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    RelativesController
   */

  public async updateFamilyMember(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_FAMILY_MEMBER);
      const userData = await this.relativesService.updateRelative(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_FAMILY_MEMBER);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_FAMILY_MEMBER);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Remove relative and return the details of that relative
   *
   * @since       1.0.2
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    RelativesController
   */

  public async removeUserRelation(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.REMOVE_RELATION);
      const objectId = request.params.objectId;
      const userData = await this.relativesService.deleteRelation(server,request, objectId);
      server.log.info({user: request.req.user.uid}, SuccessMsg.REMOVE_RELATION);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.REMOVE_RELATION);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }
}