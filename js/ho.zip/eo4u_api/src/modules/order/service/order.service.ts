import { HttpClientHelper } from "../../../services/http-client-helper";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { User } from "../../supplier/model/user.interface";

export class OrderService {
    private _orderDbservice: Service.orderDbservice;
    private _redis: RedisService;
    private _httpHelper: HttpClientHelper;

    constructor() {
        this._orderDbservice = new Service.OrderDbService();
        this._redis = new RedisService();
        this._httpHelper = new HttpClientHelper();

    }

    /**
     * @description Calls the getOrders method of eo4u_core's orderDbService.
     *              It returns the orders for specific user.
     *
     * @since       1.2.4
     * @access      public
     * @author      Devendra Gaud
     * 
     * @param       request - request instance
     * @param 	    server  - server instance
     * 
     * @returns     {Promise}
     * @memberof    PaymentService
     */
    public async getOrders(server:any, request: any): Promise<any> {
        try {
            const userData: User = await this._redis.get(server, request.req.user.uid);
            const {limit, offset} = request.query;
            const result = await this._orderDbservice.getOrders(limit, offset, userData);
            return result;
        } catch (error) {
            throw error;
        }
    }

  /**
   * @description Sends the request to the connector to place order and update the product status to placed-order
   *
   * @since       1.2.4
   * @access      public
   * @author      Devendra Gaud
   * 
   * @param       server - server instance
   * @param	      request - HTTP request object
   * 
   * @returns     {Promise}
   * @memberof    OrderService
   */
    public async placeOrder(server:any, request: any): Promise<any> {
        try {
            const userData: User = await this._redis.get(server, request.req.user.uid);
            let orderedProducts = [...request.body.lineItems];
            const woocomLineItems = request.body.lineItems.filter((product) => product.supplier === "Woocommerce");
            request.body.lineItems = woocomLineItems;
            let woocomSkus;
            if (woocomLineItems.length > 0) {
                const authorizationKey = { "authorization" : request.headers["authorization"]};
                try {
                    let woocomResult = await this._httpHelper.requestConnector("POST", `place-order?supplierId=${request.query.supplierId}`, authorizationKey, request.body);
                    woocomResult = JSON.parse(woocomResult);
                    if (woocomResult.error) {
                        throw woocomResult;
                    } else {
                        woocomSkus = woocomResult;
                    }

                } catch (error) {
                    throw error;
                }
            }
            orderedProducts = orderedProducts.map(eo => {
                if (eo.supplier === "Woocommerce") {
                     eo["orderId"] = woocomSkus.id;
                }
                return eo;
            });

            const orderDetails  = {
                lineItems: orderedProducts,
                shippingTo: request.body.shipping,
                orderedAt:new Date().toISOString()
                };
            const result = await this._orderDbservice.placeOrder(orderDetails, userData);
            return {result, id:woocomSkus.id};

        } catch (error) {
            throw error;
        }
    }

  /**
   * @description update the status of placed order in db and provider's inventory
   *
   * @since       1.2.5
   * @access      public
   * @author      Devendra Gaud
   * 
   * @param       server - server instance
   * @param	      request - HTTP request object
   * 
   * @returns     {Promise}
   * @memberof    OrderService
   */
    public async updateOrderStatus(server:any, request:any):Promise<any> {
        try {
            const userData: User = await this._redis.get(server, request.req.user.uid);
            const {orderId} = request.query;
            const result = await this._orderDbservice.updateOrder(orderId, userData);
            try {
                const authorizationKey = { "authorization" : request.headers["authorization"]};
                let woocomResult = await this._httpHelper.requestConnector("PUT", `update-order?supplierId=${request.query.supplierId}&orderId=${request.query.orderId}`, authorizationKey, request.body);
                woocomResult = JSON.parse(woocomResult);
                if (woocomResult.error) {
                    throw woocomResult;
                }
                return { result, woocomResult};
            } catch (error) {
                throw error;
            }
            // return result;
        } catch (error) {
            throw error;
        }
    }

}