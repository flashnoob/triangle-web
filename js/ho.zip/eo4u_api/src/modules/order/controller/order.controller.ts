import * as fastify from "fastify";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";
import { OrderService } from "../service/order.service";

export class OrderController {
    private _orderService: OrderService ;

    constructor() {
      this._orderService = new OrderService();
    }
    /**
     * @description Log the request and response and call getOrders() in order-service
     *
     * @since       1.2.4
     * @access      public
     * @author      Devendra Gaud
     *
     * @param       server    Instance of fastify server.
     * @param       request   HTTP request object
     * @param       {fastify.FastifyReply}      reply     HTTP reply onject
     * 
     * @returns     {Promise}
     * @memberof    OrderController
     */
    public async getOrders(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({user: request.req.user.uid}, InfoMsg.PLACE_ORDER);
            const placedOrder = await this._orderService.getOrders(server, request);
            server.log.info({user: request.req.user.uid}, SuccessMsg.PLACE_ORDER);
            return reply.send(placedOrder);
        } catch (error) {
            server.log.error({user: request.req.user.uid}, ErrorMsg.PLACE_ORDER);
            server.log.error({user: request.req.user.uid}, error.message);
            return reply.send(error);
        }
    }

    /**
     * @description Log the request and response ; call placeOrder() in order-service
     *
     * @since       1.2.4
     * @access      public
     * @author      Devendra Gaud
     *
     * @param       server    Instance of fastify server.
     * @param       request   HTTP request object
     * @param       {fastify.FastifyReply}      reply     HTTP reply onject
     * 
     * @returns     {Promise}
     * @memberof    OrderController
     */
    public async placeOrder(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({user: request.req.user.uid}, InfoMsg.PLACE_ORDER);
            const placedOrder = await this._orderService.placeOrder(server, request);
            server.log.info({user: request.req.user.uid}, SuccessMsg.PLACE_ORDER);
            return reply.send(placedOrder);
        } catch (error) {
            server.log.error({user: request.req.user.uid}, ErrorMsg.PLACE_ORDER);
            server.log.error({user: request.req.user.uid}, error.message);
            return reply.send(error);
        }
    }

    /**
     * @description Log the request and response; call updateOrderStatus() in order-service
     *
     * @since       1.2.5
     * @access      public
     * @author      Devendra Gaud
     *
     * @param       server    Instance of fastify server.
     * @param       request   HTTP request object
     * @param       {fastify.FastifyReply}      reply     HTTP reply onject
     * 
     * @returns     {Promise}
     * @memberof    OrderController
     */
    public async updateOrder(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_ORDER_STATUS);
            const placedOrder = await this._orderService.updateOrderStatus(server, request);
            server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_ORDER_STATUS);
            return reply.send(placedOrder);
        } catch (error) {
            server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_ORDER_STATUS);
            server.log.error({user: request.req.user.uid}, error.message);
            return reply.send(error);
        }
    }
}