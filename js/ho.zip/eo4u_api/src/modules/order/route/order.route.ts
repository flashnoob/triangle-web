import * as fastifyPlugin from "fastify-plugin";
import { OrderController } from "../controller/order.controller";

export default fastifyPlugin(
  async (server, opts, next) => {
    const orderController = new OrderController();

    /**
     * @description Endpoint to get orders
     *
     * @since       1.2.4
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       /orders
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/orders",
      logLevel: "warn",
      method: ["GET"],
      schema: {
          description: "Place the order",
          tags: ["Order"],
          summary: "API to place the order",
          querystring: {
            type: "object",
            properties: {
              limit: {
                type: "number",
                description: "limit",
                maxLength:3,
                minimum:0,
                value:10
              },
              offset: {
                type: "number",
                description: "offset",
                minimum:0,
                value:0
              },
            }
          },
          security: [
              {
                  "apiKey": []
              }
          ]
      },
      handler: async (request, reply) => {
          await orderController.getOrders(server, request, reply);
      }
  });

    /**
     * @description Endpoint to place order
     *
     * @since       1.2.4
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       /place-order
     * @memberof    fastifyPlugin
     */
    server.route({
        url: "/api/place-order",
        logLevel: "warn",
        method: ["POST"],
        schema: {
            description: "Place the order",
            tags: ["Order"],
            summary: "API to place the order",
            security: [
                {
                    "apiKey": []
                }
            ]
        },
        handler: async (request, reply) => {
            await orderController.placeOrder(server, request, reply);
        }
    });

    /**
     * @description Endpoint to update order status
     *
     * @since       1.2.4
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       /update-order
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/update-order",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
          description: "Update the order status",
          tags: ["Order"],
          summary: "API to update the status of placed order",
          querystring:{
            type: "object",
            properties: {
              orderId: {
                type: "string",
                description: "id of placed order",
                value:10
              },
              supplierId: {
                type: "string",
                description: "supplier",
                value:"Nascents"
              }
            }
          },
          security: [
              {
                  "apiKey": []
              }
          ]
      },
      handler: async (request, reply) => {
          await orderController.updateOrder(server, request, reply);
      }
  });

    next();
  },
  {
    fastify: "2.x",
    name: "order-plugin",
    decorators: {
      fastify: [],
      reply: [],
    },
    dependencies: ["fastify-redis", "fastify-swagger"],
  }
);