import * as fastify from "fastify";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";
import { SuperAdminService } from "../service/super-admin.service";
export class SuperAdminController {
    private superAdminService: SuperAdminService;

    constructor() {
        this.superAdminService = new SuperAdminService();
    }

    /**
     * @description Update the user in the database and cache
     * and return the updated user
     *
     * @since    1.1.4
     * @access   public
     * @author   Devendra Gaud
     *
     * @param    server    Instence of fastify server.
     * @param    request   HTTP request object
     * @param    {fastify.FastifyReply}      reply     HTTP reply onject
     * @returns  {Promise}
     * @memberof SuperAdminController
     */
    public async updateUser(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({ user: request.req.user.uid }, InfoMsg.UPDATE_USER_BY_UID);
            const userData = await this.superAdminService.updateUser(server, request);
            server.log.info({ user: request.req.user.uid }, SuccessMsg.UPDATE_USER_BY_UID);
            return reply.send(userData);
        } catch (error) {
            server.log.error({ user: request.req.user.uid }, ErrorMsg.UPDATE_USER_BY_UID);
            server.log.error({ user: request.req.user.uid }, error.message);
            return reply.send(error);
        }
    }

    /**
     * @description Disable the user in firebase and flag the user in the database and cache.
     * and return the updated user
     *
     * @since    1.1.4
     * @access   public
     * @author   Devendra Gaud
     *
     * @param    server    Instence of fastify server.
     * @param    request   HTTP request object
     * @param    {fastify.FastifyReply}      reply     HTTP reply onject
     * @returns  {Promise}
     * @memberof SuperAdminController
     */
    public async disableUser(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({ user: request.req.user.uid }, InfoMsg.DISABLE_USER_BY_UID);
            const userData = await this.superAdminService.disableUser(server, request);
            server.log.info({ user: request.req.user.uid }, SuccessMsg.DISABLE_USER_BY_UID);
            return reply.send(userData);
        } catch (error) {
            server.log.error({ user: request.req.user.uid }, ErrorMsg.DISABLE_USER_BY_UID);
            server.log.error({ user: request.req.user.uid }, error.message);
            return reply.send(error);
        }
    }

    /**
     * @description Remove the user from firebase and flag the user in the database and cache.
     * and return the updated user
     *
     * @since    1.1.4
     * @access   public
     * @author   Devendra Gaud
     * @param    server    Instence of fastify server.
     *
     * @param    request   HTTP request object
     * @param    {fastify.FastifyReply}      reply     HTTP reply onject
     * @returns  {Promise}
     * @memberof SuperAdminController
     */

    public async removeUser(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({ user: request.req.user.uid }, InfoMsg.REMOVE_USER_BY_UID);
            const userData = await this.superAdminService.removeUser(server, request);
            server.log.info({ user: request.req.user.uid }, SuccessMsg.REMOVE_USER_BY_UID);
            return reply.send(userData);
        } catch (error) {
            server.log.error({ user: request.req.user.uid }, ErrorMsg.REMOVE_USER_BY_UID);
            server.log.error({ user: request.req.user.uid }, error.message);
            return reply.send(error);
        }
    }


    /**
     * @description Get the server logs in response
     *
     * @since    1.1.4
     * @access   public
     * @author   Devendra Gaud
     *
     * @param    server    Instence of fastify server.
     * @param    request   HTTP request object
     * @param    {fastify.FastifyReply}      reply     HTTP reply onject
     * @returns  {Promise}
     * @memberof SuperAdminController
     */
    public async getServerLogs(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({ user: request.req.user.uid }, InfoMsg.GET_SERVER_LOGS);
            const offset = Number(request.query.offset);
            const limit = Number(request.query.limit);
            const sortObject = JSON.parse(request.query.sortObject);
            const filterValues = JSON.parse(request.query.filterValues);
            const sortByBoolean = sortObject.sortByBoolean;
            const alphaNumericSortBooleanMessage = sortObject.alphaNumericSortBooleanMessage;
            const alphaNumericSortBooleanLevel = sortObject.alphaNumericSortBooleanLevel;
            const alphaNumericSortBooleanHostName = sortObject.alphaNumericSortBooleanHostName;
            const searchText = request.query.searchText;
            const userData = await this.superAdminService.getServerLogs(server, request, offset, limit, searchText, sortByBoolean, alphaNumericSortBooleanMessage, alphaNumericSortBooleanLevel, alphaNumericSortBooleanHostName, filterValues);
            server.log.info({ user: request.req.user.uid }, SuccessMsg.UPDATE_USER_BY_UID);
            return reply.send(userData);
        } catch (error) {
            server.log.error({ user: request.req.user.uid }, ErrorMsg.GET_SERVER_LOGS);
            server.log.error({ user: request.req.user.uid }, error.message);
            return reply.send(error);
        }
    }


  /**
   * @description Return the avaliable data-list
   * @since    1.1.7
   * @access   public
   * @author   Devendra Gaud
   *
   * @param    {fastify.FastifyInstance} server    Instence of fastify server.
   * @param    {fastify.FastifyRequest}  request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SuperAdminController
   */
    public async getEoDataList(
        server: any,
        request: fastify.FastifyRequest,
        reply: fastify.FastifyReply<any>
    ): Promise<any> {
        try {
        server.log.info({user: request.req["user"].uid}, InfoMsg.GET_EO_DATA_LIST);
        const addedSku = await this.superAdminService.getEoFormDataList(server, request);
        server.log.info({user: request.req["user"].uid}, SuccessMsg.GET_EO_DATA_LIST);
        return reply.send(addedSku);
        } catch (error) {
        server.log.error({user: request.req["user"].uid}, ErrorMsg.GET_EO_DATA_LIST);
        server.log.error({user: request.req["user"].uid}, error.message);
        return reply.send(error);
        }
    }

  /**
   * @description Return the status of performed operation and the eo
   * @since    1.1.7
   * @access   public
   * @author   Devendra Gaud
   *
   * @param    {fastify.FastifyInstance} server    Instence of fastify server.
   * @param    {fastify.FastifyRequest}  request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SuperAdminController
   */
    public async disableEoGenusSpecie(server: any, request: fastify.FastifyRequest, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({user: request.req["user"].uid}, InfoMsg.DISABLE_EO);
            const addedSku = await this.superAdminService.disableEoGenusSpecie(server, request);
            server.log.info({user: request.req["user"].uid}, SuccessMsg.DISABLE_EO);
            return reply.send(addedSku);
            } catch (error) {
            server.log.error({user: request.req["user"].uid}, ErrorMsg.DISABLE_EO);
            server.log.error({user: request.req["user"].uid}, error.message);
            return reply.send(error);
        }
    }

  /**
   * @description Return the eo-node details
   * @since    1.1.8
   * @access   public
   * @author   Devendra Gaud
   *
   * @param    {fastify.FastifyInstance} server    Instence of fastify server.
   * @param    {fastify.FastifyRequest}  request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof SuperAdminController
   */
    public async getEoNode(server: any, request: fastify.FastifyRequest, reply: fastify.FastifyReply<any>): Promise<any> {
        try {
            server.log.info({user: request.req["user"].uid}, InfoMsg.GET_EO_NODE);
            const addedSku = await this.superAdminService.getEoNode(server, request);
            server.log.info({user: request.req["user"].uid}, SuccessMsg.GET_EO_NODE);
            return reply.send(addedSku);
            } catch (error) {
            server.log.error({user: request.req["user"].uid}, ErrorMsg.GET_EO_NODE);
            server.log.error({user: request.req["user"].uid}, error.message);
            return reply.send(error);
        }
    }
}