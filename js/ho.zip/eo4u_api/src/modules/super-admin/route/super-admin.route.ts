import * as fastifyPlugin from "fastify-plugin";
import { SuperAdminController } from "../controller/super-admin.controller";

export default fastifyPlugin(
    async (server, opts, next) => {
    const superAdminController = new SuperAdminController();
    /**
     * @description This route removed user from firebase and flag the deleted user in db.
     * 
     * @since      1.1.4
     * @author     Devendra Gaud
     * 
     * @request    DELETE 
     * @route      /delete-user/:uid
     * @memberof   fastifyPlugin
     */
    server.route({
        url: "/api/delete-user/:uid",
        logLevel: "warn",
        method: ["DELETE"],
        schema: {
            description: "Delete the user from firebase, flag the user in database using uid",
            tags: ["superadmin"],
            summary: "API to delete user from firebase",
            params: {
                type: "object",
                required:["uid"],
                properties:{
                  uid: {
                    type: "string",
                    description: "uid of user ",
                  },
                }
              },
            response: {
                201: {
                    description: "Successful response",
                    type: "object",
                    properties: {
                    }
                }
            },
            security: [
                {
                    "apiKey": []
                }
            ]
        },
        handler:  async (request, reply) => {
          await superAdminController.removeUser(server, request, reply);
        }
    });

    /**
     * @description This route disable the user in firebase and flag the disable user.
     * 
     * @since      1.1.4
     * @author     Devendra Gaud
     * 
     * @request    GET 
     * @route      /disable-user/:uid
     * @memberof   fastifyPlugin
     */
    server.route({
        url: "/api/disable-user/:uid",
        logLevel: "warn",
        method: ["GET"],
        schema: {
            description: "Disable the user from firebase, flag the user in database using uid",
            tags: ["superadmin"],
            summary: "API to disable user from firebase",
            params: {
                type: "object",
                required:["uid"],
                properties:{
                  uid: {
                    type: "string",
                    description: "uid of user ",
                  },
                }
              },
            response: {
                201: {
                    description: "Successful response",
                    type: "object",
                    properties: {
                    }
                }
            },
            security: [
                {
                    "apiKey": []
                }
            ]
        },
        handler:  async (request, reply) => {
          await superAdminController.disableUser(server, request, reply);
        }
    });

    /**
     * @description This route disable the user in firebase and flag the disable user.
     * 
     * @since      1.1.4
     * @author     Devendra Gaud
     * 
     * @request    PUT 
     * @route      /edit-user-by-superadmin/:uid
     * @memberof   fastifyPlugin
     */
    server.route({
      url: "/api/edit-user-by-superadmin/:uid",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
          description: "Update the user details",
          tags: ["superadmin"],
          summary: "API to update user in database",
          params: {
              type: "object",
              required:["uid"],
              properties:{
                uid: {
                  type: "string",
                  description: "uid of user ",
                  minLength: 28,
                  maxLength: 28,
                },
              }
            },
          response: {
              201: {
                  description: "Successful response",
                  type: "object",
                  properties: {
                  }
              }
          },
          security: [
              {
                  "apiKey": []
              }
          ]
      },
      handler:  async (request, reply) => {
        await superAdminController.updateUser(server, request, reply);
      }
  });

    /**
     * @description This route fetch the server logs.
     * 
     * @since      1.1.4
     * @author     Devendra Gaud
     * 
     * @request    GET 
     * @route      /server-logs
     * @memberof   fastifyPlugin
     */
    server.route({
      url: "/api/server-logs",
      logLevel: "warn",
      method: ["GET"],
      schema: {
          description: "Get the server logs, contained details about request that came to server",
          tags: ["superadmin"],
          summary: "API to fetch all server logs",
          querystring:{
            type:"object",
            required: ["limit", "offset", "searchText"],
            properties:{
              limit: {
                type: "number",
                description: "limit",
                maxLength: 2,
                minimum: 0
              },
              offset: {
                type: "number",
                description: "offset",
                minimum: 0
              },
              searchText: {
                type: "string",
                description: "search text"
              },
            }
          },
          response: {
              201: {
                  description: "Successful response",
                  type: "object",
                  properties: {
                  }
              }
          },
          security: [
              {
                  "apiKey": []
              }
          ]
      },
      handler:  async (request, reply) => {
        await superAdminController.getServerLogs(server, request, reply);
      }
  });
    /**
     * @description This route get the data-set for eo-form
     * 
     * @since      1.1.7
     * @author     Devendra Gaud
     * 
     * @request    GET 
     * @route      /get-eo-form-data-set
     * @memberof   fastifyPlugin
     */
    server.route({
      url: "/api/get-eo-form-data-set",
      logLevel: "warn",
      method: ["GET"],
      schema: {
          description: "Get the data-set available to merge with essential oil in eo-form",
          tags: ["superadmin"],
          summary: "API to get data-set",
          response: {
              201: {
                  description: "Successful response",
                  type: "object",
                  properties: {
                  }
              }
          },
          security: [
              {
                  "apiKey": []
              }
          ]
      },
      handler:  async (request, reply) => {
        await superAdminController.getEoDataList(server, request, reply);
      }
  });
    /**
     * @description This route get the disable eo for a specific genus-specie
     * 
     * @since      1.1.7
     * @author     Devendra Gaud
     * 
     * @request    GET 
     * @route      /get-eo-form-data-set
     * @memberof   fastifyPlugin
     */
    server.route({
      url: "/api/disable-genus-specie-eo",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
          description: "Flag the genus-specie, 'disabled' in database ",
          tags: ["superadmin"],
          summary: "Endpoint to disable eo for a genus-specie",

          querystring:{
            type:"object",

            properties:{
              genusSpecie:{
                description:"name of genus-specie",
                type:"string",
                example:"Pimenta dioica",
                maxLength: 254,

              },
              eoId:{
                description:"object-id of eo",
                type:"string",
                value:"9d30a212-bb26-4432-9ead-df5bcf00820c"
              }
            }
          },
          response: {
              201: {
                  description: "Successful response",
                  type: "object",
                  properties: {
                  }
              }
          },
          security: [
              {
                  "apiKey": []
              }
          ]
      },
      handler:  async (request, reply) => {
        await superAdminController.disableEoGenusSpecie(server, request, reply);
      }
    });
    /**
     * @description This route get the disable eo for a specific genus-specie
     * 
     * @since      1.1.8
     * @author     Devendra Gaud
     * 
     * @request    GET 
     * @route      /get-eo-node
     * @memberof   fastifyPlugin
     */
    server.route({
      url: "/api/get-eo-node/:objectId",
      logLevel: "warn",
      method: ["GET"],
      schema: {
          description: "Get the eo details with ids",
          tags: ["superadmin"],
          summary: "Endpoint to get eo",
          params:{
            type:"object",
            properties:{
              objectId:{
                description:"object-id of eo",
                type:"string",
              }
            }
          },
          response: {
              201: {
                  description: "Successful response",
                  type: "object",
                  properties: {
                  }
              }
          },
          security: [
              {
                  "apiKey": []
              }
          ]
      },
      handler:  async (request, reply) => {
        await superAdminController.getEoNode(server, request, reply);
      }
    });
    next();
    }, {
        fastify: "2.x",
        name: "superadmin-plugin",
        decorators: {
            fastify: [],
            reply: []
        },
        dependencies: ["fastify-redis", "fastify-swagger"]
});