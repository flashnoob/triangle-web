import * as _ from "lodash";
import * as Boom from "boom";
import * as fs from "fs";
import * as msg from "../../../msg/index.msg";
import * as readline from "readline";
import { AdminInfo, User } from "../../common-models.interface";
import { Promise } from "bluebird";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import moment = require("moment");

export class SuperAdminService {
    private superAdminDbService: Service.SuperAdminDbService;
    private redis: RedisService;
    private monthList: string[];
    constructor() {
        this.superAdminDbService = new Service.SuperAdminService();
        this.redis = new RedisService();

        this.monthList = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
        ];
    }

    /**
     * @description Calls the updateUserByUID method of eo4u_core's superAdminDbService.
     * It returns the user from the database.
     *
     * @since    1.1.4
     * @access   public
     * @author   Devendra Gaud
     *
     * @param    server - server instance
     * @param    request - HTTP request object
     *
     * @returns  {Promise}
     * @memberof SuperAdminService
     */
    public async updateUser(server: any, request: any): Promise<any> {
        try {
            const targetUserUID = request.params.uid;
            const updatedUser = request.body;
            const userData: User = await this.redis.get(server, request.req.user.uid);
            updatedUser["modified_by"] = userData["uid"];
            updatedUser["modified_at"] = new Date().toISOString();
            const result = await this.superAdminDbService.updateUserByUID(targetUserUID, userData, updatedUser);
            if (!_.isEmpty(result)) {
                const savedUser = await this.redis.set(server, targetUserUID, result);
                return result;
            } else {
                throw Boom.forbidden(msg.ErrorMsg.UPDATE_USER_BY_UID);
            }
        } catch (error) {
            throw error;
        }
    }
    /**
     * @description Calls the disableUserByUID method of eo4u_core's superAdminDbService.
     * It returns the user from the database.
     *
     * @since    1.1.4
     * @access   public
     * @author   Devendra Gaud
     *
     * @param    server - server instance
     * @param    request - HTTP request object
     *
     * @returns  {Promise}
     * @memberof SuperAdminService
     */
    public async disableUser(server: any, request: any): Promise<any> {
        try {
            const targetUserUID = request.params.uid;
            const statusBoolean = JSON.parse( request.query.StatusBoolean);
            const userData: User = await this.redis.get(server, request.req.user.uid);
            const result = await this.superAdminDbService.disableUserByUID(targetUserUID, userData,statusBoolean);
            if (!_.isEmpty(result)) {
                const savedUser = await this.redis.set(server, targetUserUID, result);
                return result;
            } else {
                throw Boom.forbidden(msg.ErrorMsg.DISABLE_USER_BY_UID);
            }
        } catch (error) {
            throw error;
        }
    }
    /**
     * @description Calls the removeUserByUID method of eo4u_core's superAdminDbService.
     * It returns the user from the database.
     *
     * @since    1.1.4
     * @access   public
     * @author   Devendra Gaud
     *
     * @param    server - server instance
     * @param    request - HTTP request object
     *
     * @returns  {Promise}
     * @memberof SuperAdminService
     */
    public async removeUser(server: any, request: any): Promise<any> {
        try {
            const targetUserUID = request.params.uid;
            const userData: User = await this.redis.get(server, request.req.user.uid);
            const result = await this.superAdminDbService.removeUserByUID(targetUserUID, userData);
            if (!_.isEmpty(result)) {
                return result;
            } else {
                throw Boom.forbidden(msg.ErrorMsg.REMOVE_USER_BY_UID);
            }
        } catch (error) {
            throw error;
        }
    }
    /**
     * @description Send the server logs in response
     *
     * @since    1.1.3
     * @access   public
     * @author   Devendra Gaud
     *
     * @param    server - server instance
     * @param    request - HTTP request object
     * @param    {number} limit - limit of number of item to get
     * @param    {number} offset - number of item to skip
     *
     *
     * @returns  {Promise}
     * @memberof SuperAdminService
     */
    public async getServerLogs(server: any, request: any, offset: number, limit: number, searchText: string | any[], sortByBoolean: boolean, alphaNumericSortBoolean: boolean, alphaNumericSortBooleanLevel: boolean, alphaNumericSortBooleanHostName: boolean, filterValues: Array<any>): Promise<any> {
        try {

            let data = [];
            const filteredDataCount = 0;
            const dirname = "./logs/";
            const files = fs.readdirSync(dirname);
            for await (const fileName of files) {
                if (fileName !== "server.log") {
                    const readStream = fs.createReadStream(dirname + fileName, "utf8");
                    const rl = readline.createInterface({
                        input: readStream,
                        crlfDelay: Infinity
                    });
                    for await (const line of rl) {
                        const log = JSON.parse(line);
                        log["time"] = new Date(log["time"]).toLocaleString();
                        log["level"] = log["level"] === 30 ? "Success Log" : "Error Log";
                        data.push(log);
                        if (typeof log["user"] === 'undefined' || (log["user"] !== 'undefined' && log["user"].length === 0)) {
                            log["user"] = "NA"
                        }

                    }
                    sortByBoolean ? data.sort((a, b) => {
                        a = new Date(a.time);
                        b = new Date(b.time);
                        return b.getTime() - a.getTime();
                    })
                        : data.sort((a, b) => {
                            a = new Date(a.time);
                            b = new Date(b.time);
                            return a.getTime() - b.getTime();
                        })


                    //commented for now

                    // alphaNumericSortBooleanHostName ? data.sort((a, b) => {
                    //     a = a.hostname;
                    //     b = b.hostname;
                    //     return a > b ? -1 : b > a ? 1 : 0;

                    // })
                    //     : data.sort((a, b) => {
                    //         a = a.hostname;
                    //         b = b.hostname;
                    //         return a < b ? -1 : b > a ? 1 : 0;
                    //     })

                    // alphaNumericSortBooleanLevel ? data.sort((a, b) => {
                    //     a = a.level ? a.level.toLowerCase() : a.level;
                    //     b = b.level ? b.level.toLowerCase() : b.level;
                    //     return a < b ? -1 : 1

                    // })
                    //     : data.sort((a, b) => {
                    //         a = a.level ? a.level.toLowerCase() : a.level;
                    //         b = b.level ? b.level.toLowerCase() : b.level;
                    //         return a > b ? -1 : 1

                    //     })

                    // alphaNumericSortBoolean ? data.sort((a, b) => {
                    //     a = a.msg ? a.msg.toLowerCase() : a.msg;
                    //     b = b.msg ? b.msg.toLowerCase() : b.msg;
                    //     return a > b ? -1 : b > a ? 1 : 0;
                    // })
                    //     : data.sort((a, b) => {
                    //         a = a.msg ? a.msg.toLowerCase() : a.msg;
                    //         b = b.msg ? b.msg.toLowerCase() : b.msg;

                    //         return a < b ? -1 : b > a ? 1 : 0;`
                    //     })


                }
            }

            filterValues.forEach((item, i) => {
                if (item.value.length > 0) {
                    if (item.name === "User") {
                        data = data.filter(f => item.value.includes(f.user));
                    }

                    if (item.name === "Dates") {
                        data = data.filter((res: any) => {
                            let date = new Date(res.time)
                            let startDate = new Date(item.value[0])
                            let endDate = new Date(item.value[1])
                            return date.getTime() >= startDate.getTime() &&
                                date.getTime() <= endDate.getTime();
                        });
                    }
                    if (item.name === "STATUS") {
                        data = data.filter(f => item.value.includes(f.level));
                    }
                }

            }
            )

            const uniqueUserFilter = [...new Set(data.map(item => item.user).filter(item => item !== "NA"))];
            const uniqueLevelFilter = [...new Set(data.map(item => item.level))];
            // .filter(item => item!== "NA")
            if (searchText.length !== 0) {
                data = data.filter((log) => {
                    return log["msg"].toLowerCase().includes(searchText)
                        || log["level"].toLowerCase().includes(searchText)
                        || log["time"].toLowerCase().includes(searchText)
                        || log["time"].toLowerCase().includes(searchText);
                });
            }
            return {
                size: data.length,
                data: data.slice(offset, offset + limit),
                filterData: [{ user: uniqueUserFilter }, { level: uniqueLevelFilter }, { month: this.monthList }]
            };
        } catch (error) {
            throw error;
        }
    }

  /**
   * @description Calls the getEoDataSet method of eo4u_core's superAdminDbService.
   * 			It return the object containing the value's and id for specified node-label
   *
   * @since    1.1.7
   * @access   public
   * @author   Devendra Gaud
   *
   * @param 	server
   * @param 	request
   *
   * @returns  {Promise}
   * @memberof SuperAdminService
   */
    public async getEoFormDataList(server:any, request:any) : Promise<any> {
        try {
        const userData: User = await this.redis.get(server, request.req.user.uid);
        const result = await this.superAdminDbService.getEoFormDataSet(userData);
        if (!_.isEmpty(result)) {
            return result;
        } else {
            throw Boom.forbidden(msg.ErrorMsg.GET_EO_DATA_LIST);
        }
        } catch (error) {
        throw error;
        }
    }

  /**
   * @description Calls the removeEo method of eo4u_core's superAdminDbService.
   * 			It return the object containing the value's and id for specified node-label
   *
   * @since    1.1.7
   * @access   public
   * @author   Devendra Gaud
   *
   * @param 	server
   * @param 	request
   *
   * @returns  {Promise}
   * @memberof SuperAdminService
   */
    public async disableEoGenusSpecie(server:any, request:any) : Promise<any> {
        const eoDetails = request.body;
        try {
        const userData: User = await this.redis.get(server, request.req.user.uid);
        const result = await this.superAdminDbService.disableEoGenusSpecie(eoDetails, userData);

        if (!_.isEmpty(result)) {
            return result;
        } else {
            throw Boom.forbidden(msg.ErrorMsg.DISABLE_EO);
        }
        } catch (error) {
        throw error;
        }
    }

  /**
   * @description Calls the getNodeDetails method of eo4u_core's superAdminDbService.
   * 			It return the object containing the value's and id for specified node-label
   *
   * @since    1.1.8
   * @access   public
   * @author   Devendra Gaud
   *
   * @param 	server
   * @param 	request
   *
   * @returns  {Promise}
   * @memberof SuperAdminService
   */
    public async getEoNode(server:any, request:any) : Promise<any> {

        try {
            const userData: User = await this.redis.get(server, request.req.user.uid);
            const result = await this.superAdminDbService.getEoNode(request.params.objectId, userData);
            // const result = {...eoDetails};
            if (!_.isEmpty(result)) {
                return result;
            } else {
                throw Boom.forbidden(msg.ErrorMsg.GET_EO_NODE);
            }
        } catch (error) {
            throw error;
        }
    }
}