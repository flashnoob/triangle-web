import * as _ from "lodash";
import * as admin from "firebase-admin";
import * as Boom from "boom";
import * as getStream from "into-stream";
import * as gm from "gm";
import * as moment from "moment";
import * as msg from "../../../msg/index.msg";
import * as rp from "request-promise";
import * as urlHttpClient from "urllib";
import * as uuidv4 from "uuid/v4";
import { Env } from "../../../configure-environment";
import { isEmpty } from "lodash";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { User } from "modules/supplier/model/user.interface";
import { CheckMembershipService, } from "../../../services/checkMembership.service";
const firebaseconfig = require("../../../../config/firebaseconfig.json");

import {
  BlobServiceClient,
  BlobUploadCommonResponse,
  ContainerClient,
  newPipeline,
  Pipeline,
  StorageSharedKeyCredential,
} from "@azure/storage-blob";


export class UserService {
  private config: any;
  private redis: RedisService;
  private checkMembershipService: CheckMembershipService;
  private commonDbService: Service.commonDbService;
  private sharedKeyCredential: StorageSharedKeyCredential;
  private pipeline: Pipeline;
  private blobServiceClient: BlobServiceClient;
  private im: any;

  private containerClient: ContainerClient;
  constructor() {
    this.config = Env.Instance.Config;
    this.commonDbService = new Service.CommonDbService();
    this.checkMembershipService = new CheckMembershipService();
    this.redis = new RedisService();
    this.im = gm.subClass({ imageMagick: true });
    this.sharedKeyCredential = new StorageSharedKeyCredential(
      this.config.STORAGE["AZURE_STORAGE_ACCOUNT_NAME"],
      this.config.STORAGE["AZURE_STORAGE_ACCOUNT_ACCESS_KEY"]
    );
    this.pipeline = newPipeline(this.sharedKeyCredential);
    this.blobServiceClient = new BlobServiceClient(
      this.config.STORAGE["AZURE_STORAGE_URL"],
      this.pipeline
    );
    this.containerClient = this.blobServiceClient.getContainerClient(
      this.config.STORAGE["AZURE_STORAGE_USER_IMAGE_CONTAINER_NAME"]
    );
  }

  /**
   * @description Calls the querySelector method of eo4u_core"s commonDbService.
   *              It returns the user from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       server - instance of server
   * @param       {string} id - userId
   *
   * @returns     {Promise}
   * @memberof    UserService
   */
  public async getUser(server: any, id: string): Promise<any> {
    try {
      const operation: string = "read";
      const result = await this.commonDbService.querySelector(operation, { uid: id }, "");
      if (!isEmpty(result)) {
        for (const element of result.address) {
          if (element["defaultAddress"]) {
            result["countryCode"] = element["countryCode"];
          }
        }
        const savedUser = await this.redis.set(server, id, result);
        return result;
      } else {
        throw Boom.forbidden(msg["ErrorMsg"]["USER_NOT_FOUND"]);
      }
    } catch (error) {
      throw error;
    }
  }
  /**
   * @description Calls the querySelector method of eo4u_core"s commonDbService.
   *              It returns the user-image from the azure.
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       {string} imgName - name of user image
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getUserImage(imgName: string): Promise<any> {
    try {
      const blockBlobClient = await this.containerClient.getBlockBlobClient(
        imgName
      );
      const downloadBlockBlobResponse = await blockBlobClient.download(0);
      return downloadBlockBlobResponse["readableStreamBody"];
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the querySelector method of eo4u_core"s commonDbService.
   *              It returns users from database the base on given label.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param       request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getUsersByLabel(server: any, request: any): Promise<any> {
    const label = request.params.userRole;
    try {
      const operation: string = "readByLabel";
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = {
      };
      const result = await this.commonDbService.querySelector(
        operation,
        properties,
        label,
        userData
      );
      if (!isEmpty(result)) {
        return result;
      } else {
        throw Boom.forbidden(msg["ErrorMsg"]["USER_NOT_FOUND"]);
      }
    } catch (error) {
      throw error;
    }
  }

  /**
   *
   * @description It adds the users in database and return the added user.
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */
  public async addUser(request: any): Promise<any> {
    const data = request.body;
    try {
      const operation: string = "create";
      const properties = data.user_info;
      const label = data.role ? data.role : data.label;
      properties["created_by"] = properties["created_by"] ? properties["created_by"] : data.user_info.uid;
      properties["created_at"] = new Date().toISOString();
      properties["modified_by"] = "";
      properties["modified_at"] = "";
      properties["membership_expire"] = moment().add(15, "days").utc().format("YYYY-MM-DDTHH:mm:ss.SSS[Z]");
      properties["status"] = "active";
      properties.premiumUser = false;
      properties.stripeCustomerID = "";
      properties.role = "MEMBER";
      properties["object_id"] = uuidv4();
      const result = await this.commonDbService.querySelector(
        operation,
        properties,
        label
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the querySelector method of eo4u_core"s commonDbService.
   *              It returns updated user from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   * @param 	    imgData - user image
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async updateUser(server: any, request: any, imgData?: any): Promise<any> {
    const data = request.body;
    try {
      if (imgData) {
        const imageData = await this.uploadImageToBlob(imgData);
      }
      if (data["user_info"]) {
        const operation = "update";
        const userData: User = await this.redis.get(server, request.req.user.uid);
        const properties = JSON.parse(data.user_info);
        properties["modified_by"] = properties["modified_by"] ? properties["modified_by"] : "By User";
        properties["modified_at"] = new Date().toISOString();
        properties["img_name"] = imgData ? imgData.originalname : properties["img_name"];
        const result = await this.commonDbService.querySelector(operation, properties, data.label, userData);
        if (!isEmpty(result)) {
          return result;
        } else {
          throw Boom.forbidden(msg["ErrorMsg"]["USER_NOT_FOUND"]);
        }
      }
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the updateAddress method of eo4u_core"s commonDbService.
   *              It returns updated user from the database.
   *
   * @since       1.0.5
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       userDetails - server instance
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async updateAddress(server: any, request: any, userDetails: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.updateAddress(userDetails, userData);
      return result;
    } catch (error) {
      return error;
    }
  }


  /**
   * @description Calls the updateUserProperties method of eo4u_core"s commonDbService.
   *              It returns updated user from the database.
   *
   * @since       1.0.5
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       userDetails - server instance
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async updateUserProperties(server: any, request: any, body: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.updateUserProperties(body.userDetails, userData);
      return result;
    } catch (error) {
      return error;
    }
  }


  /**
   * @description Create relation between user and sku
   *
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   * 
   * @param       server - server instance
   * @param	      request - HTTP request object
   * 
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async addProduct(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      const operation = "createRelation";
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.querySelector(
        operation,
        data,
        data.status,
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the querySelector method of eo4u_core"s commonDbService.
   *              remove relation between user and sku
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async removeProduct(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      const operation = "removeRelation";
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.removeSkuRelation(data, userData);
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the querySelector method of eo4u_core"s commonDbService.
   *              It returns HealthConditions array.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getHealthConditions(server: any, request: any): Promise<any> {
    try {
      const operation = "readHealthConditions";
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = {
      };
      const result = await this.commonDbService.querySelector(operation, properties, "", userData);
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Returns the filter object
   *
   * @since       1.0.2
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getRecommendedFilter(server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const {offset, limit} = request.query;
      const searchText = request.query.searchText || "";
      const result = await this.commonDbService.getRecommendedFilter(offset, limit, searchText, userData);
      const recommendedUses =
        result.length > 0
          ? Array.from(
            new Set(result.map((element: { recommendedUse: any; }) => element.recommendedUse))
          )
          : [];
      const groupedRecommendedUses = [];
      for (const use of recommendedUses) {
        const subrecommendedUses = result.filter((element) =>  element.recommendedUse === `${use}`)
        .map((recomUse) => {
          return {subrecommendedUse:recomUse.subrecommendedUse, id:recomUse.id };
        });
        groupedRecommendedUses.push({
          recommendedUse: use,
          subrecommendedUses,
        });
      }
      return groupedRecommendedUses;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Returns the filter object
   *
   * @since       1.0.2
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getEOFilter(server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.getEOFilter(userData);
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Returns the membership is active or not
   *
   * @since       1.1.3
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async checkUserMembership(server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      if (moment().diff(userData.membership_expire) >= 0) {
        return false;
      }
      return true;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Stores image data in azure blob storage.
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   * @param       any
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async uploadImageToBlob(imgData: any): Promise<BlobUploadCommonResponse> {
    return new Promise((resolve, reject) => {
      this.im(imgData.buffer, "img.jpg")
        .resize(720, 1280)
        .toBuffer("jpg", async (err, buffer) => {
          try {
            if (err) {
              reject(err);
            }
            const stream = getStream(buffer);
            const blockBlobClient = await this.containerClient.getBlockBlobClient(
              imgData.originalname
            );
            const result = await blockBlobClient.uploadStream(
              stream,
              buffer.length,
              20,
              { blobHTTPHeaders: { blobContentType: imgData.mimetype } }
            );
            resolve(result);
          } catch (error) {
            reject(error);
          }
        });
    });
  }
  /**
   *
   * @description It Gets user info from swagger and  generate IDtoken from firebase.
   *
   * @since       1.1.2
   * @access      public
   * @author      Sachin Kotian
   *
   * @param       object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */
  public async swaggerLogin(server: any, request: any): Promise<any> {
    const { email, password } = request.body.user_info;
    if (email && password) {
      const customToken: string = await admin.auth().createCustomToken(uuidv4());
      try {
        const firebaseIdToken = await rp({
          url: `https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyCustomToken?key=${firebaseconfig.apiKey}`,
          method: "POST",
          body: {
            token: customToken,
            returnSecureToken: true
          },
          json: true,
        });
        const verifiedToken: admin.auth.DecodedIdToken = await admin.auth().verifyIdToken(firebaseIdToken.idToken);
        return firebaseIdToken;
      } catch (error) {
        throw error;
      }

    }
  }

    /**
     *
     * @description service to add a product review.
     *
     * @since       1.1.6
     * @access      public
     * @author      Ditha Raju
     *
     * @param       server
     * @param       request
     *
     * @returns     {Promise}
     * @memberof    UserService
     */

  public async addProductReview(server: any, request: any): Promise<any> {

    const data = request.body;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.addProductReview(
        data,
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }


    /**
     *
     * @description service to update a product review.
     *
     * @since       1.1.6
     * @access      public
     * @author      Ditha Raju
     *
     * @param       server
     * @param       request
     *
     * @returns     {Promise}
     * @memberof    UserService
     */

  public async updateProductReview(server: any, request: any): Promise<any> {

    const data = request.body;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.updateProductReview(
        data,
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }
  /**
   *
   * @description service to get a product review.
   *
   * @since       1.1.6
   * @access      public
   * @author      Ditha Raju
   *
   * @param       server
   * @param       request
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getUserProductReview(eoId: any, server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.getUserProductReview(
        eoId,
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   *
   * @description service to get a product review.
   *
   * @since       1.1.6
   * @access      public
   * @author      Ditha Raju
   *
   * @param       requestedData
   * @param       server
   * @param       request
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getProductReviews(requestedData: any, server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.commonDbService.getProductReviews(
        requestedData,
        userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Return associated providers
   *
   * @since       1.2.2
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       {string} email
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async getProviders(email:string): Promise<any> {
    try {
        const firebaseAuth = admin.auth();
        const result = firebaseAuth.getUserByEmail(email);
        const providers =  (await result).providerData.map(provider => provider.providerId === "password" ? "Email" : _.startCase(provider.providerId.split(".")[0]));
        return providers;
    } catch (error) {
      if (error.code && error.code === "auth/user-not-found") {
        return [];
      }
      throw error;
    }
  }
}
