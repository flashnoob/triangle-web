import * as http from 'http';
import * as jwt from 'jsonwebtoken';




export function userMiddleware(req,res,next){

}