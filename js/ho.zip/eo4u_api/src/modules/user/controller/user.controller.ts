import * as fastify from "fastify";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";
import { UserService } from "../service/user.service";

export class UserController {
  private userService: UserService;

  constructor() {
    this.userService = new UserService();
  }

  /**
   * @description Returns the user
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */

  public async getUser(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_USER);
      const userData = await this.userService.getUser(server, request.params.id);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_USER);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_USER);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns the blob-object of user-profile image
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */

  public async getUserImage(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: ""}, InfoMsg.GET_USER_IMAGE);
      const userData = await this.userService.getUserImage(request.params.imageName);
      server.log.info({user: ""}, SuccessMsg.GET_USER_IMAGE);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: ""}, ErrorMsg.GET_USER_IMAGE);
      server.log.error({user: ""}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns list of all the user.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */

  public async getUserList(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_USER_LIST);
      const userList = await this.userService.getUsersByLabel(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_USER_LIST);
      return reply.send(userList);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_USER_LIST);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }


  /**
   * @description Adds user in the database  and return the added User
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */
  public async addUser(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_USER);
      const userData = await this.userService.addUser(request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_USER);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_USER);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description update user in the database, and return the updated user
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */

  public async updateUser(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_USER);
      const userData = await this.userService.updateUser(server, request, request.files.length > 0 ? request.files[0] : undefined);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_USER);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_USER);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }



  /**
   * @description Create relation between user and sku
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */

  public async addProduct(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_PRODUCT);
      const userData = await this.userService.addProduct(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_PRODUCT);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_PRODUCT);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Remove relation between user and sku, either in it's inventory or cart
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */

  public async removeProduct(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.REMOVE_PRODUCT);
      const userData = await this.userService.removeProduct(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.REMOVE_PRODUCT);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.REMOVE_PRODUCT);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns the health conditions array 
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */

  public async getHealthConditions(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_HEALTH_CONDITIONS);
      const healthConditions = await this.userService.getHealthConditions(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_HEALTH_CONDITIONS);
      return reply.send(healthConditions);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_HEALTH_CONDITIONS);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description returns the filter object
   *
   * @since    1.0.2
   * @access   public
   * @author   Devendra Gaud
   *
   * @param    server    Instance of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */

  public async getRecommendFilterObject(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_FILTER_OBJECT);
      const filter = await this.userService.getRecommendedFilter(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_FILTER_OBJECT);
      return reply.send(filter);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_FILTER_OBJECT);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description returns the EO filter object
   *
   * @since    1.0.2
   * @access   public
   * @author   Sachin Kotian
   *
   * @param    server    Instance of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */

  public async getEOFilterObject(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_EO_FILTER_OBJECT);
      const filter = await this.userService.getEOFilter(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_EO_FILTER_OBJECT);
      return reply.send(filter);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_EO_FILTER_OBJECT);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description calls the checkUserMembership of userService and return the response
   *
   * @since    1.1.3
   * @access   public
   * @author   Devendra Gaud
   *
   * @param    server    Instance of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}    reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */

  public async checkUserMembership(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.CHECK_MEMBERSHIP);
      const membershipStatus = await this.userService.checkUserMembership(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.CHECK_MEMBERSHIP);
      return reply.send(membershipStatus);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.CHECK_MEMBERSHIP);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description update address in the database.
   * and returns the updated user
   *
   * @since    1.0.5
   * @access   public
   * @author   Sachin Kotian
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */

  public async updateAddress(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_ADDRESS);
      const user = await this.userService.updateAddress(server, request, request.body);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_ADDRESS);
      return reply.send(user);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_ADDRESS);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Logs in user from swagger
   *
   * @since       1.1.2
   * @access      public
   * @author      Sachin Kotian
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    UserController
   */
  public async swaggerLogin(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: ""}, InfoMsg.SWAGGER_LOGIN);
      const userData = await this.userService.swaggerLogin(server, request);
      server.log.info({user: ""}, SuccessMsg.SWAGGER_LOGIN);
      return reply.send(userData);
    } catch (error) {
      server.log.error({user: ""}, ErrorMsg.SWAGGER_LOGIN);
      server.log.error({user: ""}, error.message);
      return reply.send(error);
    }
  }


  /**
   * @description update address in the database.
   * and returns the updated user
   *
   * @since    1.0.5
   * @access   public
   * @author   Sachin Kotian
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */

  public async updateUserProperties(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_USER_PROPERTIES);
      const user = await this.userService.updateUserProperties(server, request, request.body);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_USER_PROPERTIES);
      return reply.send(user);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_USER_PROPERTIES);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description adds a product review. 
   *
   * @since    1.1.6
   * @access   public
   * @author   Ditha Raju
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */
  public async addProductReview(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_PRODUCT_REVIEW);
      const productReview = await this.userService.addProductReview(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_PRODUCT_REVIEW);
      return reply.send(productReview);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_PRODUCT_REVIEW);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Updates a product review. 
   *
   * @since    1.1.6
   * @access   public
   * @author   Ditha Raju
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */
  public async updateProductReview(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_PRODUCT_REVIEW);
      const productReview = await this.userService.updateProductReview(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_PRODUCT_REVIEW);
      return reply.send(productReview);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_PRODUCT_REVIEW);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Gets a product review. 
   *
   * @since    1.1.6
   * @access   public
   * @author   Ditha Raju
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */
  public async getUserProductReview(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      const eoId = request.query.eoId;
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_PRODUCT_REVIEW);
      const productReview = await this.userService.getUserProductReview(eoId, server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_PRODUCT_REVIEW);
      return reply.send(productReview);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_PRODUCT_REVIEW);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Gets a product review. 
   *
   * @since    1.1.6
   * @access   public
   * @author   Ditha Raju
   *
   * @param    server    Instence of fastify server.
   * @param    request   HTTP request object
   * @param    {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns  {Promise}
   * @memberof UserController
   */
  public async getProductReviews(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      const eoId = request.query.eoId;
      const offset = Number(request.query.offset);
      const limit = Number(request.query.limit);
      const requestedData = {
        eoId, limit, offset
      }
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_ALL_PRODUCT_REVIEW);
      const productReview = await this.userService.getProductReviews(requestedData, server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_ALL_PRODUCT_REVIEW);
      return reply.send(productReview);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_ALL_PRODUCT_REVIEW);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

   /**
    * @description Enter logs for request to get associated providers
    *
    * @since    1.2.2
    * @access   public
    * @author   Devendra Gaud
    *
    * @param    server    Instence of fastify server.
    * @param    request   HTTP request object
    * @param    reply     HTTP reply onject
    * @returns  {Promise}
    * @memberof UserController
    */
  public async getAccountProviders(server: any, request: any, reply: any): Promise<any> {
    try {
      const email = request.query.email;
      server.log.info({user: ""}, InfoMsg.GET_ALL_PRODUCT_REVIEW);
      const productReview = await this.userService.getProviders(email);
      server.log.info({user: ""}, SuccessMsg.GET_ALL_PRODUCT_REVIEW);
      return reply.send(productReview);
    } catch (error) {
      server.log.error({user: ""}, ErrorMsg.GET_ALL_PRODUCT_REVIEW);
      server.log.error({user: ""}, error.message);
      return reply.send(error);
    }
  }
}
