import * as fastifyPlugin from "fastify-plugin";
import * as fs from "fs";
import multer from "fastify-multer";
import { UserController } from "../controller/user.controller";
const upload = multer();

export default fastifyPlugin(
  async (server, opts, next) => {
    const userController = new UserController();

    /**
     * @description This route returns list of all the users by their labels.
     *
     * @since      1.0.0
     * @author     Mohit Sharma(mhtsharma)
     *
     * @request    GET
     * @route      /get-user/:userRole
     * @memberof   fastifyPlugin
     */

    server.route({
      url: "/api/get-users/:userRole",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "get list of users on user-role",
        tags: ["user"],
        summary: "API to get user(s)",
        params: {
          type: "object",
          required: ["userRole"],
          properties: {
            userRole: {
              type: "string",
              description: "label",
              enum: ["MEMBER_USER_NL", "USER_NL", "PREMIUMMEMBER_USER_NL", "SPONSOREDMEMBER_USER_NL", "ADMIN_USER_NL", "SPONSOREDADMIN_USER_NL", "SUPERADMIN_USER_NL", ""]
            },
          }
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await userController.getUserList(server, request, reply);
      },
    });

    /**
     * @description This route returns list of all the users by their labels.
     *
     * @since       1.0.0
     * @author      Mohit Sharma(mhtsharma)
     *
     * @request     GET
     * @route       /get-users-image/:imageName
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/get-users-image/:imageName",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "get list of users on user-role",
        tags: ["user"],
        summary: "API to get user(s)",
        params: {
          type: "object",
          required: ["imageName"],
          properties: {
            imageName: {
              type: "string",
              description: "image-name",
              minlength: 5,
              maxlength: 100,
              value: "userName.png"
            },
          }
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await userController.getUserImage(server, request, reply);
      },
    });

    /**
     * @description This route returns the user by user_id.
     *
     * @since       1.0.0
     * @author      Mohit Sharma(mhtsharma)
     *
     * @request     GET
     * @route       /get-user/:id
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/get-user/:id",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "pass the UID to retrieve the user details",
        tags: ["user"],
        summary: "API to get user",
        params: {
          type: "object",
          required: ["id"],
          properties: {
            id: {
              type: "string",
              description: "user id",
              minLength: 28,
              maxLength: 28,
              value: "8VSsjze8luSlvmvV9tccYfEJEd82"
            },
          },
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await userController.getUser(server, request, reply);
      },
    });

    /**
     * @description This route adds user in the database.
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       /add-user/
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/add-user",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Add a new member",
        summary: "API to add new user",
        tags: ["user"],
        body: {
          type: "object",
          properties: {
            label: { type: "string", example: "MEMBER_USER_NL" },
            user_info: {
              type: "object",
              required: ["img_name", "email", "phoneNumber", "uid", "isNewUser", "lastSigninTimestamp", "firstName", "lastName", "address", "sex", "birthday"],
              properties: {
                firstName: { type: "string", example: "Vijay" },
                lastName: { type: "string", example: "Chouhan" },
                sex: { type: "string", example: "male" },
                phoneNumber: { type: "string", example: "43534535" },
                birthday: { type: "string", example: "15-6-1988" },
                email: { type: "string", example: "swuuvcscqsalfguvpf@awdrt.com" },
                address: {
                  type: "array",
                  items: {
                    type: "object",
                    required: ["street1", "zip", "city", "state", "country", "countryCode", "defaultAddress"],
                    properties: {
                      street1: { type: "string", example: "street 1" },
                      street2: { type: "string", example: "streeet 2" },
                      zip: { type: "string", example: "32212" },
                      city: { type: "string", example: "Packo" },
                      state: { type: "string", example: "Mishima" },
                      country: { type: "string", example: "India" },
                      countryCode: { type: "string", example: "INR" },
                      defaultAddress: { type: "boolean", "example": true }
                    },
                  },
                },
                img_name: { type: "string", example: "userName.png" },
                isNewUser: { type: "boolean", example: true },
                lastSigninTimestamp: { type: "string", example: "Wed Jun 10 2020 13:35:57 GMT+0530 (IST)" },
                uid: { type: "string" },
                premiumUser: { type: "boolean", example: true }
              },
            },
          },
        },
      },
      handler: async (request, reply) => {
        await userController.addUser(server, request, reply);
      },
    });

    /**
     * @description This update the user by user_id.
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       /update-user/:uid
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/update-user/:uid",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Update user details",
        summary: "API to update user",
        tags: ["user"],
        body: {
          // type: "object",
          // properties: {}
        },
      },
      preHandler: upload.any(),
      handler: async (request, reply) => {
        if (request.files.length) {
          fs.writeFileSync(
            request.files[0]["originalname"],
            request.files[0].buffer
          );
        }
        await userController.updateUser(server, request, reply);
      },
    });

    /**
     * @description This add item in cart
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       /add-item
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/add-item",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "add the product in cart or inventory",
        tags: ["user"],
        summary: "API endpoint to  add product",
        params: {},
        body: {
          type: "object",
          required: ["status", "EoName", "supplier", "sku", "uid"],
          properties: {
            status: {
              type: "string",
              example: "IN_CART",
              enum: ["ADD_INVENTORY", "IN_CART"],
              minLength: 3,
              maxLength: 20
            },
            EoName: {
              type: "string",
              description: "name of essential oil",
              example: "Bergamot",
              minLength: 3,
              maxLength: 200
            },
            supplier: {
              type: "string",
              description: "name of supplier",
              example: "doTERRA",
              minLength: 3,
              maxLength: 100
            },
            sku: {
              type: "string",
              description: "sku no.",
              example: "30790001",
              minLength: 2,
              maxLength: 50,
            },
            uid: {
              type: "string",
              description: "unique-id",
              example: "8VSsjze8luSlvmvV9tccYfEJEd82",
              minLength: 28,
              maxLength: 28,
            },
          },
        },
      },
      handler: async (request, reply) => {
        await userController.addProduct(server, request, reply);
      },
    });

    /**
     * @description This remove item from cart
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     PUT
     * @route       /remove-item
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/remove-item",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
        description: "remove the product from cart",
        tags: ["user"],
        summary: "API endpoint to  add product",
        params: {},
        body: {
          type: "object",
          required: ["status", "EoName", "supplier", "sku", "uid"],
          properties: {
            status: {
              type: "string",
              example: "IN_CART",
              enum: ["IN_CART"],
              minLength: 3,
              maxLength: 20
            },
            EoName: {
              type: "string",
              description: "name of essential oil",
              example: "Bergamot",
              minLength: 3,
              maxLength: 200
            },
            supplier: {
              type: "string",
              description: "name of supplier",
              example: "doTERRA",
              minLength: 3,
              maxLength: 100
            },
            sku: {
              type: "string",
              description: "sku no.",
              example: "30790001",
              minLength: 2,
              maxLength: 50,
            },
            uid: {
              type: "string",
              example: "8VSsjze8luSlvmvV9tccYfEJEd82",
              description: "unique-id",
              minLength: 28,
              maxLength: 28,
            },
          },
        },
      } /*  */,
      handler: async (request, reply) => {
        await userController.removeProduct(server, request, reply);
      },
    });

    /**
     * @description   get the health conditions array 
     *
     * @since         1.0.0
     * @author        Devendra Gaud
     *
     * @request       GET
     * @route         /get-health-conditions
     * @memberof      fastifyPlugin
     */

    server.route({
      url: "/api/get-health-conditions",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "get the health conditions array",
        tags: ["user"],
        summary: "API endpoint to update inventory of user",
      },
      handler: async (request, reply) => {
        await userController.getHealthConditions(server, request, reply);
      },
    });

    /**
     * @description Route return the filter-Object
     *
     * @since       1.0.2
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       /get-filters
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/recommend-filter",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "get the filter object",
        tags: ["user"],
        summary: "API endpoint to fetch filters",
        querystring: {
          type: "object",
          required :["offset", "limit"],
          properties: {
            offset: {
              type: "string"
            },
            limit: {
              type: "string"
            },
            searchText: {
              type: "string"
            }
          }
        }
      },
      handler: async (request, reply) => {
        await userController.getRecommendFilterObject(server, request, reply);
      },
    });

    /**
     * @description Route return the filter-Object
     *
     * @since       1.0.2
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       /-eo-filters
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/get-eo-filters",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "get the EO filter object",
        tags: ["user"],
        summary: "API endpoint to fetch EO filters",
      },
      handler: async (request, reply) => {
        await userController.getEOFilterObject(server, request, reply);
      },
    });

    /**
     * @description Route to check if membership has been expired or not
     *
     * @since       1.1.3
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       /check-user-membership
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/check-user-membership",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "Check if user membership is active or expire",
        tags: ["user"],
        summary: "API endpoint to check membership",
      },
      handler: async (request, reply) => {
        await userController.checkUserMembership(server, request, reply);
      },
    });

    /**
     * @description This route update the addres-array of user.
     *
     * @since       1.0.5
     * @author      Sachin Kotian
     *
     * @request     POST
     * @route       /update-address
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/update-address",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Update address of user",
        summary: "API to update user address",
        tags: ["user"],
        body: {
          type: "object",
          required: ["userId", "addressArray"],
          properties: {
            addressArray: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  street1: { type: "string", example: "street 1" },
                  street2: { type: "string", example: "streeet 2" },
                  zip: { type: "string", example: "32212" },
                  city: { type: "string", example: "Packo" },
                  state: { type: "string", example: "Mishima" },
                  country: { type: "string", example: "India" },
                  countryCode: { type: "string", example: "INR" },
                  defaultAddress: { type: "boolean", "example": true }
                }
              }
            },
            userId: { type: "string", example: "8VSsjze8luSlvmvV9tccYfEJEd82" }
          },
        },
      },
      handler: async (request, reply) => {
        const response = await userController.updateAddress(server, request, reply);
        return reply.send(response);
      },
    });


    /**
     * @description This route update the addres-array of user.
     *
     * @since       1.1.3
     * @author      Sachin Kotian
     *
     * @request     POST
     * @route       /update-address
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/update-user-properties",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Update properties of user",
        summary: "API to update user properties",
        tags: ["user"],
        body: {
          type: "object",
          properties: {
            userDetails: {
              type: "object",
              properties: {
                customerStripeID: { type: "string" },
                userId: { type: "string" },
              }
            },
          },
        },
      },
      handler: async (request, reply) => {
        const response = await userController.updateUserProperties(server, request, reply);
        return reply.send(response);
      },
    });

    /**
     * @description This route logs in swagger user.
     *
     * @since       1.1.2
     * @author      Sachin Kotian
     *
     * @request     POST
     * @route       /swagger-login/
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/swagger-login",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "Swagger admin login",
        summary: "API to admin login",
        tags: ["swagger-login"],
        body: {
          type: "object",
          properties: {
            user_info: {
              type: "object",
              properties: {
                email: { type: "string", example: "mhtsharma948@gmail.com" },
                password: { type: "string", example: "mohit.1234" },
              },
            },
          },
          password: { type: "string" },
        },
      },
      handler: async (request, reply) => {
        await userController.swaggerLogin(server, request, reply);
      },
    });

    /**
     * @description This adds a product review.
     *
     * @since       1.1.6
     * @author      Ditha Raju
     *
     * @request     POST
     * @route       /product-review/
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/add-product-review",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "User Review and Rating",
        summary: "API endpoint to add a Review and Rating",
        tags: ["user"],
        body: {
          type: "object",
          properties: {
            eo_id: { type: "string", example: "305e1a41-3e39-47cd-8940-5d8615d88a9b" },
            star: { type: "number", example: "4" },
            review: { type: "string", example: "It smells really good." }
          },
        },
      },
      handler: async (request, reply) => {
        await userController.addProductReview(server, request, reply);
      },
    });

    /**
     * @description This returns a product review.
     *
     * @since       1.1.6
     * @author      Ditha Raju
     *
     * @request     GET
     * @route       /get-user-product-review/
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/get-user-product-review",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "User Review and Rating",
        summary: "API endpoint to return the product`s Review and Rating",
        tags: ["user"],
        querystring: {
          type: "object",
          properties: {
            eoId: { type: "string", example: "305e1a41-3e39-47cd-8940-5d8615d88a9b" }
          },
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await userController.getUserProductReview(server, request, reply);
      },
    });

    /**
     * @description This updates a product review.
     *
     * @since       1.1.6
     * @author      Ditha Raju
     *
     * @request     PUT
     * @route       /update-product-review/
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/update-product-review",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
        description: "User Review and Rating",
        summary: "API endpoint to add a Review and Rating",
        tags: ["user"],
        body: {
          type: "object",
          properties: {
            eo_id: { type: "string", example: "305e1a41-3e39-47cd-8940-5d8615d88a9b" },
            star: { type: "number", example: "4" },
            review: { type: "string", example: "It smells really good." }
          },
        },
      },
      handler: async (request, reply) => {
        await userController.updateProductReview(server, request, reply);
      },
    });

    /**
     * @description This returns all product reviews.
     *
     * @since       1.1.7
     * @author      Ditha Raju
     *
     * @request     GET
     * @route       /get-all-product-reviews/
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/get-all-product-reviews",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "User Review and Rating",
        summary: "API endpoint to return the product`s Review and Rating",
        tags: ["EO"],
        querystring: {
          type: "object",
          properties: {
            eoId: { type: "string", example: "305e1a41-3e39-47cd-8940-5d8615d88a9b" },
            offset: {type: "number", example:"0"},
            limit: {type: "number", example:"5"}
          },
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await userController.getProductReviews(server, request, reply);
      },
    });

    /**
     * @description This returns list of associated providers for queried email.
     *
     * @since       1.2.2
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       /get-account-providers
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/get-account-providers",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "User Review and Rating",
        summary: "API endpoint to return the product`s Review and Rating",
        tags: ["user"],
        querystring: {
          type: "object",
          properties: {
            email: { type: "string", example: "devendragaud01@gmail.com" },
          },
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await userController.getAccountProviders(server, request, reply);
      },
    });


    next();
  },
  {
    fastify: "2.x",
    name: "user-plugin",
    decorators: {
      fastify: [],
      reply: [],
    },
    dependencies: ["fastify-redis", "fastify-swagger"],
  }
);
