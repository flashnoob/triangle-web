import * as fastify from "fastify";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";
import { InventoryService } from "../service/inventory.service";

export class InventoryController {
  private inventoryService: InventoryService;

  constructor() {
    this.inventoryService = new InventoryService();
  }
  /**
   * @description create relation between user and sku
   *              for inventory and cart
   *
   * @since       1.0.5
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply object
   * 
   * @returns     {Promise}
   * @memberof    InventoryController
   */

  public async checkSkuAvailability(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.CHECK_SKU_INVENTORY);
      const userSkurelation = await this.inventoryService.checkSkuAvailability(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.CHECK_SKU_INVENTORY);
      return reply.send(userSkurelation);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.CHECK_SKU_INVENTORY);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }
  /**
   * @description Returns the updated array of products from inventory
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply object
   * 
   * @returns     {Promise}
   * @memberof    InventoryController
   */

  public async updateInventory(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_TO_INVENTORY);
      const updatedInventory = await this.inventoryService.updateInventory(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_TO_INVENTORY);
      return reply.send(updatedInventory.eo_array);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_TO_INVENTORY);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Return array of eo in inventory
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply object
   * 
   * @returns     {Promise}
   * @memberof    InventoryController
   */

  public async getInventory(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_INVENTORY);
      const updatedInventory = await this.inventoryService.getInventory(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_INVENTORY);
      return reply.send(updatedInventory.eo_array);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_INVENTORY);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }
  /**
   * @description Get Health statement for eo in inventory
   *
   * @since       1.0.5
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply object
   * 
   * @returns     {Promise}
   * @memberof    InventoryController
   */

  public async getEoHealthCaution(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_SKU_HEALTH_CAUTION);
      const healthCautionStatement = await this.inventoryService.checkEoHealthCaution(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_SKU_HEALTH_CAUTION);
      return reply.send(healthCautionStatement);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_SKU_HEALTH_CAUTION);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Remove relation between user and sku, either in it's inventory or cart
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instance of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply object
   * @returns     {Promise}
   * @memberof    UserController
   */

  public async removeProduct(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.REMOVE_PRODUCT);
      const removedSku = await this.inventoryService.removeProduct(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.REMOVE_PRODUCT);
      return reply.send(removedSku);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.REMOVE_PRODUCT);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }
}