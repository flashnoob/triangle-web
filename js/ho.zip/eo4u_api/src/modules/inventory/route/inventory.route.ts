import * as fastifyPlugin from "fastify-plugin";
import { InventoryController } from "../controller/inventory.controller";

export default fastifyPlugin(
  async (server, opts, next) => {
    const inventoryController = new InventoryController();

    /**
     * @description This check the status of the sku
     *              if it's in the user's cart or inventory or neither in them.
     *              give boolean in response
     *
     * @since       1.0.5
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       /check-sku-status
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/check-sku-status",
      logLevel: "warn",
      method: ["POST"],
      schema: {
        description: "add the product in cart",
        tags: ["inventory"],
        summary: "API endpoint to  add product",
        params: {},
        body: {
          type: "object",
          required:["status", "EoName", "supplier", "size", "uid"],
          properties: {
            status: {
              type: "string",
              example:"ADD_INVENTORY",
              minLength:2,
              maxLength:20
            },
            EoName: {
              type: "string",
              description:"name of essential oil",
              example:"Bergamot",
              minLength:2,
              maxLength:200
            },
            supplier: {
              type: "string",
              description:"name of supplier",
              example:"escents" ,
              minLength:5 ,
              maxLength:100
            },
            size: {
              type: "string" ,
              description:"quantity of eo",
              example:"10 mL" ,
              minLength:3 ,
              maxLength:20
            },
            uid: {
              type: "string",
              example:"8VSsjze8luSlvmvV9tccYfEJEd82",
              description: "unique-id",
              minLength:28,
              maxLength:28,
            },
          },
        },
      },
      handler: async (request, reply) => {
        await inventoryController.checkSkuAvailability(server, request, reply);
      },
    });


    /**
     * @description This add item in inventory
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     PUT
     * @route       /update-inventory/:uid
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/update-inventory/:uid",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
        description: "update the inventory items of requested uid",
        tags: ["inventory"],
        summary: "API endpoint to update inventory of user",
        params: {
          uid: {
            type: "string",
            description: "UID",
          },
        },
        body: {
          type: "object",
          properties: {
            label: { type: "string" , description: "type of inventory", enum: ["SINGLE_INVENTORY_NL", "BLEND_INVENTORY_NL"], example:"SINGLE_INVENTORY_NL" },
            eo_array: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  // schema for single eo
                  supplier: { type: "string" },
                  size: { type: "string" },
                  blendsWellWith: { type: "string" },
                  // schema for blend eo
                  blends_array: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        name: { type: "string" },
                        drps: { type: "number" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
      },
      handler: async (request, reply) => {
        await inventoryController.updateInventory(server, request, reply);
      },
    });

    /**
     * @description This get array of eo from inventory
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       /get-inventory
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/get-inventory",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "update the inventory items of requested uid",
        tags: ["inventory"],
        summary: "API endpoint to update inventory of user",
        querystring: {
          type: "object",
          required: ["uid", "label"],
          properties:{
            uid: {
              type: "string",
              description: "user's uid",
              minLength:28,
              maxLength:28,
            },
            label: {
              type: "string",
              description: "type of inventory",
              enum: ["SINGLE_INVENTORY_NL", "BLEND_INVENTORY_NL"]
            },
          }
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
      },
      handler: async (request, reply) => {
        await inventoryController.getInventory(server, request, reply);
      },
    });

    /**
     * @description This check the status of the sku
     *              if it's in the user's cart or inventory or neither in them.
     *
     * @since       1.0.6
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       /get-eo-health-caution
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/get-eo-health-caution",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "Return the health caution statement product added in inventory from product details",
        tags: ["inventory"],
        summary: "API endpoint to  get health caution",
        params: {},
        querystring: {
          type: "object",
          required: ["uid", "eoName", "genusSpecie"],
          properties:{
            uid: {
              type: "string",
              description: "user's uid",
              minLength:28,
              maxLength:28,
            },
            eoName: {
              type :"string",
              description: "eo-name",
              value:"Bergamot",
              minLength:2,
              maxLength:200,
            },
            genusSpecie:{
              type:"string",
              description: "product genus or specie",
              value: "Citrus bergamia",
              minLength:2,
              maxLength:100,
            }
          }
        },
      },
      handler: async (request, reply) => {
        await inventoryController.getEoHealthCaution(server, request, reply);
      },
    });

    /**
     * @description This check the status of the sku
     *              if it's in the user's cart or inventory or neither in them.
     *
     * @since       1.0.5
     * @author      Devendra Gaud
     *
     * @request     PUT
     * @route       /remove-sku-inventory
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/remove-sku-inventory",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
        description: "add the sku in inventory",
        tags: ["inventory"],
        summary: "API endpoint to  add sku in inventory",
        params: {},
        body: {
          type: "object",
          required:["status", "EoName", "supplier", "size", "uid"],
          properties: {
            status: {
              type: "string",
              example:"ADD_INVENTORY",
              minLength:5,
              maxLength:20
            },
            EoName: {
              type: "string",
              description:"name of essential oil",
              example:"Bergamot",
              minLength:5,
              maxLength:200
            },
            supplier: {
              type: "string",
              description:"name of supplier",
              example:"escents" ,
              minLength:5 ,
              maxLength:100
            },
            size: {
              type: "string" ,
              description:"quantity of eo",
              example:"10 mL" ,
              minLength:3 ,
              maxLength:20
            },
            uid: {
              type: "string",
              example:"8VSsjze8luSlvmvV9tccYfEJEd82",
              description: "unique-id",
              minLength:28,
              maxLength:28,
            },
          },
        },
      },
      handler: async (request, reply) => {
        await inventoryController.removeProduct(server, request, reply);
      },
    });
    next();
  },
  {
    fastify: "2.x",
    name: "inventory-plugin",
    decorators: {
      fastify: [],
      reply: [],
    },
    dependencies: ["fastify-redis", "fastify-swagger"],
  }
);
