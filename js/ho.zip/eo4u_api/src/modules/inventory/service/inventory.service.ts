import * as _ from "lodash";
import * as Boom from "boom";
import * as msg from "../../../msg/index.msg";
import { Promise } from "bluebird";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { User } from "modules/supplier/model/user.interface";

export class InventoryService {
  private commonDbService: Service.commonDbService;
  private inventoryDbService: Service.inventoryDbService;
  private redis: RedisService;

  constructor() {
    this.commonDbService = new Service.CommonDbService();
    this.inventoryDbService = new Service.InventoryDbService();
    this.redis = new RedisService();

  }

  /**
   * @description Calls the checkSkuStatus method of eo4u_core"s commonDbService.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   * 
   * @param       server - server instance
   * @param       request - HTTP request object
   * 
   * @returns     {Promise}
   * @memberof    InventoryService
   */
  public async checkSkuAvailability(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.inventoryDbService.checkSkuStatus(
        data, userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the updateInventory method of eo4u_core"s inventoryDbService.
   *              It returns updated inventory array from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    InventoryService
   */
  public async updateInventory(server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = request.body;
      properties["uid"] = request.params.uid;
      properties["modified_by"] = request.params.uid;
      properties["modified_at"] = new Date().toISOString();
      const result = await this.inventoryDbService.updateInventory(
        properties,
        properties.label
        , userData);
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the getInventory method of eo4u_core"s inventoryDbService.
   *              It returns updated user from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    InventoryService
   */

  public async getInventory(server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const properties = {
        uid: request.query.uid
      };
      const result = await this.inventoryDbService.getInventory(properties, request.query.label, userData);
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the getUserEoHealthWarning method of eo4u_core"s inventoryDbService.
   *
   * @since       1.0.6
   * @access      public
   * @author      Devendra Gaud
   * 
   * @param       server - server instance
   * @param       request - HTTP request object
   * 
   * @returns     {Promise}
   * @memberof    InventoryService
   */

  public async checkEoHealthCaution(server: any, request: any): Promise<string[]> {
    const eoName = request.query.eoName;
    const uid = request.query.uid;
    const genusSpecie = request.query.genusSpecie;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.inventoryDbService.getUserEoHealthWarning(
        uid, eoName, genusSpecie, userData
      );
      return result;
    } catch (error) {
      throw error;
    }
  }


  /**
   * @description Calls the removeInventorySkuRelation method of eo4u_core"s inventoryDbService.
   *              remove relation between user and sku
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param	      request - HTTP request object
   *
   * @returns     {Promise}
   * @memberof    UserService
   */

  public async removeProduct(server: any, request: any): Promise<any> {
    const data = request.body;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const result = await this.inventoryDbService.removeInventorySkuRelation(data, userData);
      return result;
    } catch (error) {
      throw error;
    }
  }

}