import * as fastify from "fastify";
import { EoService } from "../service/eo.service";
import { ErrorMsg, InfoMsg, SuccessMsg } from "../../../msg/index.msg";

export class EoController {
  private eoService: EoService;

  constructor() {
    this.eoService = new EoService();
  }

  /**
   * @description Returns the essential oil
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra
   *
   * @param       server    Instence of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    EoController
   */

  public async getEo(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_EO);
      const eoData = await this.eoService.getEo(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_EO);
      return reply.send(eoData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_EO);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns the blob of eo-image
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instence of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    EoController
   */

  public async getEoImage(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: ""}, InfoMsg.GET_EO_IMAGE);
      const eoImage = await this.eoService.getEoImage(request.params.imageName);
      server.log.info({user: ""}, SuccessMsg.GET_EO_IMAGE);
      return reply.send(eoImage);
    } catch (error) {
      server.log.error({user: ""}, ErrorMsg.GET_EO_IMAGE);
      server.log.error({user: ""}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Returns list of all the essential oil
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instence of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}    reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    EoController
   */

  public async getEoList(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.GET_EO_LIST);
      const offset = Number(request.query.offset);
      const limit = Number(request.query.limit);
      const searchText = request.query.search;
      const filter = request.query.filter ? request.query.filter : "{}";
      const uid = request.query.uid;

      const eoFilter = request.query.eoFilter ? request.query.eoFilter : "{}";

      const sortByAlphaBoolean = request.query.sortByAlphaBoolean ? JSON.parse(request.query.sortByAlphaBoolean) : true;
      const supplierName = request.query.supplierName ? request.query.supplierName : "";

      const eoList = await this.eoService.getEoList(offset, limit, uid, searchText, filter, eoFilter, sortByAlphaBoolean, supplierName, server);
      server.log.info({user: request.req.user.uid}, SuccessMsg.GET_EO_LIST);
      return reply.send(eoList);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.GET_EO_LIST);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Adds essential oil in the database and cache.
   *              and return the added eo
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instence of fastify server.
   * @param       request   HTTP request object
   * 
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * @returns     {Promise}
   * @memberof    EoController
   */
  public async addEo(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.ADD_EO);
      const eoData = await this.eoService.addEo(server, request);
      server.log.info({user: request.req.user.uid}, SuccessMsg.ADD_EO);
      return reply.send(eoData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.ADD_EO);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

  /**
   * @description Update essential oil in the database.
   *              and return the updated eo
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server    Instence of fastify server.
   * @param       request   HTTP request object
   * @param       {fastify.FastifyReply}      reply     HTTP reply onject
   * 
   * @returns     {Promise}
   * @memberof    EoController
   */

  public async updateEo(server: any, request: any, reply: fastify.FastifyReply<any>): Promise<any> {
    try {
      server.log.info({user: request.req.user.uid}, InfoMsg.UPDATE_EO);
      const eoData = await this.eoService.updateEo(request, server);
      server.log.info({user: request.req.user.uid}, SuccessMsg.UPDATE_EO);
      return reply.send(eoData);
    } catch (error) {
      server.log.error({user: request.req.user.uid}, ErrorMsg.UPDATE_EO);
      server.log.error({user: request.req.user.uid}, error.message);
      return reply.send(error);
    }
  }

}
