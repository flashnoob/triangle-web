import * as boom from "boom";
import * as getStream from "into-stream";
import * as gm from "gm";
import * as urlHttpClient from "urllib";
import * as uuidv4 from "uuid/v4";
import { Env } from "../../../configure-environment";
import { HttpClientHelper } from "../../../services/http-client-helper";
import { IENVCONFIG } from "../../../interface/config.interface";
import { RedisService } from "../../../services/redis.service";
import { Service } from "eo4u_core";
import { User } from "modules/supplier/model/user.interface";
import {
  BlobServiceClient,
  ContainerClient,
  newPipeline,
  Pipeline,
  StorageSharedKeyCredential,
  BlobUploadCommonResponse,
} from "@azure/storage-blob";

export class EoService {
  private config: IENVCONFIG;
  private redis: RedisService;
  private commonDbService: Service.commonDbService;
  private eoDbService: Service.eoDbService;
  private sharedKeyCredential: StorageSharedKeyCredential;
  private pipeline: Pipeline;
  private blobServiceClient: BlobServiceClient;
  private containerClient: ContainerClient;
  private httpHelper: HttpClientHelper;
  private im: any;
  constructor() {
    this.config = Env.Instance.Config;
    this.commonDbService = new Service.CommonDbService();
    this.redis = new RedisService();
    this.eoDbService = new Service.EoDbService();
    this.im = gm.subClass({ imageMagick: true });
    this.sharedKeyCredential = new StorageSharedKeyCredential(
      this.config.STORAGE["AZURE_STORAGE_ACCOUNT_NAME"],
      this.config.STORAGE["AZURE_STORAGE_ACCOUNT_ACCESS_KEY"]
    );
    this.pipeline = newPipeline(this.sharedKeyCredential);
    this.blobServiceClient = new BlobServiceClient(
      this.config.STORAGE["AZURE_STORAGE_URL"],
      this.pipeline
    );
    this.containerClient = this.blobServiceClient.getContainerClient(
      this.config.STORAGE["AZURE_STORAGE_EO_IMAGE_CONTAINER_NAME"]
    );
    this.httpHelper = new HttpClientHelper();
  }

  /**
   * @description Calls the querySelector method of eo4u_core's commonDbService.
   *              filter the skus and rearrange them with their suppliers
   *              It returns  the essential oil from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       {string} id 	- object id of essential oil
   * @param       {string} label - label of essential oil
   * @param 	    server 		- server instance
   * @param 	    request 		- request instance
   *
   * @returns     {Promise}
   * @memberof    EoService
   */
  public async getEo(server: any, request: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);

      const nodeObject = {
        object_id: request.query.id,
        uid:userData.uid,
        countryCode:request.query.countryCode,
        filteredSupplier: request.query.supplier ? request.query.supplier : ""
      };
      const result = await this.eoDbService.getEo(nodeObject, "EO", userData);
      const eoObject = result["eo"];
      const shopifySuppliers = result["shopifySuppliers"];
      const woocomSuppliers = result["woocomSuppliers"];
      if (eoObject.productId) {
        await this.fetchProductSkusFromStore(eoObject.productId, eoObject, shopifySuppliers, result["shopifySkus"], request);
      }
      if (eoObject.woocomId) {
        await this.fetchProductSkusFromStore(eoObject.woocomId, eoObject, woocomSuppliers, result["woocommerceSkus"], request);
      }
      eoObject["supplierNames"] =
        eoObject.skus.length > 0
          ? Array.from(
            new Set(eoObject.skus.map((element: { supplierName: any; }) => element.supplierName))
          )
          : [];
      eoObject["supplierCollection"] = {};
      for (const i of eoObject.supplierNames) {
        eoObject.supplierCollection[`${i}`] = eoObject.skus
          .map((element: { supplierName: string; skuPrice: any; skuSize: any; skuNumber: any; skuId:string, labels:string, percentDiscount:string }) => {
            if (element.supplierName === `${i}`) {
              return {
                price: element.skuPrice,
                size: element.skuSize,
                skuNumber: element.skuNumber,
                id:element.skuId,
                labels: element.labels,
                discount:element.percentDiscount
              };
            }
          })
          .filter((defined: any) => defined !== undefined);
      }
      delete eoObject.skus;
      eoObject.blendsWellWith =
        eoObject.blendsWellWith.length === 0
          ? eoObject.blendsWellWith
          : eoObject.blendsWellWith[0]
            .split(/\,\s|\;and\s|and\s|\;/)
            .map((el: string) => el.trim());
      eoObject.storage = eoObject.storage.length === 0 ? eoObject.storage : eoObject.storage[0].split(/\,\s|\sand\s/).map(el => el.trim());
      const basicInfo = eoObject.basicInformation;
      basicInfo.cultivationCountries = basicInfo.cultivationCountries ? basicInfo.cultivationCountries.split(";") : [];
      basicInfo.nativeCountries = basicInfo.nativeCountries ? basicInfo.nativeCountries.split(";") : [];
      basicInfo.oilDescription = basicInfo.oilDescription ? basicInfo.oilDescription.split(";") : [];
      const coRecommendUses = eoObject.CORecommendUses;
      coRecommendUses.properties = coRecommendUses.properties ? coRecommendUses.properties.split(";") : [];
      coRecommendUses.uses = coRecommendUses.uses ? coRecommendUses.uses.split(";") : [];
      coRecommendUses.formulation = coRecommendUses.formulation ? coRecommendUses.formulation.split(";") : [];
      coRecommendUses.skinTypes = coRecommendUses.skinTypes ? coRecommendUses.skinTypes.split(";") : [];
      const recommendedUses =
        eoObject.primaryUses.length > 0
          ? Array.from(
            new Set(eoObject.primaryUses.map((element: { recommendedUse: any; }) => element.recommendedUse))
          )
          : [];
      eoObject["recommendedUses"] = [];
      for (const use of recommendedUses) {
        const subrecommendedUses = eoObject.primaryUses.filter((element) =>  element.recommendedUse === `${use}`)
        .map((recomUse) => recomUse.subrecommendedUse);
        eoObject["recommendedUses"].push({
          recommendedUse: use,
          subrecommendedUses,
        });
      }
      return eoObject;
    } catch (error) {
      throw error;
    }
  }


  /**
   * @description Fetch product skus based on store type and suppliers
   *
   * @since       1.2.4
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       {number} productId 	- from where to skip the items
   * @param	      storeSuppliers   	- limit of items to be return
   * @param 	    storeSkus 		- user-id of the user
   * @param 	    request 	- stringify object
   * @param 	    server 			- server instance
   *
   * @returns     {Promise}
   * @memberof    EoService
   */

  public async fetchProductSkusFromStore(productId:string, eo:any, storeSuppliers:any, storeSkus:any, request:any): Promise<any> {
    const requestData = {
      productId
    };
    const authorizationKey = { "authorization" : request.headers["authorization"]};
    for (const supplier of storeSuppliers) {
    requestData["supplierId"] = supplier["supplier"];
    requestData["availableSkus"] = storeSkus;
    try {
      const shopifySkus = await this.httpHelper.requestConnector("GET", "get-skus", authorizationKey, requestData);
      eo.skus.push(...JSON.parse(shopifySkus));
      } catch (error) {
        throw error;
      }
    }

  }


  /**
   * @description Calls the querySelector method of eo4u_core's commonDbService.
   *              It returns  the essential oil list from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       {numbrer} offset 	- from where to skip the items
   * @param	      {number} limit   	- limit of items to be return
   * @param 	    {string} uid 		- user-id of the user
   * @param 	    {string} filter 	- stringify object
   * @param 	    server 			- server instance
   *
   * @returns     {Promise}
   * @memberof    EoService
   */

  public async getEoList(offset: number, limit: number, uid: string, searchText: string, filter: string, eoFilter: string, sortByAlphaBoolean: boolean, supplierName: string, server: any): Promise<any> {
    try {
      const userData: User = await this.redis.get(server, uid);
      const properties = {
        offset,
        limit,
        uid,
        searchText: searchText ? searchText : "",
        filter,
        eoFilter,
        sortByAlphaBoolean,
        supplierName
        // userData
      };
      const {eoList, eoCount} = await this.eoDbService.getEoList(
        properties,
        "EO"
        , userData
      );

      if (userData.role !== "SUPER_ADMIN" && userData.role !== "ADMIN") {
        for (const eo of eoList) {
          eo.userHealth = eo.userHealth.join(";");
        }
        return eoList.filter(eo =>eo.status === "active" || eo.status === null);
      }
      return {eoList, eoCount};
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the querySelector method of eo4u_core's commonDbService.
   *              It returns the added essential oil from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   *
   * @param       server - server instance
   * @param 	    request - request instance
   *
   * @returns     {Promise}
   * @memberof    EoService
   */
  public async addEo(server: any, request: any): Promise<any> {
    const data = request.body;
    const eoObjectId = uuidv4();
    const imageName = eoObjectId + ".jpg";
    try {

      const userData: User = await this.redis.get(server, request.req.user.uid);
      const label = data.label;
      const properties = JSON.parse(data.eoInfo);
      properties["createdAt"] = new Date().toISOString();
      properties["objectId"] = eoObjectId;
      properties["image"] = imageName;
      const result = await this.eoDbService.addEo(properties, label, userData);
      const imageData = await this.uploadImageToBlob(request.file, imageName);
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the updateEo method of eo4u_core's eoDbService.
   *              It returns  the updated essential oil from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Devendra Gaud
   * 
   * @param       request - request instance
   * @param 	    server  - server instance
   *
   * @returns     {Promise}
   * @memberof    EoService
   */

  public async updateEo(request: any, server: any): Promise<any> {
    const data = request.body;
    try {
      const userData: User = await this.redis.get(server, request.req.user.uid);
      const label = data.label;
      const properties = JSON.parse(data.eoInfo);
      properties["modifiedAt"] = new Date().toISOString();
      const result = await this.eoDbService.updateEo(properties, label, userData);
      if (request.file) {
      const imageData = await this.uploadImageToBlob(request.file, properties.image);
      }
      return result;
    } catch (error) {
      throw error;
    }
  }

  /**
   * @description Calls the querySelector method of eo4u_core's commonDbService.
   *              It returns the blob of eo-image from the database.
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   *
   * @param       {string} imageId - name of eo
   *
   * @returns     {Promise}
   * @memberof    UserService
   */
  public async getEoImage(imageId: string): Promise<any> {
    if (imageId !== "NA") {
      imageId = imageId.includes(".") ? imageId : imageId + ".jpg";
      try {
        const blockBlobClient = await this.containerClient.getBlockBlobClient(
          imageId
        );
        const downloadBlockBlobResponse = await blockBlobClient.download(0);
        return downloadBlockBlobResponse["readableStreamBody"];
      } catch (error) {
        throw error;
      }
    } else {
      return imageId;
    }
  }

  /**
   * @description Stores image data in azure blob storage.
   *
   * @since       1.0.0
   * @access      public
   * @author      Mohit Sharma(mhtsharma)
   * @param       any
   *
   * @returns  {Promise}
   * @memberof UserService
   */
  public async uploadImageToBlob(imgData: any, eoId:string): Promise<any> {
    return new Promise((resolve, reject) => {
      this.im(imgData.buffer, "img.jpg")
        .resize(720, 1280)
        .toBuffer("jpg", async (err, buffer) => {
          try {
            if (err) {
              reject(err);
            }
            const stream = getStream(buffer);
            const blockBlobClient = await this.containerClient.getBlockBlobClient(
              eoId
            );
            const result = await blockBlobClient.uploadStream(
              stream,
              buffer.length,
              20,
              { blobHTTPHeaders: { blobContentType: "image/jpeg" } }
            );
            resolve(result);
          } catch (error) {
            reject(error);
          }
        });
    });
  }

}
