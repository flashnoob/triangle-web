import * as fastifyPlugin from "fastify-plugin";
import multer from "fastify-multer";
import { EoController } from "../controller/eo.controller";
const upload = multer();

export default fastifyPlugin(
  async (server, opts, next) => {
    const eoController = new EoController();

    /**
     * @description This route returns the eo by object_id.
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       get-eo
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/get-eo",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "pass the object_id to retrieve the essential oil details",
        tags: ["EO"],
        summary: "API to get essential oil",
        querystring: {
          type: "object",
          required: ["id", "countryCode"],
          properties:{
            id: {
              type: "string",
              description: "eo object-id",
              minLength:30,
              maxLength:50
            },
            supplier: {
              type: "string",
              description: "supplier",
            },
            uid: {
              type: "string",
              description: "user's uid",
              minLength:28,
              maxLength:28,
            },
            countryCode:{
              type:"string",
              description:"currency code",
              minLength:3,
              maxLength:3,
            }
          }
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await eoController.getEo(server, request, reply);
      },
    });

    /**
     * @description This route returns image blob of imageName from azure.
     *
     * @since       1.0.0
     * @author      Devendra
     *
     * @request     GET
     * @route       get-eo-image/:imageName
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/get-eo-image/:imageName",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "get image from azure",
        tags: ["EO"],
        summary: "API to get image blob",
        params: {
          type:"object",
          required:["imageName"],
          properties:{
            imageName: {
              type: "string",
              description: "eo-image name without extension JPG is default extension",
              value:"SEO8",
              minLength:1,
              maxLength:100
            },
          }
        },
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
        await eoController.getEoImage(server, request, reply);
      },
    });

    /**
     * @description This route adds eo in the database.
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     POST
     * @route       add-eo/
     * @memberof    fastifyPlugin
     */
    server.route({
      url: "/api/add-eo",
      method: ["POST"],
      schema: {
        description: "Add a new essential oil",
        summary: "API to insert new essential oil",
        consumes: [ "multipart/form-data", "application/json" ],
        tags: ["EO"],
        body: {
          type: "object",
          required: ["label", "eoInfo"],
          properties: {
            label: { type: "string" },
            eoInfo: {
              type: "string",
              // required: ["createdBy", "eoType", "image", "healthConditions", "safetyInformations", "name", "storage", "preparation", "reference", "genusOrSpecie", "recommeneduse", "origin", "howToUse"],
              // properties: {
              //   createdBy: {type: "string", example: "8VSsjze8luSlvmvV9tccYfEJEd82"},
              //   eoType: { type: "string", example:"Single" },
              //   image: { type: "string", example:"SEO8" },
              //   healthConditions: { type: "string" , example:"23;27"},
              //   safetyInformations: { type: "string", example:"N1;N2;N3" },
              //   name: { type: "string", example:"Bergamot" },
              //   storage: { type: "string", example:"1" },
              //   preparation: { type: "string", example:"1" },
              //   reference: { type: "string", example:"B1" },
              //   genusOrSpecie: { type: "string", example:"21" },
              //   recommeneduse: { type: "string", example:"6" },
              //   origin: { type: "string", example:"10" },
              //   howToUse: { type: "string", example:"6;5;10" },
              // },
            },
          },
        },
      },
      preValidation: upload.single("eoImage"),
      handler: async (request, reply) => {
        await eoController.addEo(server, request, reply);
      },
    });

    /**
     * @description This route returns list of all the eo.
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     GET
     * @route       get-all-eo
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/get-all-eo",
      logLevel: "warn",
      method: ["GET"],
      schema: {
        description: "retrieve list of all essential oils",
        tags: ["EO"],
        summary: "API to get EO(s)",
        querystring:{
          type: "object",
          required: ["limit", "offset", "uid"],
          properties: {
            limit: {
              type: "number",
              description: "limit",
              maxLength:2,
              minimum:0,
              value:10
            },
            offset: {
              type: "number",
              description: "offset",
              minimum:0,
              value:0
            },
            uid: {
              type: "string",
              description: "unique-id",
              minLength:28,
              maxLength:28,
            },
            search: {
              type: "string",
              description: "search text",
            },
            filter: {
              type: "string",
              description: "Stringify filter object",
            },
            eoFilter: {
              type: "string",
              description: "Stringify filter object",
            },
            sortByAlphaBoolean: {
              type: "string",
              description: "sorting key",
              enum: ["true", "false"]
            },
            supplierName: {
              type: "string",
              description: "sorting key",
              value: "Nascents"
            },
        }},
        response: {
          201: {
            description: "Successful response",
            type: "object",
            properties: {
              hello: { type: "string" },
            },
          },
        },
        security: [
          {
            apiKey: [],
          },
        ],
      },
      handler: async (request, reply) => {
       await eoController.getEoList(server, request, reply);
      },
    });

    /**
     * @description This update the eo by object_id.
     *
     * @since       1.0.0
     * @author      Devendra Gaud
     *
     * @request     PUT
     * @route       /update-eo/:object_id
     * @memberof    fastifyPlugin
     */

    server.route({
      url: "/api/update-eo",
      logLevel: "warn",
      method: ["PUT"],
      schema: {
        description: "update the info of essential oil of requested object_id",
        tags: ["EO"],
        consumes: [ "multipart/form-data", "application/json" ],
        summary: "API enpoint to update eo detail",
        body: {
          type: "object",
          required: ["label", "eoInfo"],
          properties: {
            label: { type: "string" },
            eoInfo: {
              type: "string",
              // required: ["objectId", "modifiedBy", "eoType", "image", "healthConditions", "safetyInformations", "name", "storage", "preparation", "reference", "genusOrSpecie", "recommeneduse", "origin", "howToUse"],
              // properties: {
              //   objectId: { type: "string", example:"b69fb56b-d51e-436f-8f14-f9885a5e37eb"},
              //   modifiedBy: {type: "string", example: "8VSsjze8luSlvmvV9tccYfEJEd82"},
              //   eoType: { type: "string", example:"Single" },
              //   image: { type: "string", example:"SEO8" },
              //   healthConditions: { type: "string" , example:"23;27"},
              //   safetyInformations: { type: "string", example:"N1;N2;N3"},
              //   name: { type: "string", example:"Bergamot" },
              //   storage: { type: "string", example:"1" },
              //   preparation: { type: "string", example:"1" },
              //   reference: { type: "string", example:"B1" },
              //   genusOrSpecie: { type: "string", example:"21" },
              //   recommeneduse: { type: "string", example:"6" },
              //   origin: { type: "string", example:"10" },
              //   howToUse: { type: "string", example:"6;5;10" },
              // },
            },
          },
        },
      },
      preValidation: upload.single("eoImage"),
      handler: async (request, reply) => {
        await eoController.updateEo(server, request, reply);
      },
    });
    next();
  },
  {
    fastify: "2.x",
    name: "eo-plugin",
    decorators: {
      fastify: [],
      reply: [],
    },
    dependencies: ["fastify-redis", "fastify-swagger"],
  }
);
