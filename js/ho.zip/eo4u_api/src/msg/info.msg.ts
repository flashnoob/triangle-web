export class InfoMsg {
  public static SERVER_START = "Server is Starting...";
  public static DB_CONNECTION = "Database connection is statrted.";
  public static ENV_CONFIG = "Environment is being configured.";
  public static GET_EO = "Get EO request recieved.";
  public static GET_EO_IMAGE = "Get EO image request recieved.";
  public static GET_EO_LIST = "Get EO list request recieved.";
  public static ADD_EO = "Add EO list request recieved.";
  public static UPDATE_EO = "Update EO list request recieved.";
  public static GET_USER = "Get user request recieved.";
  public static GET_USER_IMAGE = "Get user image request recieved.";
  public static GET_USER_LIST = "Get user list request recieved.";
  public static GET_RELATIVE_LIST = "Get relative list request recieved.";
  public static ADD_USER = "Add user request recieved.";
  public static GET_ACCOUNT_PROVIDERS = "Get user account providers request recieved";

  public static ADD_RELATIVE = "Add relative request recieved.";
  public static UPDATE_USER = "Update user list request recieved.";
  public static UPDATE_FAMILY_MEMBER = "Update family member request recieved.";
  public static REMOVE_RELATION = "Remove relation request recieved.";

  public static ADD_PRODUCT = "Add product request recieved.";
  public static REMOVE_PRODUCT = "Remove product request recieved.";
  public static CHECK_SKU_STATUS = "Check sku status request recieved.";
  public static REMOVE_SKU_STATUS = "Check sku status request recieved.";
  public static GET_CART_PRODUCTS = "Get cart products request recieved.";
  public static PLACE_ORDER = "Place order request recieved";
  public static UPDATE_ORDER_STATUS = "Update order-status request recieved";

  public static ADD_TO_INVENTORY = "Add to inventory request recieved.";
  public static GET_INVENTORY = "Get inventory products request recieved.";
  public static GET_HEALTH_CONDITIONS = "Get health conditions request recieved.";
  public static GET_FILTER_OBJECT = "Get filtered object request recieved.";

  public static ADD_WISHLIST = "Add wishlist request recieved.";
  public static REMOVE_WISHLIST = "Remove wishlist request recieved.";
  public static GET_WISHLIST = "Get wishlist request recieved.";

  public static ADD_SUPPLIER = "Add supplier request recieved.";
  public static ADD_SUPPLIER_ADMIN = "Add supplier admin request recieved.";
  public static GET_ADMIN = "Get admin request recieved.";
  public static GET_SUPPLIER = "Get supplier request recieved.";
  public static GET_SUPPLIER_LIST = "Get supplier list request recieved.";
  public static GET_META_DATA = "Get metadata request recieved.";
  public static GET_USERS_LIST = "Get all user list request recieved.";
  public static ADD_SKU = "Add Sku request recieved";
  public static ADD_SKU_DISCOUNT = "Add Sku Discount request recieved";

  public static UPDATE_ADDRESS = "update address request recieved.";
  public static GET_SKU_HEALTH_CAUTION = "get sku health caution request recieved.";
  public static GET_EO_FILTER_OBJECT = "get  EO filter list request recieved.";
  public static CHECK_MEMBERSHIP = "check user memebership request recieved";

  public static UPDATE_UNITS = "Update units request recieved.";
  public static CHECK_SKU_INVENTORY = "Check sku in inventory request recieved";

  public static SWAGGER_LOGIN = "Swagger user login request recieved.";
  public static UPDATE_USER_PROPERTIES = "update user properties request recieved.";
  public static CREATE_PAYMENT_INTENT = " Create payment intent in Stripe request recieved.";
  public static GET_CUSTOMER_SOURCE_LIST = "Get customer source request recieved.";
  public static ADD_CUSTOMER = "Add customer in stripe request recieved.";
  public static ADD_CUSTOMER_SOURCE = "Add customer source in stripe request recieved.";
  public static UPDATE_USER_MEMBERSHIP= "update user membership request recieved.";

  public static DISABLE_USER_BY_UID  = "Disable user by superadmin request recieved.";
  public static REMOVE_USER_BY_UID  = "Remove user by superadmin request recieved.";
  public static UPDATE_USER_BY_UID  = "Update user by superadmin request recieved.";
  public static GET_SERVER_LOGS  = "Get server logs request recieved.";
  public static GET_EO_DATA_LIST = "Get Eo data list request recieved";
  public static DISABLE_EO =  "Disable EO request recieved";
  public static GET_EO_NODE = "Get Eo-node details request recieved";

  public static UPDATE_PRODUCT_REVIEW = "Update Product Review request recieved.";
  public static ADD_PRODUCT_REVIEW = "Add Product Review request recieved.";
  public static GET_PRODUCT_REVIEW = "Get Product Review request recieved.";
  public static GET_ALL_PRODUCT_REVIEW = "Get  Product`s Whole Reviews request recieved.";
}
