export class SuccessMsg {
    public static SERVER_START = "Server started successfully on the port <<PORT>>.";
    public static DB_CONNECTION = "Database connection established successfully.";
    public static ENV_CONFIG = "Environment configured successfully.";
    public static GET_EO = "Get EO request completed successfully.";
    public static GET_EO_IMAGE = "Get EO image request completed successfully.";
    public static GET_EO_LIST = "Get EO list request completed successfully.";
    public static ADD_EO = "Add EO list request completed successfully.";
    public static UPDATE_EO = "Update EO list request completed successfully.";

    public static GET_USER = "Get user request completed successfully.";
    public static GET_USER_IMAGE = "Get user image request completed successfully.";
    public static GET_USER_LIST = "Get user list request completed successfully.";
    public static GET_RELATIVE_LIST = "Get relative list request completed successfully.";
    public static ADD_USER = "Add user request completed successfully.";
    public static GET_ACCOUNT_PROVIDERS = "Get account providers request completed successfully";


    public static ADD_RELATIVE = "Add relative request completed successfully.";
    public static UPDATE_USER = "Update user request completed successfully.";
    public static UPDATE_FAMILY_MEMBER = "Update family member request completed successfully.";
    public static REMOVE_RELATION = "Remove relation request completed successfully.";


    public static ADD_PRODUCT = "Add product request completed successfully.";
    public static REMOVE_PRODUCT = "Remove product request completed successfully.";
    public static GET_CART_PRODUCTS = "Get cart products request completed successfully.";
    public static PLACE_ORDER = "Place order request completed successfully.";
    public static UPDATE_ORDER_STATUS = "Update order-status request completed successfully";


    public static ADD_TO_INVENTORY = "Add to inventory request completed successfully.";
    public static GET_INVENTORY = "Get inventory request completed successfully.";
    public static GET_HEALTH_CONDITIONS = "Get health conditions request completed successfully.";
    public static GET_FILTER_OBJECT = "Get filter object request completed successfully.";
    public static ADD_WISHLIST = "Add wishlist request completed successfully.";
    public static REMOVE_WISHLIST = "Remove wishlist request completed successfully.";
    public static GET_WISHLIST = "Get wishlist request completed successfully.";
    public static CHECK_MEMBERSHIP = "Check user membership request completed successfully";


    public static ADD_SUPPLIER = "Add supplier request completed successfully.";
    public static ADD_SUPPLIER_ADMIN = "Add supplier admin request completed successfully.";
    public static GET_ADMIN = "Get admin request completed successfully.";
    public static GET_SUPPLIER = "Get supplier request completed successfully.";
    public static GET_SUPPLIER_LIST = "Get supplier list request completed successfully.";
    public static GET_META_DATA = "Get metadata of user request completed successfully.";
    public static GET_USERS_LIST = "Get all user list request completed successfully.";
    public static UPDATE_ADDRESS = "update address request completed successfully.";
    public static GET_SKU_HEALTH_CAUTION = "get sku health caution request completed successfully.";
    public static GET_EO_FILTER_OBJECT = "get EO filter list request completed successfully.";
    public static ADD_SKU = "Add SKU request completed successfully";
    public static ADD_SKU_DISCOUNT = "Add SKU discount request completed successfully";

    public static UPDATE_UNITS = "Updating units of cart product request completed successfully.";
    public static CHECK_SKU_INVENTORY = "Checking sku in inventory request completed successfully.";
    public static SWAGGER_LOGIN = "Swagger user login request completed successfully.";
    public static UPDATE_USER_PROPERTIES = "update user properties request completed successfully.";
    public static CREATE_PAYMENT_INTENT = " Create payment intent in Stripe request completed successfully."
    public static GET_CUSTOMER_SOURCE_LIST = "Get customer source request completed successfully."
    public static ADD_CUSTOMER = "Add customer in stripe request completed successfully.";
    public static ADD_CUSTOMER_SOURCE = "Add customer source in stripe request completed successfully.";
    public static UPDATE_USER_MEMBERSHIP = "update user membership request completed successfully.";
    
    public static DISABLE_USER_BY_UID  = "User disabled successfully by superadmin.";
    public static REMOVE_USER_BY_UID  = "User removed successfully by superadmin.";
    public static UPDATE_USER_BY_UID  = "User updated successfully by superadmin.";
    public static GET_SERVER_LOGS  = "Server Logs returned successfully";
    public static GET_EO_DATA_LIST = "Get Eo data list request completed successfully";
    public static DISABLE_EO =  "EO disabled successfully";
    public static GET_EO_NODE = "Get eo-node details successfully";

    public static UPDATE_PRODUCT_REVIEW = "Update Product Review completed successfully.";
    public static ADD_PRODUCT_REVIEW = "Add Product Review completed successfully.";
    public static GET_PRODUCT_REVIEW = "Get Product Review completed successfully.";
    public static GET_ALL_PRODUCT_REVIEW = "Get Product`s Whole Reviews completed successfully.";

}