export class ErrorMsg {
  public static SERVER_START = "Error while starting the server.";
  public static DB_CONNECTION = "Error While connecting to database.";
  public static ENV_CONFIG = "Error while configuring Environment.";
  public static USER_NOT_FOUND = "User Not Found.";
  public static RELATIVE_NOT_FOUND = "Relative Not Found.";
  public static SUPPLIER_NOT_FOUND = "Supplier Not Found.";
  public static WISHLIST_ADD_ERROR = "Error Adding Wishlist.";
  public static WISHLIST_REMOVE_ERROR = "Error Removing Wishlist.";
  public static WISHLIST_GET_ERROR = "Error Getting Wishlist.";
  public static GET_SUPPLIER_DB = "Error while getting supplier from DB.";
  public static GET_EO = "Error while getting EO.";
  public static GET_EO_IMAGE = "Error while getting EO image.";
  public static GET_EO_LIST = "Error while getting EO list.";
  public static ADD_EO = "Error while adding EO in database.";
  public static UPDATE_EO = "Error while updating EO in database.";
  public static GET_USER = "Error while getting user.";
  public static GET_USER_IMAGE = "Error while getting user image.";
  public static GET_USER_LIST = "Error while getting user list.";
  public static GET_RELATIVE_LIST = "Error while getting relative list.";
  public static ADD_USER = "Error while adding user in database.";
  public static GET_ACCOUNT_PROVIDERS = "Error while getting account providers";


  public static ADD_RELATIVE = "Error while adding relative in database.";
  public static UPDATE_USER = "Error while updating user in database.";
  public static UPDATE_FAMILY_MEMBER = "Error while updating family member in database.";
  public static REMOVE_RELATION = "Error while removing relation in database.";

  public static ADD_PRODUCT = "Error while adding product in database.";
  public static REMOVE_PRODUCT = "Error while removing product in database.";
  public static GET_CART_PRODUCTS = "Error while getting cart products.";
  public static PLACE_ORDER = "Error while placing order.";
  public static UPDATE_ORDER_STATUS = "Error while updating order-status";


  public static ADD_TO_INVENTORY = "Error while adding to inventory in database.";
  public static GET_INVENTORY = "Error while getting inventory.";
  public static GET_HEALTH_CONDITIONS = "Error while getting health condition.";

  public static GET_FILTER_OBJECT = "Error while getting filtered object.";

  public static ADD_WISHLIST = "Error while adding wishlist in database.";
  public static REMOVE_WISHLIST = "Error while removing wishlist in database.";
  public static GET_WISHLIST = "Error while getting wishlist.";

  public static ADD_SUPPLIER = "Error while adding supplier in database.";
  public static ADD_SUPPLIER_ADMIN = "Error while adding supplier admin in database.";
  public static GET_ADMIN = "Error while getting admin from database.";
  public static GET_SUPPLIER = "Error while getting supplier from database.";
  public static GET_SUPPLIER_LIST = "Error while getting supplier's list from database.";
  public static GET_META_DATA = "Error while getting metadata of user from database.";
  public static GET_USERS_LIST = "Error while getting all user's list from database.";
  public static ADD_SKU = "Error while adding sku";
  public static ADD_SKU_DISCOUNT = "Error while adding discount on skus.";

  public static UPDATE_ADDRESS = "Error while updating address in database.";
  public static GET_SKU_HEALTH_CAUTION = "Error while getting health caution related to sku in inventory";
  public static GET_EO_FILTER_OBJECT = "Error while getting EO filter list from database."
  public static UPDATE_UNITS = "Error while updating units of cart product.";
  public static CHECK_SKU_INVENTORY = "Error while checking sku in inventory";
  public static MEMBERSHIP_EXPIRE = "Membersip has been expired";
  public static CHECK_MEMBERSHIP = "Error while checking user membership";

  public static SWAGGER_LOGIN = "Swagger user not found.";
  public static UPDATE_USER_PROPERTIES = "Error while updating user properties.";
  public static CREATE_PAYMENT_INTENT = "Error while creating payment intent in Stripe."
  public static GET_CUSTOMER_SOURCE_LIST = "Error while getting customer source."
  public static ADD_CUSTOMER = "Error while adding customer in stripe.";
  public static ADD_CUSTOMER_SOURCE = "Error while adding customer source in stripe.";
  public static UPDATE_USER_MEMBERSHIP = "Error while updating user membership.";

  public static DISABLE_USER_BY_UID = "Error while removing user using uid by superadmin.";
  public static REMOVE_USER_BY_UID = "Error while removing user using uid by superadmin.";
  public static UPDATE_USER_BY_UID = "Error while updating user using uid by superadmin.";
  public static GET_SERVER_LOGS = "Error while getting server logs.";
  public static GET_EO_DATA_LIST = "Error while getting Eo data list";
  public static DISABLE_EO =  "Error while disabling EO";
  public static GET_EO_NODE = "Error while getting geo-node details";

  public static ADD_PRODUCT_REVIEW = "Error while adding the Product Review.";
  public static UPDATE_PRODUCT_REVIEW = "Error while updating the Product Review.";
  public static GET_PRODUCT_REVIEW = "Error while returning the Product Review.";
  public static GET_ALL_PRODUCT_REVIEW = "Error while returning the Product`s Whole Reviews .";

}

