import * as Boom from "boom";
import * as moment from "moment";
import * as msg from "../msg/index.msg";
import { Service } from "eo4u_core";

export class CheckMembershipService{
    private commonDbService: Service.commonDbService;

    constructor() {
        this.commonDbService = new Service.CommonDbService();
    }

    /** 
     * @description throw error if user membership is expired. Calls updateMembershipStatus method of eo4u_core"s commonDbService.
     *  Returns the updated user-details and store it in the redis.
     * 
     * @since    1.1.3
     * @access   public
     * @author   Devendra Gaud
     * 
     * @param    {any}      server   -Instence of fastify server. 
     * @param    {any}      userData - user-details stored in redis
     * @returns  {Promise<void>}
     * @memberof CheckMembershipService
     */
    public async isMembershipExpired(userData:any): Promise<void> {
      const currentMembershipStatus = moment().diff(userData.membership_expire) >= 0 ? "expire" : "acitve";
      // const currentMembershipStatus = "expire";
      if (currentMembershipStatus === "expire") {
        throw Boom.forbidden(msg.ErrorMsg.MEMBERSHIP_EXPIRE);
      }

    }
}