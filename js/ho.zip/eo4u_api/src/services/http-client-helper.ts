import * as urlHttpClient from "urllib";
import { Env } from "../configure-environment";
import { IENVCONFIG } from "../interface/config.interface";



export class HttpClientHelper {
    private config: IENVCONFIG;
    private options: any;
    private connectorURL: string;

    constructor() {
        this.config = Env.Instance.Config;
        this.connectorURL = `http://${this.config.CON_HOST}:${this.config.CON_PORT}/con/`;
        this.options = {
            dataType: "JSON",
            headers: {
                "Content-Type": "application/json",
                "api-key": "AIzaSyCih_SmFXdmdKLnqjhLXFR-_XGWepwZLJo"
            },
        };
    }

    public async requestConnector(reqMethod: string, uri: string, authorizedHeaders:object, content?: object) {
        try {
            this.options["method"] = reqMethod;
            if (reqMethod === "GET" && content) {
                this.options["data"] = content;
            } else if ((reqMethod === "POST" || reqMethod === "PUT") && content) {
                this.options["content"] = JSON.stringify(content);
            }
            this.options["headers"] = {...this.options["headers"], ...authorizedHeaders};
            this.options["timeout"] = 100000;
            const res = await urlHttpClient.request(
                this.connectorURL + uri,
                this.options
            );
            return res.data.toString();
        } catch (err) {
            return err;
        }
    }
}