import * as msg from "../msg/error.msg";
import { isEmpty } from "lodash";
import { Service } from "eo4u_core";
import Boom = require("boom");

export class RedisService {
    private commonDbService: Service.commonDbService;
    constructor(
    ) {
        this.commonDbService = new Service.CommonDbService();
    }

    /** 
     * @description Returns the value of the key from  redis
     * 
     * @since    1.0.0
     * @access   public
     * @author   Mohit Sharma(mhtsharma.me)
     * 
     * @param    {any}     server    Instance of fastify server. 
     * @param    {string}  key        Key to get value from redis.
     * @returns  {Promise}
     * @memberof RedisService
     */
    public get(server: any, key: string): Promise<any> {

        return new Promise((resolve, reject) => {
            server.redis.get(key, async (error: any, value: string) => {
                if (!value) {
                    try {
                        const supplier: string = await this.getUser(server, key);
                        resolve(JSON.parse(supplier));
                    } catch (error) {
                        reject(error);
                    }
                } else {
                    resolve(JSON.parse(value));
                }
                // error ? reject(error) : resolve(value);
            });
        });
    }

    /** 
     * @description Set the key and value in redis and returns the value
     * 
     * @since    1.0.0
     * @access   public
     * @author   Mohit Sharma(mhtsharma.me)
     * 
     * @param    {any}      server    Instence of fastify server. 
     * @param    {string}   key       Key to bet set in redis.
     * @param    {string}   value     Value to be set in redis.
     * @returns  {Promise<string>}
     * @memberof RedisService
     */
    public set(server: any, key: string, value: any): Promise<string> {

        return new Promise((resolve, reject) => {
            server.redis.set(key, JSON.stringify(value), (error: any) => {
                error ? reject(error) : resolve(value);
            });
        });
    }

    /**
     * @description Calls the querySelector method of eo4u_core"s commonDbService.
     *              It returns the user from the database.
     *
     * @since       1.0.0
     * @access      public
     * @author      Mohit Sharma(mhtsharma)
     *
     * @param       server - instance of server
     * @param       {string} id - userId
     *
     * @returns     {Promise}
     * @memberof    RedisService
     */
    public async getUser(server: any, id: string): Promise<any> {

        return new Promise(async (resolve, reject) => {
            if (!isEmpty(id)) {
                const operation: string = "read";
                const result = await this.commonDbService.querySelector(operation, { uid: id }, "");
                if (!isEmpty(result)) {
                    const savedUser = new Promise((resolve, reject) => {
                        server.redis.set(id, JSON.stringify(result), (error: any) => {
                            error ? reject(error) : resolve(JSON.stringify(result));
                        });
                    });
                    resolve(savedUser);
                }
            } else {
                reject(Boom.forbidden(msg["ErrorMsg"]["USER_NOT_FOUND"]));
            }
        }
        )
    }
}
