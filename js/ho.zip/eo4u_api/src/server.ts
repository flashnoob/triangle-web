import * as _ from "lodash";
import * as admin from "firebase-admin";
import * as fastify from "fastify";
import * as fs from "fs";
import * as msg from "./msg/index.msg";
import * as neo4j from "eo4u_core";
import * as path from "path";
import { commonMiddleware } from "./middleware/common.middleware";
import { Env } from "./configure-environment";
import { PluginRegistery } from "./plugin.registery";
import {
  Http2SecureServer,
  Http2ServerRequest,
  Http2ServerResponse,
} from "http2";
const serviceAccount = require("../config/firebaseconfig.json");

const getDate = () => {
  const date = new Date();
  const dateTimeFormat = new Intl.DateTimeFormat("en", {
    year: "numeric",
    month: "numeric",
    day: "2-digit",
  });
  const [
    { value: month },
    ,
    { value: day },
    ,
    { value: year },
  ] = dateTimeFormat.formatToParts(date);
  return `${day}-${month}-${year}`;
};

const server: fastify.FastifyInstance<
  Http2SecureServer,
  Http2ServerRequest,
  Http2ServerResponse
> = fastify({
  // http2: true,
  // https: {
  //   allowHTTP1: true, // fallback support for HTTP1
  //   key: fs.readFileSync(path.join(__dirname, "..", "https", "server_dev.key")),
  //   cert: fs.readFileSync(
  //     path.join(__dirname, "..", "https", "server_dev.crt")
  //   ),
  // },
  logger: {
    name: "EO4U_api",
    // prettyPrint: true,
    level: "info",
    file: `./logs/${getDate()}.log`, // Will use pino.destination()
  },
  trustProxy: true,
});

let config: any;
const pluginRegistery = new PluginRegistery();

pluginRegistery.registerPlugins(server);

server.addHook("onRequest", commonMiddleware);

const start = async () => {
  try {
    // firebase-admin initialize
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
    });
    config = Env.Instance.Config;
    await server.listen(Number(process.env.PORT) || config['PORT'], config["HOST"]);
    server.swagger();

    await configureDatabase();

    server.log.info(
      { user: "" },
      _.replace(
        msg["SuccessMsg"]["SERVER_START"],
        "<<PORT>>",
        Number(process.env.PORT) || config["PORT"]
      )
    );
    server.blipp();
  } catch (error) {
    server.log.error({ user: "" }, msg["ErrorMsg"]["SERVER_START"] + error);
    process.exit(1);
  }
};

async function configureDatabase() {
  try {
    await neo4j.Database.Instance.configure(config["DB_CONFIG"]);
    server.log.info({ user: "" }, msg["SuccessMsg"]["DB_CONNECTION"]);
  } catch (error) {
    server.log.error({ user: "" }, msg["ErrorMsg"]["DB_CONNECTION"]);
  }
}

process.on("uncaughtException", (error) => {
  server.log.error(error);
});
process.on("unhandledRejection", (error) => {
  server.log.error(error);
});

start();
