export interface IDBCONFIG {
    url: string;
    userName: string;
    password: string;
}

export interface ICACHECONFIG {
    host: string;
    port: number;
}

export interface ISTORAGE {
    AZURE_STORAGE_URL: string;
    AZURE_STORAGE_USER_IMAGE_CONTAINER_NAME: string;
    AZURE_STORAGE_EO_IMAGE_CONTAINER_NAME: string;
    AZURE_STORAGE_ACCOUNT_NAME: string;
    AZURE_STORAGE_ACCOUNT_ACCESS_KEY: string;
}

export interface IENVCONFIG {
    HOST: string;
    PORT: string;
    CON_HOST: string;
    CON_PORT: string;
    DB_CONFIG: IDBCONFIG;
    CACHE_CONFIG: ICACHECONFIG;
    STORAGE: ISTORAGE;
}