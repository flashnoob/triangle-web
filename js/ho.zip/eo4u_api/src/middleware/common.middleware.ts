import { FastifyReply } from "fastify";
import { ServerResponse } from "http";
import fastify = require("fastify");
import admin = require("firebase-admin");


/** 
 * @description check if the request have necessary level of authorization
 * 
 * @since    1.0.0
 * @access   public
 * @author   Sachin kotian
 * 
 * @param    req - request instance
 * @param 	 res - response instance
 * @param 	 next
 * 
 * @returns  {Promise}
 * @memberof commonMiddleware
 */
export async function authorization(req: fastify.FastifyRequest, res: FastifyReply<ServerResponse>): Promise<any> {
  const token = req.headers["authorization"];
  if (!token) {
    res.status(401).send("You must sign in first");
    // return res;
  }
  try {
    const userInfo = await verifyFirebaseJwt(req.headers);
    if (req.headers["api-key"] && req.headers["api-key"] !== "AIzaSyCih_SmFXdmdKLnqjhLXFR-_XGWepwZLJo") {
      res.status(401).send("Unauthorized API-Key");
    }
    req["req"]["user"] = userInfo;
    return ;
  } catch (error) {
    res.status(401).send("Your token is invalid or has expired");
    // return res;
  }
}

/** 
 * @description verify firebase JWT sent in headers 
 * 
 * @since    1.0.0
 * @access   public
 * @author   Sachin kotian
 * 
 * @param    {string} headers header from request
 * 
 * @returns  {Promise}
 * @memberof commonMiddleware
 */
export async function verifyFirebaseJwt(headers: fastify.DefaultHeaders): Promise<admin.auth.DecodedIdToken> {
  try {
    const jwtToken = headers.authorization.split(" ")[1];
    const verifiedToken = await admin.auth().verifyIdToken(jwtToken);
    return verifiedToken;
  } catch (error) {
    throw error;
  }
}

/** 
 * @description verify firebase JWT sent in headers 
 * 
 * @since    1.0.0
 * @access   public
 * @author   Sachin kotian
 * 
 * @param    req - request instance
 * @param 	 res - response instance
 * @param 	 next
 * 
 * @returns  {Promise<void>}
 * @memberof commonMiddleware
 */
export async function commonMiddleware(req, res): Promise<void> {
  try {
    if (req["raw"].hasOwnProperty("originalUrl")) {
      if (req["raw"]["originalUrl"].includes("/docs") || req["raw"]["originalUrl"].includes("image") || req["raw"]["originalUrl"].includes("swagger-login") || req["raw"]["originalUrl"].includes("providers")) {
        return ;
      } else {
        await authorization(req, res);
      }
    }
  } catch (err) {
    res.status(400).send("You must sign in first");
    // return res;
  }
}