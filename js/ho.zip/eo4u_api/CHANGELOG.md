# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0] - 2020-04-06
### Added
- NA
### Updated
- NA
### Removed
- NA
### Fixed
- NA

## [1.0.1] - 2020-04-13
### Added
- Search functionality
- Get users list
- set suppliers list
- Add supplier
- Add admin
### Updated
- User profile
- Add relative functionality

## [1.0.2] - 2020-04-20
### Added
- Apply Filter
- Add To Wishlist
- Remove From Wishlist
### Updated
- Add Relative Health Conditions
### Removed
- NA
### Fixed
- Update Relative
- delete Relative

## [1.0.3] - 2020-04-22
### Added
- NA
### Updated
- Error log
- Warning log
- Success log
- get-eo route
### Removed
- NA
### Fixed
- Method not found error.

## [1.0.4] - 2020-04-27
### Added
- NA
### Updated
- String formatter for eo-names seperated by either of these - ";","and",","
- Success, warning and error messages updated in controllers.
- get-eo route updated from route-params to query-params.
### Removed
- NA
### Fixed
- NA


## [1.0.5] - 2020-05-04
### Added
- Route for updating address
- Route to add sku in inventory
- Route to check if product already in inventory
### Updated
- NA
### Removed
- NA
### Fixed
- NA

## [1.0.6] - 2020-05-11
### Added
- cart, inventory and relatives module
- route to added to healht caution for eo in inventory
### Updated
- update-address route moved from eo to user module
- cart, inventory and relatives related route moved from user to respective modules
### Removed
- NA
### Fixed
- NA

## [1.0.7] - 2020-05-18
### Added
- NA
### Updated
- common.service replaced from inventory.service in inventory module
- common.service replaced from relative.service in relative module
- common.service replaced from wishlist.service in wishlist module
- common.service replaced from eo.service in eo module
### Removed
- NA
### Fixed
- NA

## [1.1.0] - 2020-05-18
### Added
- route added to update units of eo in cart
### Updated
- success, warning and error messages updated
### Removed
- NA
### Fixed
- NA

## [1.1.1] - 2020-06-01
### Added
- Jasmine as Testing Lib
- Report Generator
- Acceptance test cases
- Helmet package
### Updated
- Testing Script
### Removed
- NA
### Fixed
- NA

## [1.1.2] - 2020-06-08
### Added
- Jasmine as Testing Lib
- Report Generator
- Acceptance test cases
- Helmet package
### Updated
- Testing Script
### Removed
- NA
### Fixed
- NA

## [1.1.3] - 2020-06-15
### Added
- /check-user-membership endpoint to check user membership is active or not
### Updated
- NA
### Removed
- NA
### Fixed
- NA

## [1.1.4] - 2020-06-29
### Added
- super-admin module
- super-admin can update,delete and disable user
- route to get server logs with limit, offset and search filter.
- payment module
- routes added for secure payment
### Updated
- NA
### Removed
- NA
### Fixed
- NA

## [1.1.5] - 2020-07-04
### Added
- Endpoint to Add Sku.
- Environment configuration updated with connector modules host and port.
### Updated
- Endpoint /get-eo updated with shopify-skus. 
### Removed
- NA
### Fixed
- NA

## [1.1.6] - 2020-07-12
### Added
- Endpoint to Add discount on all sku of single product of a supplier.
- Endpoint to add review 
### Updated
- Params updated with supplier-id for get-sku request.
### Removed
- NA
### Fixed
- NA

## [1.1.7] - 2020-07-20
### Added
- Endpoint to get dataset for eo-form
- Endpoint to flag eo as deleted
### Updated
- Endpoint to add eo
### Removed
- NA
### Fixed
- NA

## [1.1.8] - 2020-07-26
### Added
- Endpoint to get-eo return the eo with ids
- Endpoint to delete eo
- Image Upload in add-eo, update-eo
### Updated
- Endpoint to update eo
- Deployment config
- Sorting implemented in getSupplierList, getUsersList
- QueryParams updated in request to fetch shopify skus from connector.
### Removed
- NA
### Fixed
- NA

## [1.1.9] - 2020-08-03
### Added
- HTTP2 Protocol
- fastify-rate-limit and ioredis
- UTs for cart-controller and cart-service
- "repository" in package.json
### Updated
- fastify version
### Removed
- NA
### Fixed
- NA

## [1.1.10] - 2020-08-10
### Added
- UTs in inventory module
- UTs in eo module
### Updated
- NA
### Removed
- NA
### Fixed
- NA

## [1.2.0] - 2020-08-16
### Added
- Prefix "api/"
- Azure Pipelines
- UTs for wishlist and relative modules
### Updated
- get-cart-products's response updated with available discount for cart items
### Removed
- NA
### Fixed
- Middleware response fixed in case of expired token or no token at all in request.

## [1.2.1] - 2020-08-19
### Added
- NA
### Updated
- Middleware changes rollback
### Removed
- NA
### Fixed
- NA

## [1.2.2] - 2020-08-24
### Added
- UTs for super-admin, supplier and user modules
### Updated
- HTTP helper updated with headers(api-key)
- Error handling implemented in health-conditions and eo-filter
### Removed
- NA
### Fixed
- Middleware fixed with calling twice route handler

## [1.2.3] - 2020-09-05
### Added
- NA
### Updated
- NA
### Removed
- NA
### Fixed
- NA

## [1.2.4] - 2020-11-07
### Added
- order-module
### Updated
- route-schema
- get-eo for woocommerce supplier
### Removed
- NA
### Fixed
- NA

## [1.2.5] - 2020-11-12
### Added
- NA
### Updated
- update order status
### Removed
- NA
### Fixed
- NA


## [1.2.6] - 2020-11-25
### Added
- NA
### Updated
- NA
### Removed
- NA
### Fixed
- NA

## [1.2.7] - 2020-11-26
### Added
- NA
### Updated
- Request timeout for connector, from 10 to 30 sec
### Removed
- NA
### Fixed
- NA

## [1.2.8] - 2020-11-26
### Added
- NA
### Updated
- NA
### Removed
- NA
### Fixed
- Connector URL

## [1.2.9] - 2020-12-08
### Added
- NA
### Updated
- request-timeout for connector
### Removed
- NA
### Fixed
- NA

## [1.3.0] - 2020-12-23
### Added
- NA
### Updated
- Get eo request updated with supplier name param
### Removed
- NA
### Fixed
- NA

## [1.3.1] - 2020-12-30
### Added
- NA
### Updated
- eo4u_core package
### Removed
- NA
### Fixed
- NA

## [1.3.2] - 2021-01-04
### Added
- NA
### Updated
- eo4u_core package
### Removed
- NA
### Fixed
- NA

## [1.3.3] - 2021-01-12
### Added
- NA
### Updated
- eo4u_core package
### Removed
- NA
### Fixed
- NA