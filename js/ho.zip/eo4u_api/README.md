<h1 align="center">EO4U API</h1>
<p align="center">
  <img alt="Version" src="https://img.shields.io/badge/version-1.3.2-blue.svg?cacheSeconds=2592000" />
  <img alt="Version" src="https://img.shields.io/badge/node.js-10.18.0-blue.svg?cacheSeconds=2592000" />
</p>

<p align="center">
  <img alt="Version" src="https://img.shields.io/badge/codestyle-standard-green.svg?cacheSeconds=2592000" />
  <img alt="Version" src="https://img.shields.io/badge/build-passing-green.svg?cacheSeconds=2592000" />
</p>

# Introduction 
An backend application which provide API support to eo4u mobile and web application for the functionality like authentication, EO list, safety and warnings etc.

# Getting Started
Follow the following steps to build/run the application
##	Installation / build process
1. Install the npm dependencies

    ``` npm install ```
2. Run the application

    Unix based OS ```npm run start:dev```
    Windows ```gulp serve```
##	Software dependencies
- [Node.js 10.18.0](https://nodejs.org/ja/blog/release/v10.18.0/)
- [Gulp](https://www.npmjs.com/package/gulp)
##	Latest releases

|Sr. No.|Version   | Release Date|
|-------|----------|-------------|
|     1.|[Previous Versions](https://dev.azure.com/eo4u/EO4U/_git/eo4u_api/tags) | Check tags in azure devops for previous versions.
|    29.|[1.3.0](https://dev.azure.com/eo4u/EO4U/_git/eo4u_api?version=GT1.3.0) |23/12/2020   |
|    30.|[1.3.1](https://dev.azure.com/eo4u/EO4U/_git/eo4u_api?version=GT1.3.1) |30/12/2020   |
|    31.|[1.3.2](https://dev.azure.com/eo4u/EO4U/_git/eo4u_api?version=GT2.3.2) |04/01/2021   |
|    32.|[1.3.3](https://dev.azure.com/eo4u/EO4U/_git/eo4u_api?version=GT2.3.3) |12/01/2021   |


## Dependencies

1. EO4U Web - 1.3.0

2. EO4U Mobile - 1.3.3

3. EO4U Connector - 1.2.9

4. EO4U Core - 1.3.4



##	API references
[EO4U Core]()

## Author
👤 **Mohit Sharma**

👤 **Devendra Gaud**

👤 **Sachin Kotian**



