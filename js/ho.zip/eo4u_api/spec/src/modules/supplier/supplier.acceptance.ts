import { HttpHelper } from "./../../../helpers/http.helper";

describe("supplier acceptance test", () => {
    const httpHelper: HttpHelper = new HttpHelper();
    beforeAll(() => {
    });

    afterAll(() => {
    });

    describe("/add-supplier: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    role: "string",
                    supplier_info: {
                        uid: "string",
                        name: "string",
                        contactNo: "string",
                        birthday: "string",
                        email: "string",
                        address: "string",
                        street1: "string",
                        street2: "string",
                        postalCode: "string",
                        city: "string",
                        state: "string",
                        country: "string",
                        inventorySource: "string",
                        apiKey: "string",
                        apiSecretKey: "string",
                        storeLogo: "string",
                        storeName: "string"
                    }
                };
                result = await httpHelper.request("POST", `/add-supplier`, content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("status code should be 200", () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/add-admin: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    role: "string",
                    supplier: "string",
                    admin_info: {
                        fullName: "string",
                        uid: "string",
                        email: "string",
                        userName: "string"
                    }
                };
                result = await httpHelper.request("POST", `/add-admin`, content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("status code should be 200", () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-admin/id: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const id: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("GET", `/get-admin/${id}`);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-supplier/id: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const id: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("GET", `/get-supplier/${id}`);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-suppliers: ", () => {
        let result: any ={};
        beforeAll(async (done) => {
            try {
                const content = {
                    limit: "string",
                    offset: "string"
                }
                result = await httpHelper.request("GET", `/get-suppliers`, content);
                done(); 
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-metadata: ", () => {
        let result: any ={};
        beforeAll(async (done) => {
            try {
                // const content = {};
                result = await httpHelper.request("GET", `/get-metadata`);
                done(); 
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-userlist: ", () => {
        let result: any ={};
        beforeAll(async (done) => {
            try {
                const content = {
                    limit: "string",
                    offset: "string"
                }
                result = await httpHelper.request("GET", "/get-userlist", content);
                done(); 
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

});