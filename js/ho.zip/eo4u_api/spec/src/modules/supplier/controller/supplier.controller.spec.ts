import { MockReply, MockServer } from "./../../../../helpers/common_mock.helper";
import { SupplierController } from "./../../../../../src/modules/supplier/controller/supplier.controller";

describe("Supplier controller Unit tests:", () => {
    let supplierController: SupplierController;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn:any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockReply = new MockReply();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        supplierController = new SupplierController();
    });


    // TODO: - Error while adding supplier
    // TODO: - SyntaxError: Unexpected token i in JSON at position 352.

    describe("Add supplier", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                supplierData:['{"role":"SUPPLIER","supplier_info":{"name":"Young Living","contactNo":"9292929292","otherContactNo":"9898989898","address":"chjhxx","city":"hkdj","country":"jhkjhkj","postalCode":454545,"inventorySource":"Shopify","apiKey":"4e9bb7e174dbd4bf9ce46773c52bacca","apiSecretKey":"0a8a7793619fdf73f4e2097536dfffdb","storeName":"eo4u","storeLogo":"C:\\\\fakepath\\\\images.jpeg"}}'],
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
            mockRequest["files"] = [];
        });
        it("Add supplier details", async () => {
            spyOn(supplierController["supplierService"], "addSupplier").and.resolveTo({
                address:'123 Drew Street',
                apiKey:'4e9bb7e174dbd4bf9ce46773c52bacca',
                apiSecretKey:'0a8a7793619fdf73f4e2097536dfffdb',
                city:'Mumbai',
                contactNo:'9292929292',
                country:'India',
                created_at:'2020-08-20T11:40:00.930Z',
                inventorySource:'Shopify',
                modified_by:'',
                name:'doTERRA',
                object_id:'b4edf53a-011f-4dc0-9c04-55c00433930d',
                otherContactNo:'9898989898',
                postalCode:400092,
                role:'SUPPLIER',
                storeLogo:'doTERRA',
                storeName:'eo4u'
            })
            await expectAsync(supplierController.addSupplier(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                address:'123 Drew Street',
                apiKey:'4e9bb7e174dbd4bf9ce46773c52bacca',
                apiSecretKey:'0a8a7793619fdf73f4e2097536dfffdb',
                city:'Mumbai',
                contactNo:'9292929292',
                country:'India',
                created_at:'2020-08-20T11:40:00.930Z',
                inventorySource:'Shopify',
                modified_by:'',
                name:'doTERRA',
                object_id:'b4edf53a-011f-4dc0-9c04-55c00433930d',
                otherContactNo:'9898989898',
                postalCode:400092,
                role:'SUPPLIER',
                storeLogo:'doTERRA',
                storeName:'eo4u'
            })
        });
        it("Error while adding supplier", async () => {
            spyOn(supplierController["supplierService"], "addSupplier").and.rejectWith(Promise.reject("Unable to add supplier"));
            await expectAsync(supplierController.addSupplier(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to add supplier");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add supplier admin", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                admin_info:['{"adminAddress":"gjs dsd","adminCity":"Mumbai","adminCountry":"India","adminPostalCode":"400092","email":"user05@gmail.com","password":"12345678","firstName":"User","lastName":"Five"}'],
                role:'ADMIN_USER_NL',
                supplier:'Young Living',
                uid:'u4SNzshIrVS12kaSjwYoMuBNy8B3'
            };
        });
        it("Adding admin supplier", async () => {
            spyOn(supplierController["supplierService"], "addSupplierAdmin").and.resolveTo({
                email:'abcxyz@gmail.com',
                firstName:'Abc',
                lastName:'Xyz',
                role:'ADMIN',
                supplier:'Young Living',
                uid:'I293nw3YIAdITXodhpU7MTeCEg22'
            })
            await expectAsync(supplierController.addAdmin(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                email:'abcxyz@gmail.com',
                firstName:'Abc',
                lastName:'Xyz',
                role:'ADMIN',
                supplier:'Young Living',
                uid:'I293nw3YIAdITXodhpU7MTeCEg22'
            })
        });
        it("Error while adding supplier admin", async () => {
            spyOn(supplierController["supplierService"], "addSupplierAdmin").and.rejectWith(Promise.reject("Unable to add supplier admin"));
            await expectAsync(supplierController.addAdmin(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to add supplier admin");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get supplier admin", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
        });
        it("Get empty", async () => {
            spyOn(supplierController["supplierService"], "getAdmin").and.resolveTo([])
            await expectAsync(supplierController.getAdmin(mockServer,mockRequest,mockReply)).toBeResolvedTo([])
        });
        it("Get admin supplier", async () => {
            spyOn(supplierController["supplierService"], "getAdmin").and.resolveTo({
                email:'eo4usupport@eo4u.ca',
                firstName:'Dark',
                lastName:'Marshmallow',
                role:'SUPER_ADMIN',
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                userName:'EO4U'
            })
            await expectAsync(supplierController.getAdmin(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                email:'eo4usupport@eo4u.ca',
                firstName:'Dark',
                lastName:'Marshmallow',
                role:'SUPER_ADMIN',
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                userName:'EO4U'
            })
        });
        it("Error while getting supplier admin", async () => {
            spyOn(supplierController["supplierService"], "getAdmin").and.rejectWith(Promise.reject("Unable to get supplier admin"))
            await expectAsync(supplierController.getAdmin(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get supplier admin")
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get supplier list", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                currentFilter:'',
                currentSort:'undefined',
                limit:10,
                offset:0,
                sortType:'ASC',
                uid: 'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
        });
        it("Get empty supplier list", async () => {
            spyOn(supplierController["supplierService"], "getSupplierList").and.resolveTo([])
            await expectAsync(supplierController.getSupplierList(mockServer,mockRequest,mockReply)).toBeResolvedTo([])
        });
        it("Get supplier list", async () => {
            spyOn(supplierController["supplierService"], "getSupplierList").and.resolveTo({
                uid:"ByY5OgqlrRgvEa48hqkzXMl733v1",
                firstName:"nigga",
                lastName:"fdf",
                role:"ADMIN",
                email:"eo4usupport@eo4u.ca11",
                supplier:"ACG"
            })
            await expectAsync(supplierController.getSupplierList(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                uid:"ByY5OgqlrRgvEa48hqkzXMl733v1",
                firstName:"nigga",
                lastName:"fdf",
                role:"ADMIN",
                email:"eo4usupport@eo4u.ca11",
                supplier:"ACG"
            })
        });
        it("Error while getting supplier list", async () => {
            spyOn(supplierController["supplierService"], "getSupplierList").and.rejectWith(Promise.reject("Unable to get supplier list"))
            await expectAsync(supplierController.getSupplierList(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get supplier list")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    // TODO: - Error while getting metadata
    // TODO: - TypeError: Cannot read property 'get' of undefined.
    // TODO:   - TypeError: supplierData.map is not a function.

    describe("Get metadata", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
        });
        it("Get empty metadata of users", async () => {
            spyOn(supplierController["supplierService"], "getSupplierAdminList").and.resolveTo([]);
            spyOn(supplierController["supplierService"], "getUsersList").and.resolveTo([]);
            await expectAsync(supplierController.getMetaData(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                userCount:0,
                supplierCount:0,
                supplierNameList:[]
            });
        });
        it("Get metadata of users", async () => {
            spyOn(supplierController["supplierService"], "getSupplierAdminList").and.resolveTo([{
                email:"dev2@code.dev",
                firstName:"Vihan",
                lastName:"afdsarer",
                role:"ADMIN",
                supplier:"ACG",
                uid:"26zI0fpzEpN0C3qrOGHUsq7Gije2"
            }]);
            spyOn(supplierController["supplierService"], "getUsersList").and.resolveTo([]);
            await expectAsync(supplierController.getMetaData(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                userCount:0,
                supplierCount:1,
                supplierNameList:["ACG"]
            })
        });
        it("Error while getting metadata of users", async () => {
            spyOn(supplierController["supplierService"], "getSupplierAdminList").and.rejectWith(Promise.reject("Unable to get metadata"))
            await expectAsync(supplierController.getMetaData(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get metadata")
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get list of all users", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                currentFilter:'',
                currentSort:'name',
                limit:10,
                offset:0,
                sortType:'ASC',
            };
        });
        it("Get empty users list", async () => {
            spyOn(supplierController["supplierService"], "getUsersList").and.resolveTo([])
            await expectAsync(supplierController.getUsersList(mockServer,mockRequest,mockReply)).toBeResolvedTo([])
        });
        it("Get list of all users", async () => {
            spyOn(supplierController["supplierService"], "getUsersList").and.resolveTo({
                userData: [{
                    email:'eo4usupport@eo4u.ca',
                    firstName:'Dark',
                    lastName:'Marshmallow',
                    role:'SUPER_ADMIN',
                    uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                    userName:'EO4U'},
                {   
                    email:'abcxyz@gmail.com',
                    firstName:'Abc',
                    lastName:'Xyz',
                    role:'ADMIN',
                    supplier:'Young Living',
                    uid:'I293nw3YIAdITXodhpU7MTeCEg22'}]
            })
            await expectAsync(supplierController.getUsersList(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                userData: [{
                    email:'eo4usupport@eo4u.ca',
                    firstName:'Dark',
                    lastName:'Marshmallow',
                    role:'SUPER_ADMIN',
                    uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                    userName:'EO4U'},
                {   
                    email:'abcxyz@gmail.com',
                    firstName:'Abc',
                    lastName:'Xyz',
                    role:'ADMIN',
                    supplier:'Young Living',
                    uid:'I293nw3YIAdITXodhpU7MTeCEg22'}]
            })
        });
        it("Error while getting users list", async () => {
            spyOn(supplierController["supplierService"], "getUsersList").and.rejectWith(Promise.reject("Unable to get metadata"))
            await expectAsync(supplierController.getUsersList(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get metadata")
        });
        afterAll(() => {
            mockRequest["params"] = {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add sku", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                productId:'5388285018269',
                skus: ['{"blend_composition":"NA","blends_well_with":"NA","duration":"NA","equipment":"NA","genus_specie":"NA","id":"35140578836637","item":"Apple oil","non_gmo":"NA","price":"CA$36.51","price_INR":"₹100","price_USD":"US$10.00","prime_per_ml":"NA","promotional":"NA","size":"20 mL","sku":"kjhg","supplier":"Young Living","usda_organic_cert":"NA"}'],
                storeTypeLabel:'SHOPIFY_SKU_NL'
            };
        });
        it("Adding sku", async () => {
            spyOn(supplierController["supplierService"], "addSku").and.resolveTo({
                addedSkus: [{
                    blend_composition:'NA',
                    blends_well_with:'NA',
                    duration:'NA',
                    equipment:'NA',
                    genus_specie:'NA',
                    id:'35140578836637',
                    item:'Apple oil',
                    non_gmo:'NA',
                    price:'CA$36.51',
                    price_INR:'₹100',
                    price_USD:'US$10.00',
                    prime_per_ml:'NA',
                    promotional:'NA',
                    size:'20 mL',
                    sku:'kjhg',
                    supplier:'Young Living',
                    usda_organic_cert:'NA'
                },
                {
                    blend_composition:'NA',
                    blends_well_with:'NA',
                    duration:'NA',
                    equipment:'NA',
                    genus_specie:'NA',
                    id:'35140578869405',
                    item:'Apple oil',
                    non_gmo:'NA',
                    price:'CA$36.51',
                    price_INR:'₹100',
                    price_USD:'US$6.00',
                    prime_per_ml:'NA',
                    promotional:'NA',
                    size:'15 mL',
                    sku:'345678h',
                    supplier:'Young Living',
                    usda_organic_cert:'NA'
                }],
                count:2
            })
            await expectAsync(supplierController.addSku(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                addedSkus: [{
                    blend_composition:'NA',
                    blends_well_with:'NA',
                    duration:'NA',
                    equipment:'NA',
                    genus_specie:'NA',
                    id:'35140578836637',
                    item:'Apple oil',
                    non_gmo:'NA',
                    price:'CA$36.51',
                    price_INR:'₹100',
                    price_USD:'US$10.00',
                    prime_per_ml:'NA',
                    promotional:'NA',
                    size:'20 mL',
                    sku:'kjhg',
                    supplier:'Young Living',
                    usda_organic_cert:'NA'
                },
                {
                    blend_composition:'NA',
                    blends_well_with:'NA',
                    duration:'NA',
                    equipment:'NA',
                    genus_specie:'NA',
                    id:'35140578869405',
                    item:'Apple oil',
                    non_gmo:'NA',
                    price:'CA$36.51',
                    price_INR:'₹100',
                    price_USD:'US$6.00',
                    prime_per_ml:'NA',
                    promotional:'NA',
                    size:'15 mL',
                    sku:'345678h',
                    supplier:'Young Living',
                    usda_organic_cert:'NA'
                }],
                count:2
            })
        });
        it("Error while adding sku", async () => {
            spyOn(supplierController["supplierService"], "addSku").and.rejectWith(Promise.reject("Unable to add sku"))
            await expectAsync(supplierController.addSku(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to add sku")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add discount on sku", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                discount:'15',
                productName:'Apple oil',
                supplier:'Young Living'
            };
        });
        it("Adding discount on sku", async () => {
            spyOn(supplierController["supplierService"], "addDiscountOnSku").and.resolveTo({
                skus:[]
            })
            await expectAsync(supplierController.addDiscountOnSku(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                skus:[]
            })
        });
        it("Error while adding discount on sku", async () => {
            spyOn(supplierController["supplierService"], "addDiscountOnSku").and.rejectWith(Promise.reject("Unable to add discount on sku"))
            await expectAsync(supplierController.addDiscountOnSku(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to add discount on sku")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    // describe("Get supplier image", () => {
    //     beforeAll(() => {
    //     });
    //     afterAll(() => {
    //         mockRequest["params"] =  {} ;
    //         mockRequest["query"] = {};
    //         mockRequest["body"] = {};
    //     });
    // });
});