import { MockServer } from "../../../../helpers/common_mock.helper";
import { SupplierService } from "./../../../../../src/modules/supplier/service/supplier.service";

describe("Supplier service unit test:", () => {
    let supplierService: SupplierService;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn:any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        supplierService = new SupplierService();
        spyOn(supplierService["redis"], "get").and.resolveTo({});
        spyOn(supplierService["redis"], "set").and.resolveTo(JSON.stringify({uid}));
    });

    //TODO: - Error while adding supplier
    // TODO: - SyntaxError: Unexpected token i in JSON at position 352.

    describe("Add supplier", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                supplierData:'{"role":"SUPPLIER","supplier_info":{"name":"Young Living","contactNo":"9292929292","otherContactNo":"9898989898","address":"chjhxx","city":"hkdj","country":"jhkjhkj","postalCode":454545,"inventorySource":"Shopify","apiKey":"4e9bb7e174dbd4bf9ce46773c52bacca","apiSecretKey":"0a8a7793619fdf73f4e2097536dfffdb","storeName":"eo4u","storeLogo":"C:\\\\fakepath\\\\images.jpeg"}}',
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
        });
        it("Add supplier details", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo({
                address:'123 Drew Street',
                apiKey:'4e9bb7e174dbd4bf9ce46773c52bacca',
                apiSecretKey:'0a8a7793619fdf73f4e2097536dfffdb',
                city:'Mumbai',
                contactNo:'9292929292',
                country:'India',
                created_at:'2020-08-20T11:40:00.930Z',
                inventorySource:'Shopify',
                modified_by:'',
                name:'doTERRA',
                object_id:'b4edf53a-011f-4dc0-9c04-55c00433930d',
                otherContactNo:'9898989898',
                postalCode:400092,
                role:'SUPPLIER',
                storeLogo:'doTERRA',
                storeName:'eo4u'
            })
            await expectAsync(supplierService.addSupplier(mockServer,mockRequest)).toBeResolvedTo({
                address:'123 Drew Street',
                apiKey:'4e9bb7e174dbd4bf9ce46773c52bacca',
                apiSecretKey:'0a8a7793619fdf73f4e2097536dfffdb',
                city:'Mumbai',
                contactNo:'9292929292',
                country:'India',
                created_at:'2020-08-20T11:40:00.930Z',
                inventorySource:'Shopify',
                modified_by:'',
                name:'doTERRA',
                object_id:'b4edf53a-011f-4dc0-9c04-55c00433930d',
                otherContactNo:'9898989898',
                postalCode:400092,
                role:'SUPPLIER',
                storeLogo:'doTERRA',
                storeName:'eo4u'
            })
        });
        it("Error while adding supplier", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.rejectWith("Unable to add supplier");
            await expectAsync(supplierService.addSupplier(mockServer,mockRequest)).toBeRejectedWith("Unable to add supplier");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get supplier admin", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'I293nw3YIAdITXodhpU7MTeCEg22'
            };
        });
        it("Get empty", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo([])
            await expectAsync(supplierService.getAdmin(mockServer,mockRequest)).toBeResolvedTo([])
        });
        it("Get admin supplier details", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo({
                email:'abcxyz@gmail.com',
                firstName:'Abc',
                lastName:'Xyz',
                role:'ADMIN',
                supplier:'Young Living',
                uid:'I293nw3YIAdITXodhpU7MTeCEg22'
            })
            await expectAsync(supplierService.getAdmin(mockServer,mockRequest)).toBeResolvedTo({
                email:'abcxyz@gmail.com',
                firstName:'Abc',
                lastName:'Xyz',
                role:'ADMIN',
                supplier:'Young Living',
                uid:'I293nw3YIAdITXodhpU7MTeCEg22'
            })
        });
        it("Error while getting supplier admin", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.rejectWith("Unable to get supplier admin")
            await expectAsync(supplierService.getAdmin(mockServer,mockRequest)).toBeRejectedWith("Unable to get supplier admin")
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add supplier admin", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                admin_info:['{"adminAddress":"dsds ds","adminCity":"Mumbai","adminCountry":"India","adminPostalCode":"400092","email":"user03@gmail.com","password":"12345678","firstName":"User","lastName":"Three"}'],
                role:'ADMIN_USER_NL',
                supplier:'Young Living',
                uid:'03Dt27aqraT0PmrL3OOEjc3RMyf2'
            };
        });
        it("Add supplier admin details", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo({
                email:'abcxyz@gmail.com',
                firstName:'Abc',
                lastName:'Xyz',
                role:'ADMIN',
                supplier:'Young Living',
                uid:'I293nw3YIAdITXodhpU7MTeCEg22'
            })
            await expectAsync(supplierService.addSupplierAdmin(mockServer,mockRequest)).toBeResolvedTo({
                email:'abcxyz@gmail.com',
                firstName:'Abc',
                lastName:'Xyz',
                role:'ADMIN',
                supplier:'Young Living',
                uid:'I293nw3YIAdITXodhpU7MTeCEg22'
            })
        });
        it("Error while adding supplier admin", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.rejectWith(Promise.reject("Unable to add supplier admin"));
            await expectAsync(supplierService.addSupplierAdmin(mockServer,mockRequest)).toBeRejectedWith("Unable to add supplier admin");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get supplier list", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                currentFilter:'',
                currentSort:'undefined',
                limit:10,
                offset:0,
                sortType:'ASC',
                uid: 'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
        });
        it("Get empty supplier list", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo([])
            await expectAsync(supplierService.getSupplierList(mockServer,mockRequest,mockRequest["query"],mockRequest["query"],mockRequest["query"],mockRequest["query"],mockRequest["query"])).toBeResolvedTo([])
        });
        it("Get supplier list", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo({
                uid:"ByY5OgqlrRgvEa48hqkzXMl733v1",
                firstName:"nigga",
                lastName:"fdf",
                role:"ADMIN",
                email:"eo4usupport@eo4u.ca11",
                supplier:"ACG"
            })
            await expectAsync(supplierService.getSupplierList(mockServer,mockRequest,mockRequest["query"],mockRequest["query"],mockRequest["query"],mockRequest["query"],mockRequest["query"])).toBeResolvedTo({
                uid:"ByY5OgqlrRgvEa48hqkzXMl733v1",
                firstName:"nigga",
                lastName:"fdf",
                role:"ADMIN",
                email:"eo4usupport@eo4u.ca11",
                supplier:"ACG"
            })
        });
        it("Error while getting supplier list", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.rejectWith("Unable to get supplier list")
            await expectAsync(supplierService.getSupplierList(mockServer,mockRequest,mockRequest["query"],mockRequest["query"],mockRequest["query"],mockRequest["query"],mockRequest["query"])).toBeRejectedWith("Unable to get supplier list")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get supplier admin list", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
        });
        it("Get empty supplier admin list", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo([])
            await expectAsync(supplierService.getSupplierAdminList(mockServer,mockRequest,mockRequest["query"],mockRequest["query"])).toBeResolvedTo([])
        });
        it("Get supplier admin list", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo({
                userCount:6,
                supplierCount:1,
                supplierNameList:["ACG"]
            })
            await expectAsync(supplierService.getSupplierAdminList(mockServer,mockRequest,mockRequest["query"],mockRequest["query"])).toBeResolvedTo({
                userCount:6,
                supplierCount:1,
                supplierNameList:["ACG"]
            })
        });
        it("Error while getting supplier admin list", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.rejectWith("Unable to get supplier admin list")
            await expectAsync(supplierService.getSupplierAdminList(mockServer,mockRequest,mockRequest["query"],mockRequest["query"])).toBeRejectedWith("Unable to get supplier admin list")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get list of all users", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                currentFilter:'',
                currentSort:'name',
                limit:10,
                offset:0,
                sortType:'ASC',
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
        });
        it("Get empty users list", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo([])
            await expectAsync(supplierService.getUsersList(mockServer,mockRequest,mockRequest,mockRequest,mockRequest,mockRequest,mockRequest)).toBeResolvedTo([])
        });
        it("Get list of all users", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.resolveTo({
                userData: [{
                    email:'eo4usupport@eo4u.ca',
                    firstName:'Dark',
                    lastName:'Marshmallow',
                    role:'SUPER_ADMIN',
                    uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                    userName:'EO4U'},
                {   
                    email:'abcxyz@gmail.com',
                    firstName:'Abc',
                    lastName:'Xyz',
                    role:'ADMIN',
                    supplier:'Young Living',
                    uid:'I293nw3YIAdITXodhpU7MTeCEg22'}]
            })
            await expectAsync(supplierService.getUsersList(mockServer,mockRequest,mockRequest,mockRequest,mockRequest,mockRequest,mockRequest)).toBeResolvedTo({
                userData: [{
                    email:'eo4usupport@eo4u.ca',
                    firstName:'Dark',
                    lastName:'Marshmallow',
                    role:'SUPER_ADMIN',
                    uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                    userName:'EO4U'},
                {   
                    email:'abcxyz@gmail.com',
                    firstName:'Abc',
                    lastName:'Xyz',
                    role:'ADMIN',
                    supplier:'Young Living',
                    uid:'I293nw3YIAdITXodhpU7MTeCEg22'}]
            })
        });
        it("Error while getting users list", async () => {
            spyOn(supplierService["supplierDbService"], "querySelector").and.rejectWith("Unable to get metadata")
            await expectAsync(supplierService.getUsersList(mockServer,mockRequest,mockRequest,mockRequest,mockRequest,mockRequest,mockRequest)).toBeRejectedWith("Unable to get metadata")
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add sku", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                productId:'5388285018269',
                skus: ['{"blend_composition":"NA","blends_well_with":"NA","duration":"NA","equipment":"NA","genus_specie":"NA","id":"35140578836637","item":"Apple oil","non_gmo":"NA","price":"CA$36.51","price_INR":"₹100","price_USD":"US$10.00","prime_per_ml":"NA","promotional":"NA","size":"20 mL","sku":"kjhg","supplier":"Young Living","usda_organic_cert":"NA"}'],
                storeTypeLabel:'SHOPIFY_SKU_NL'
            };
        });
        it("Cancel sku", async () => {
            spyOn(supplierService["supplierDbService"], "addSku").and.resolveTo([])
            await expectAsync(supplierService.addSku(mockServer,mockRequest)).toBeRejectedWithError("Error while adding sku")
        });
        it("Add sku details", async () => {
            spyOn(supplierService["supplierDbService"], "addSku").and.resolveTo({
                addedSkus: [{
                    blend_composition:'NA',
                    blends_well_with:'NA',
                    duration:'NA',
                    equipment:'NA',
                    genus_specie:'NA',
                    id:'35140578836637',
                    item:'Apple oil',
                    non_gmo:'NA',
                    price:'CA$36.51',
                    price_INR:'₹100',
                    price_USD:'US$10.00',
                    prime_per_ml:'NA',
                    promotional:'NA',
                    size:'20 mL',
                    sku:'kjhg',
                    supplier:'Young Living',
                    usda_organic_cert:'NA'
                },
                {
                    blend_composition:'NA',
                    blends_well_with:'NA',
                    duration:'NA',
                    equipment:'NA',
                    genus_specie:'NA',
                    id:'35140578869405',
                    item:'Apple oil',
                    non_gmo:'NA',
                    price:'CA$36.51',
                    price_INR:'₹100',
                    price_USD:'US$6.00',
                    prime_per_ml:'NA',
                    promotional:'NA',
                    size:'15 mL',
                    sku:'345678h',
                    supplier:'Young Living',
                    usda_organic_cert:'NA'
                }],
                count:2
            })
            await expectAsync(supplierService.addSku(mockServer,mockRequest)).toBeResolvedTo({
                addedSkus: [{
                    blend_composition:'NA',
                    blends_well_with:'NA',
                    duration:'NA',
                    equipment:'NA',
                    genus_specie:'NA',
                    id:'35140578836637',
                    item:'Apple oil',
                    non_gmo:'NA',
                    price:'CA$36.51',
                    price_INR:'₹100',
                    price_USD:'US$10.00',
                    prime_per_ml:'NA',
                    promotional:'NA',
                    size:'20 mL',
                    sku:'kjhg',
                    supplier:'Young Living',
                    usda_organic_cert:'NA'
                },
                {
                    blend_composition:'NA',
                    blends_well_with:'NA',
                    duration:'NA',
                    equipment:'NA',
                    genus_specie:'NA',
                    id:'35140578869405',
                    item:'Apple oil',
                    non_gmo:'NA',
                    price:'CA$36.51',
                    price_INR:'₹100',
                    price_USD:'US$6.00',
                    prime_per_ml:'NA',
                    promotional:'NA',
                    size:'15 mL',
                    sku:'345678h',
                    supplier:'Young Living',
                    usda_organic_cert:'NA'
                }],
                count:2
            })
        });
        it("Error while adding sku", async () => {
            spyOn(supplierService["supplierDbService"], "addSku").and.rejectWith("Unable to add sku")
            await expectAsync(supplierService.addSku(mockServer,mockRequest)).toBeRejectedWith("Unable to add sku")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add discount on sku", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                discount:'15',
                productName:'Apple oil',
                supplier:'Young Living'
            };
        });
        it("Cancel discount on sku", async () => {
            spyOn(supplierService["supplierDbService"], "applyDiscount").and.resolveTo([])
            await expectAsync(supplierService.addDiscountOnSku(mockServer,mockRequest)).toBeRejectedWithError("Error while adding sku")
        });
        it("Add discount on sku", async () => {
            spyOn(supplierService["supplierDbService"], "applyDiscount").and.resolveTo({
                skus:[]
            })
            await expectAsync(supplierService.addDiscountOnSku(mockServer,mockRequest)).toBeResolvedTo({
                skus:[]
            })
        });
        it("Error while adding discount on sku", async () => {
            spyOn(supplierService["supplierDbService"], "applyDiscount").and.rejectWith("Unable to add discount on sku")
            await expectAsync(supplierService.addDiscountOnSku(mockServer,mockRequest)).toBeRejectedWith("Unable to add discount on sku")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    // describe("Get supplier image", () => {
    //     beforeAll(() => {
    //     });
    //     afterAll(() => {
    //         mockRequest["params"] =  {} ;
    //         mockRequest["query"] = {};
    //         mockRequest["body"] = {};
    //     });
    // });
    
});