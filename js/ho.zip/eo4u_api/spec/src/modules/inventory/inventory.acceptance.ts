import { HttpHelper } from "./../../../helpers/http.helper";

describe("Inventory acceptance test: ", () => {
    const httpHelper: HttpHelper = new HttpHelper();
    beforeAll(() => {
    });

    afterAll(() => {
    });

    describe("/check-sku-status: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    status: "string",
                    EoName: "string",
                    supplier: "string",
                    size: "string",
                    uid: "string"
                };
                result = await httpHelper.request("POST", "/check-sku-status", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/update-inventory/:uid: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    label: "string",
                    eo_array: [
                        {
                            name: "string",
                            supplier: "string",
                            size: "string",
                            blendsWellWith: "string",
                            blends_array: [
                                {
                                    name: "string",
                                    drps: 0
                                }
                            ]
                        }
                    ]
                };
                const uid: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("PUT", `/update-inventory/${uid}`, content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-inventory: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    uid: "string",
                    label: "string"
                };
                result = await httpHelper.request("GET", "/get-inventory", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-eo-health-caution: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    uid: "string",
                    eoName: "string",
                    genusSpecie: "string"
                };
                result = await httpHelper.request("GET", "/get-eo-health-caution", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/remove-sku-inventory: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    status: "string",
                    EoName: "string",
                    supplier: "string",
                    size: "string",
                    uid: "string"
                };
                result = await httpHelper.request("PUT", "/remove-sku-inventory", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });
});