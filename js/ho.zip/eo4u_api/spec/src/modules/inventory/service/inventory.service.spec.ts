import { InventoryService } from "../../../../../src/modules/inventory/service/inventory.service";
import { MockServer } from "../../../../helpers/common_mock.helper";


describe("Inventory Service Unit tests: ", () => {
    let inventoryService: InventoryService;
    let mockRequest: any;
    let mockServer: MockServer;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        inventoryService = new InventoryService();
        spyOn(inventoryService["redis"], "get").and.resolveTo({uid});
    });

    describe("Check Sku Availability", () => {
        beforeAll(() => {
            mockRequest["body"] =  {
                EoName:"Bergamot",
                size:"10 mL",
                status:"ADD_INVENTORY",
                supplier:"escents",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            } ;
        });
        it("When sku is already in inventory", async () => {
            spyOn(inventoryService["inventoryDbService"], "checkSkuStatus").and.resolveTo(true);
            await expectAsync(inventoryService.checkSkuAvailability(mockServer, mockRequest)).toBeResolvedTo(true);
        });
        it("When sku is not added in inventory", async () => {
            spyOn(inventoryService["inventoryDbService"], "checkSkuStatus").and.resolveTo(false);
            await expectAsync(inventoryService.checkSkuAvailability(mockServer, mockRequest)).toBeResolvedTo(false);
        });
        it("Get error while checking sku available to add in inventory", async () => {
            spyOn(inventoryService["inventoryDbService"], "checkSkuStatus").and.rejectWith("Unable to check Sku availability");
            await expectAsync(inventoryService.checkSkuAvailability(mockServer, mockRequest)).toBeRejectedWith("Unable to check Sku availability");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Update Inventory", () => {
        beforeAll(() => {
            mockRequest["body"] =  {
                eo_array:[{
                    created:"available",
                    eoName:"Bergamot",
                    genusSpecie:"Citrus bergamia",
                    img:"SEO8",
                    size:"10 mL",
                    supplier:"escents",
                }],
                label:"SINGLE_INVENTORY_NL"
            };
            mockRequest["params"] = {uid: "jyHpMqYWQqPj3c49DOF66Csbv2M2"};
        });
        it("Adding sku in inventory", async () => {
            spyOn(inventoryService["inventoryDbService"], "updateInventory").and.resolveTo({
                eo_array:[{
                    created:"available",
                    eoName:"Bergamot",
                    genusSpecie:"Citrus bergamia",
                    img:"SEO8",
                    size:"10 mL",
                    supplier:"escents",
                }],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
            await expectAsync(inventoryService.updateInventory(mockServer, mockRequest)).toBeResolvedTo({
                eo_array:[{
                    created:"available",
                    eoName:"Bergamot",
                    genusSpecie:"Citrus bergamia",
                    img:"SEO8",
                    size:"10 mL",
                    supplier:"escents",
                }],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
        });
        it("Get error while adding sku in inventory", async () => {
            spyOn(inventoryService["inventoryDbService"], "updateInventory").and.rejectWith("Unable to add SKU in inventory");
            await expectAsync(inventoryService.updateInventory(mockServer, mockRequest)).toBeRejectedWith("Unable to add SKU in inventory");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Get Inventory details", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                label:"SINGLE_INVENTORY_NL",
                uid
            };
        });
        it("When Single EO Inventory has a single SKU", async () => {
            spyOn(inventoryService["inventoryDbService"], "getInventory").and.resolveTo({
                eo_array:[{
                    created:"available",
                    eoName:"Bergamot",
                    genusSpecie:"Citrus bergamia",
                    img:"SEO8",
                    size:"10 mL",
                    supplier:"escents",
                }],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
            await expectAsync(inventoryService.getInventory(mockServer, mockRequest)).toBeResolvedTo({
                eo_array:[{
                    created:"available",
                    eoName:"Bergamot",
                    genusSpecie:"Citrus bergamia",
                    img:"SEO8",
                    size:"10 mL",
                    supplier:"escents",
                }],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
        });
        it("When inventory is empty", async () => {
            spyOn(inventoryService["inventoryDbService"], "getInventory").and.resolveTo({
                eo_array:[],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
            await expectAsync(inventoryService.getInventory(mockServer, mockRequest)).toBeResolvedTo({
                eo_array:[],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
        });
        it("Get error while adding sku in inventory", async () => {
            spyOn(inventoryService["inventoryDbService"], "getInventory").and.rejectWith("Unable to get inventory details");
            await expectAsync(inventoryService.getInventory(mockServer, mockRequest)).toBeRejectedWith("Unable to get inventory details");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Get Health Caution When user has selected 'Breastfeeding' in health conditions", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                uid,
                eoName:"Clove",
                genusSpecie:"Eugenia caryophyllata"
            };
        });
        it("Get Health caution statement", async () => {
            spyOn(inventoryService["inventoryDbService"], "getUserEoHealthWarning").and.resolveTo(["Avoid if breastfeeding"]);
            await expectAsync(inventoryService.checkEoHealthCaution(mockServer, mockRequest)).toBeResolvedTo(["Avoid if breastfeeding"]);
        });
        it("Get error while getting health caution statement", async () => {
            spyOn(inventoryService["inventoryDbService"], "getUserEoHealthWarning").and.rejectWith("Unable to get health caution statement");
            await expectAsync(inventoryService.checkEoHealthCaution(mockServer, mockRequest)).toBeRejectedWith("Unable to get health caution statement");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Remove SKU[Cinnanmon Bark(5ml, Melaleuca)] from inventory", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                EoName:"Cinnamon Bark",
                size:"5 mL",
                status:"ADD_INVENTORY",
                supplier:"Melaleuca"
            };
        });
        it("Removing SKU from inventory", async () => {
            spyOn(inventoryService["inventoryDbService"], "removeInventorySkuRelation").and.resolveTo({
                eoName:"Clove",
                size:"15 mL",
                supplier:"Melaleuca"
            });
            await expectAsync(inventoryService.removeProduct(mockServer, mockRequest)).toBeResolvedTo({
                eoName:"Clove",
                size:"15 mL",
                supplier:"Melaleuca"
            });
        });
        it("Get error while removing sku from inventory", async () => {
            spyOn(inventoryService["inventoryDbService"], "removeInventorySkuRelation").and.rejectWith("Unable to remove SKU from inventory");
            await expectAsync(inventoryService.removeProduct(mockServer, mockRequest)).toBeRejectedWith("Unable to remove SKU from inventory");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
});
