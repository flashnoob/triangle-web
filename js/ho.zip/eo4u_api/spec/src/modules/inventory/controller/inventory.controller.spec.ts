import { InventoryController } from "../../../../../src/modules/inventory/controller/inventory.controller";
import { MockReply, MockServer } from "../../../../helpers/common_mock.helper";

describe("Inventory controller Unit tests: ", () => {
    let inventoryController: InventoryController;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    const uid = "jyHpMqYWQqPj3c49DOF66Csbv2M2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockReply = new MockReply();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        inventoryController = new InventoryController();
    });

    describe("Check Sku Availability", () => {
        beforeAll(() => {
            mockRequest["body"] =  {
                EoName:"Bergamot",
                size:"10 mL",
                status:"ADD_INVENTORY",
                supplier:"escents",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            } ;
        });
        it("When sku is already in inventory", async () => {
            spyOn(inventoryController["inventoryService"], "checkSkuAvailability").and.resolveTo(true);
            await expectAsync(inventoryController.checkSkuAvailability(mockServer, mockRequest, mockReply)).toBeResolvedTo(true);
        });
        it("When sku is not added in inventory", async () => {
            spyOn(inventoryController["inventoryService"], "checkSkuAvailability").and.resolveTo(false);
            await expectAsync(inventoryController.checkSkuAvailability(mockServer, mockRequest, mockReply)).toBeResolvedTo(false);
        });
        it("Get error while checking sku available to add in inventory", async () => {
            spyOn(inventoryController["inventoryService"], "checkSkuAvailability").and.rejectWith(Promise.reject("Unable to check Sku availability"));
            await expectAsync(inventoryController.checkSkuAvailability(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to check Sku availability");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update Inventory", () => {
        beforeAll(() => {
            mockRequest["body"] =  {
                eo_array:[{
                    created:"available",
                    eoName:"Bergamot",
                    genusSpecie:"Citrus bergamia",
                    img:"SEO8",
                    size:"10 mL",
                    supplier:"escents",
                }],
                label:"SINGLE_INVENTORY_NL"
            };
            mockRequest["params"] = {uid: "jyHpMqYWQqPj3c49DOF66Csbv2M2"};
        });
        it("Adding sku in inventory", async () => {
            spyOn(inventoryController["inventoryService"], "updateInventory").and.resolveTo({
                eo_array:[{
                    created:"available",
                    eoName:"Bergamot",
                    genusSpecie:"Citrus bergamia",
                    img:"SEO8",
                    size:"10 mL",
                    supplier:"escents",
                }],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
            await expectAsync(inventoryController.updateInventory(mockServer, mockRequest, mockReply)).toBeResolvedTo([{
                created:"available",
                eoName:"Bergamot",
                genusSpecie:"Citrus bergamia",
                img:"SEO8",
                size:"10 mL",
                supplier:"escents",
            }]);
        });
        it("Get error while adding sku in inventory", async () => {
            spyOn(inventoryController["inventoryService"], "updateInventory").and.rejectWith(Promise.reject("Unable to add SKU in inventory"));
            await expectAsync(inventoryController.updateInventory(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to add SKU in inventory");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get Inventory details", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                label:"SINGLE_INVENTORY_NL",
                uid
            };
        });
        it("When Single EO Inventory has a single SKU", async () => {
            spyOn(inventoryController["inventoryService"], "getInventory").and.resolveTo({
                eo_array:[{
                    created:"available",
                    eoName:"Bergamot",
                    genusSpecie:"Citrus bergamia",
                    img:"SEO8",
                    size:"10 mL",
                    supplier:"escents",
                }],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
            await expectAsync(inventoryController.getInventory(mockServer, mockRequest, mockReply)).toBeResolvedTo([{
                created:"available",
                eoName:"Bergamot",
                genusSpecie:"Citrus bergamia",
                img:"SEO8",
                size:"10 mL",
                supplier:"escents",
            }]);
        });
        it("When inventory is empty", async () => {
            spyOn(inventoryController["inventoryService"], "getInventory").and.resolveTo({
                eo_array:[],
                modified_at:"2020-08-06T07:46:41.017Z",
                modified_by:"jyHpMqYWQqPj3c49DOF66Csbv2M2",
                uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2"
            });
            await expectAsync(inventoryController.getInventory(mockServer, mockRequest, mockReply)).toBeResolvedTo([]);
        });
        it("Get error while adding sku in inventory", async () => {
            spyOn(inventoryController["inventoryService"], "getInventory").and.rejectWith(Promise.reject("Unable to get inventory details"));
            await expectAsync(inventoryController.getInventory(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to get inventory details");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Get Health Caution When user has selected 'Breastfeeding' in health conditions", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                uid,
                eoName:"Clove",
                genusSpecie:"Eugenia caryophyllata"
            };
        });
        it("Get Health caution statement successfully", async () => {
            spyOn(inventoryController["inventoryService"], "checkEoHealthCaution").and.resolveTo(["Avoid if breastfeeding"]);
            await expectAsync(inventoryController.getEoHealthCaution(mockServer, mockRequest, mockReply)).toBeResolvedTo(["Avoid if breastfeeding"]);
        });
        it("Get error while getting health caution statement", async () => {
            spyOn(inventoryController["inventoryService"], "checkEoHealthCaution").and.rejectWith(Promise.reject("Unable to get health caution statement"));
            await expectAsync(inventoryController.getEoHealthCaution(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to get health caution statement");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Remove SKU from inventory", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                EoName:"Cinnamon Bark",
                size:"5 mL",
                status:"ADD_INVENTORY",
                supplier:"Melaleuca"
            };
        });
        it("Removing SKU from inventory", async () => {
            spyOn(inventoryController["inventoryService"], "removeProduct").and.resolveTo({
                eoName:"Clove",
                size:"15 mL",
                supplier:"Melaleuca"
            });
            await expectAsync(inventoryController.removeProduct(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                eoName:"Clove",
                size:"15 mL",
                supplier:"Melaleuca"
            });
        });
        it("Get error while removing sku from inventory", async () => {
            spyOn(inventoryController["inventoryService"], "removeProduct").and.rejectWith(Promise.reject("Unable to remove SKU from inventory"));
            await expectAsync(inventoryController.removeProduct(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to remove SKU from inventory");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
});