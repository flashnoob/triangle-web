import { PaymentService } from './../../../../../src/modules/payment/service/payment.service';
import { MockServer } from "../../../../helpers/common_mock.helper";

describe("Payement service unit test:", () => {
    let paymentService: PaymentService;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn: any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockRequest = { req: { user: { uid } }, params: {}, query: {}, body: {} };
        paymentService = new PaymentService();
        spyOn(paymentService["redis"], "get").and.resolveTo({});
        spyOn(paymentService["redis"], "set").and.resolveTo(JSON.stringify({ uid }));
    });

    describe("Create payment intent", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                amount:'12',
                currency:'usd',
                customerId:'cus_HtX9DCAHQMkdjk',
                payment_method_id:'src_1HJk7ZBAvb48eNmDxtPSoBNH',
                uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
        });
        it("Create setup intent for a customer", async () => {
            spyOn(paymentService["paymentDbService"], "createPaymentIntent").and.resolveTo({
                amount:10000,
                amount_capturable:0,
                amount_received:0,
                application:null,
                application_fee_amount:null,
                canceled_at:null,
                cancellation_reason:null,
                capture_method:'automatic',
                charges: {
                    data:[],
                    has_more:false,
                    object:'list',
                    total_count:0,
                    url:'/v1/charges?payment_intent=pi_1HJlM7BAvb48eNmD7qHWrwB3'
                },
                client_secret:'pi_1HJlM7BAvb48eNmD7qHWrwB3_secret_BIYRJzBc9lLglNVeuInqEWqFH',
                confirmation_method:'automatic',
                created:1598297363,
                currency:'cad',
                customer:'cus_HtX9DCAHQMkdjk',
                description:'purchased product',
                id:'pi_1HJlM7BAvb48eNmD7qHWrwB3',
                invoice:null,
                last_payment_error:null,
                lastResponse: ['{"_readableState":"ReadableState","readable":"false","_events": "{…}", "_eventsCount": "2", "_maxListeners": "undefined"}'],
                livemode:false,
                metadata:{},
                next_action:null,
                object:'payment_intent',
                on_behalf_of:null,
                payment_method:'src_1HJk7ZBAvb48eNmDxtPSoBNH',
                payment_method_options:{card: ['{"installments":"null","network":"null","request_three_d_secure":"automatic"}']},
                payment_method_types: ['card'],
                receipt_email:null,
                review:null,
                setup_future_usage:null,
                shipping:null,
                source:null,
                statement_descriptor:null,
                statement_descriptor_suffix:null,
                status:'requires_confirmation',
                transfer_data:null,
                transfer_group:null
            })
            await expectAsync(paymentService.createPaymentIntent(mockServer,mockRequest,mockRequest)).toBeResolvedTo({
                amount:10000,
                amount_capturable:0,
                amount_received:0,
                application:null,
                application_fee_amount:null,
                canceled_at:null,
                cancellation_reason:null,
                capture_method:'automatic',
                charges: {
                    data:[],
                    has_more:false,
                    object:'list',
                    total_count:0,
                    url:'/v1/charges?payment_intent=pi_1HJlM7BAvb48eNmD7qHWrwB3'
                },
                client_secret:'pi_1HJlM7BAvb48eNmD7qHWrwB3_secret_BIYRJzBc9lLglNVeuInqEWqFH',
                confirmation_method:'automatic',
                created:1598297363,
                currency:'cad',
                customer:'cus_HtX9DCAHQMkdjk',
                description:'purchased product',
                id:'pi_1HJlM7BAvb48eNmD7qHWrwB3',
                invoice:null,
                last_payment_error:null,
                lastResponse: ['{"_readableState":"ReadableState","readable":"false","_events": "{…}", "_eventsCount": "2", "_maxListeners": "undefined"}'],
                livemode:false,
                metadata:{},
                next_action:null,
                object:'payment_intent',
                on_behalf_of:null,
                payment_method:'src_1HJk7ZBAvb48eNmDxtPSoBNH',
                payment_method_options:{card: ['{"installments":"null","network":"null","request_three_d_secure":"automatic"}']},
                payment_method_types: ['card'],
                receipt_email:null,
                review:null,
                setup_future_usage:null,
                shipping:null,
                source:null,
                statement_descriptor:null,
                statement_descriptor_suffix:null,
                status:'requires_confirmation',
                transfer_data:null,
                transfer_group:null
            })
        });
        it("Error while creating payment intent", async () => {
            spyOn(paymentService["paymentDbService"], "createPaymentIntent").and.rejectWith("Unable to create payment intent")
            await expectAsync(paymentService.createPaymentIntent(mockServer,mockRequest,mockRequest)).toBeRejectedWith("Unable to create payment intent")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get customer source list", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                customerId: 'cus_HtU6xmeEZvlKlQ',
                uid: 'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
        });
        it("Get empty customer source list", async () => {
            spyOn(paymentService["paymentDbService"], "getCustomerSourceList").and.resolveTo([])
            await expectAsync(paymentService.getCustomerSourceList(mockServer, mockRequest, mockRequest["params"])).toBeResolvedTo([])
        });
        it("Get customer source list", async () => {
            spyOn(paymentService["paymentDbService"], "getCustomerSourceList").and.resolveTo({
                data:{
                    amount:null,
                    card:['{"address_line1_check":"null","address_zip_check":"null","brand":"Visa","country":"IN","cvc_check":"unchecked","dynamic_last4":"null","exp_month":"11","exp_year":"2021","fingerprint":"kjODQWP1nmvqLVhd","funding":"debit","last4":"5630","name":"null","three_d_secure":"optional","tokenization_method":"null"}']
                },
                has_more:false,
                lastResponse: ['{"_readableState":"ReadableState","readable":"false","_events": "{…}", "_eventsCount": "2", "_maxListeners": "undefined"}'],
                object:'list',
                url:'/v1/customers/cus_HtU6xmeEZvlKlQ/sources'
            })
            await expectAsync(paymentService.getCustomerSourceList(mockServer, mockRequest, mockRequest["params"])).toBeResolvedTo({
                data:{
                    amount:null,
                    card:['{"address_line1_check":"null","address_zip_check":"null","brand":"Visa","country":"IN","cvc_check":"unchecked","dynamic_last4":"null","exp_month":"11","exp_year":"2021","fingerprint":"kjODQWP1nmvqLVhd","funding":"debit","last4":"5630","name":"null","three_d_secure":"optional","tokenization_method":"null"}']
                },
                has_more:false,
                lastResponse: ['{"_readableState":"ReadableState","readable":"false","_events": "{…}", "_eventsCount": "2", "_maxListeners": "undefined"}'],
                object:'list',
                url:'/v1/customers/cus_HtU6xmeEZvlKlQ/sources'
            })
        });
        it("Error while getting customersource list", async () => {
            spyOn(paymentService["paymentDbService"], "getCustomerSourceList").and.rejectWith("Unable to get customer source list")
            await expectAsync(paymentService.getCustomerSourceList(mockServer, mockRequest, mockRequest["params"])).toBeRejectedWith("Unable to get customer source list")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Create customer", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                address: '{"street1":"Sgsg","street2":"Agsg","city":"Sggs","state":"Ssnjs","country":"United States of America","countryCode":"USD","zip":"446455","defaultAddress":true}',
                description: 'description',
                email: 'leo20@gmail.com',
                name: 'Leo Abc',
                phoneNumber: '9191919191',
                uid: '8SO9LIWDRoZVBqWzvhtrNJEhMj42'
            };
        });
        it("Create a customer in stripe", async () => {
            spyOn(paymentService["paymentDbService"], "createCustomer").and.resolveTo({
                address: ['{"street1":"Sgsg","street2":"Agsg","city":"Sggs","state":"Ssnjs","country":"United States of America","countryCode":"USD","zip":"446455","defaultAddress":true}'],
                birthday: '15-11-1984',
                created_at: '2020-08-24T17:38:30.026Z',
                created_by: '8SO9LIWDRoZVBqWzvhtrNJEhMj42',
                email: 'leo20@gmail.com',
                firstName: 'Leo',
                img_name: 'userName.png',
                isNewUser: true,
                lastName: 'Abc',
                lastSigninTimestamp: 'Mon Aug 24 2020 23:07:33 GMT+0530 (IST)',
                membership_expire: '2018-09-07T22:03:55.353Z',
                modified_at: '',
                modified_by: '',
                object_id: '016f70ad-98ab-4460-beb6-0d8cfd7087fc',
                phoneNumber: '9191919191',
                premiumUser: false,
                role: 'MEMBER',
                sex: 'male',
                status: 'active',
                stripeCustomerID: 'cus_HtX457z6Eoptv8',
                uid: '8SO9LIWDRoZVBqWzvhtrNJEhMj42'
            })
            await expectAsync(paymentService.createCustomer(mockServer, mockRequest, mockRequest["body"])).toBeResolvedTo({
                address: ['{"street1":"Sgsg","street2":"Agsg","city":"Sggs","state":"Ssnjs","country":"United States of America","countryCode":"USD","zip":"446455","defaultAddress":true}'],
                birthday: '15-11-1984',
                created_at: '2020-08-24T17:38:30.026Z',
                created_by: '8SO9LIWDRoZVBqWzvhtrNJEhMj42',
                email: 'leo20@gmail.com',
                firstName: 'Leo',
                img_name: 'userName.png',
                isNewUser: true,
                lastName: 'Abc',
                lastSigninTimestamp: 'Mon Aug 24 2020 23:07:33 GMT+0530 (IST)',
                membership_expire: '2018-09-07T22:03:55.353Z',
                modified_at: '',
                modified_by: '',
                object_id: '016f70ad-98ab-4460-beb6-0d8cfd7087fc',
                phoneNumber: '9191919191',
                premiumUser: false,
                role: 'MEMBER',
                sex: 'male',
                status: 'active',
                stripeCustomerID: 'cus_HtX457z6Eoptv8',
                uid: '8SO9LIWDRoZVBqWzvhtrNJEhMj42'
            })
        });
        it("Error while creating customer", async () => {
            spyOn(paymentService["paymentDbService"], "createCustomer").and.rejectWith("Unable to create a customer in stripe")
            await expectAsync(paymentService.createCustomer(mockServer, mockRequest, mockRequest["body"])).toBeRejectedWith("Unable to create a customer in stripe")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    })

    describe("Add customer card source", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                customerId: 'cus_HtX9DCAHQMkdjk',
                token: 'src_1HJk7ZBAvb48eNmDxtPSoBNH',
                uid: '8SO9LIWDRoZVBqWzvhtrNJEhMj42'
            };
        });
        it("Add customer card source details", async () => {
            spyOn(paymentService["paymentDbService"], "addCustomerCardSource").and.resolveTo({
                amount: null,
                card: ['{"address_line1_check":"null","address_zip_check":"null","brand":"Visa","country":"IN","cvc_check":"unchecked","dynamic_last4":"null","exp_month":"11","exp_year":"2021","fingerprint":"kjODQWP1nmvqLVhd","funding":"debit","last4":"5630","name":"null","three_d_secure":"optional","tokenization_method":"null"}'],
                client_secret: 'src_client_secret_EqOvxpsaeQoXyesebI3YbqRK',
                created: 1598292617,
                currency: null,
                customer: 'cus_HtX9DCAHQMkdjk',
                flow: 'none',
                id: 'src_1HJk7ZBAvb48eNmDxtPSoBNH',
                lastResponse: ['{"_consuming":"false","_dumped":"false","_eventsCount":"2","_maxListeners":"undefined","aborted":"false","apiVersion":"2020-03-02","complete":"true","httpVersion":"1.1","httpVersionMajor":"1","httpVersionMinor":"1","method":"null","requestId":"req_E9N4gwe5wgVlkY"}'],
                livemode: false,
                metadata: {},
                object: 'source',
                owner: ['{"address":"null","email":"null","name":"null","phone":"null","verified_address":"null","verified_email":"null","verified_name":"null","verified_phone":"null"}'],
                statement_descriptor: null,
                status: 'chargeable',
                type: 'card',
                usage: 'reusable',
            })
            await expectAsync(paymentService.addCustomerCardSource(mockServer, mockRequest, mockRequest["body"], mockRequest["body"])).toBeResolvedTo({
                amount: null,
                card: ['{"address_line1_check":"null","address_zip_check":"null","brand":"Visa","country":"IN","cvc_check":"unchecked","dynamic_last4":"null","exp_month":"11","exp_year":"2021","fingerprint":"kjODQWP1nmvqLVhd","funding":"debit","last4":"5630","name":"null","three_d_secure":"optional","tokenization_method":"null"}'],
                client_secret: 'src_client_secret_EqOvxpsaeQoXyesebI3YbqRK',
                created: 1598292617,
                currency: null,
                customer: 'cus_HtX9DCAHQMkdjk',
                flow: 'none',
                id: 'src_1HJk7ZBAvb48eNmDxtPSoBNH',
                lastResponse: ['{"_consuming":"false","_dumped":"false","_eventsCount":"2","_maxListeners":"undefined","aborted":"false","apiVersion":"2020-03-02","complete":"true","httpVersion":"1.1","httpVersionMajor":"1","httpVersionMinor":"1","method":"null","requestId":"req_E9N4gwe5wgVlkY"}'],
                livemode: false,
                metadata: {},
                object: 'source',
                owner: ['{"address":"null","email":"null","name":"null","phone":"null","verified_address":"null","verified_email":"null","verified_name":"null","verified_phone":"null"}'],
                statement_descriptor: null,
                status: 'chargeable',
                type: 'card',
                usage: 'reusable',
            })
        });
        it("Error while adding suctomer card source", async () => {
            spyOn(paymentService["paymentDbService"], "addCustomerCardSource").and.rejectWith("Unable to add customer card source")
            await expectAsync(paymentService.addCustomerCardSource(mockServer, mockRequest, mockRequest["body"], mockRequest["body"])).toBeRejectedWith("Unable to add customer card source")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update membership", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                amount:'12',
                currency:'usd',
                customerId:'cus_HtX9DCAHQMkdjk',
                payment_method_id:'src_1HJk7ZBAvb48eNmDxtPSoBNH',
                uid:'8SO9LIWDRoZVBqWzvhtrNJEhMj42'
            };
        });
        it("Updates membership of a user", async () => {
        spyOn(paymentService["paymentDbService"], "updateMembership").and.resolveTo({
            aud:'eo4u-fde9b',
                auth_time:1598358822,
                email:'leo20@gmail.com',
                email_verified:false,
                exp:1598362422,
                firebase:['{"email":"leo20@gmail.com", "sign_in_provider":"password"}'],
                iat:1598358822,
                iss:'https://securetoken.google.com/eo4u-fde9b',
                sub:'8SO9LIWDRoZVBqWzvhtrNJEhMj42',
                uid:'8SO9LIWDRoZVBqWzvhtrNJEhMj42',
                user_id:'8SO9LIWDRoZVBqWzvhtrNJEhMj42',
                amount:'12',
                currency:'usd',
                customerId:'cus_HtX9DCAHQMkdjk',
                payment_method_id:'src_1HJk7ZBAvb48eNmDxtPSoBNH'
        })
        await expectAsync(paymentService.updateMembership(mockServer,mockRequest,mockRequest["body"])).toBeResolvedTo({
            aud:'eo4u-fde9b',
                auth_time:1598358822,
                email:'leo20@gmail.com',
                email_verified:false,
                exp:1598362422,
                firebase:['{"email":"leo20@gmail.com", "sign_in_provider":"password"}'],
                iat:1598358822,
                iss:'https://securetoken.google.com/eo4u-fde9b',
                sub:'8SO9LIWDRoZVBqWzvhtrNJEhMj42',
                uid:'8SO9LIWDRoZVBqWzvhtrNJEhMj42',
                user_id:'8SO9LIWDRoZVBqWzvhtrNJEhMj42',
                amount:'12',
                currency:'usd',
                customerId:'cus_HtX9DCAHQMkdjk',
                payment_method_id:'src_1HJk7ZBAvb48eNmDxtPSoBNH'
        })
        });
        it("Error while updating membership", async () => {
        spyOn(paymentService["paymentDbService"], "updateMembership").and.rejectWith("Unable to update membership")
        await expectAsync(paymentService.updateMembership(mockServer,mockRequest,mockRequest["body"])).toBeRejectedWith("Unable to update membership")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
})
