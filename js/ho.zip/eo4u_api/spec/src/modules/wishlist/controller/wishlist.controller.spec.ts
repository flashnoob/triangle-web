import { MockReply, MockServer } from './../../../../helpers/common_mock.helper';
import { WishlistController } from './../../../../../src/modules/wishlist/controller/wishlist.controller';

describe("Wishlist controller Unit tests:", () => {
    let wishlistController: WishlistController;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn:any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockReply = new MockReply();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        wishlistController = new WishlistController();
    });
    describe("Add wishlist", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                productId:'eea8cfa3-7ced-4810-bd2b-04ad19589d97',
                userId:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            }
        }) 
        it("Adding product to wishlist", async () =>{
            spyOn(wishlistController["wishlistService"], "addWishList").and.resolveTo({
                address:['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'3-8-1999',
                created_at:'2020-08-10T11:32:17.423Z',
                created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                email:'savishetty18@gmail.com',
                firstName:'Savita',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Shettyar',
                lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                membership_expire:'2020-08-25T11:32:17.423Z',
                modified_at:'',
                modified_by:'',
                object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            })
            await expectAsync(wishlistController.addWishList(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                address:['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'3-8-1999',
                created_at:'2020-08-10T11:32:17.423Z',
                created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                email:'savishetty18@gmail.com',
                firstName:'Savita',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Shettyar',
                lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                membership_expire:'2020-08-25T11:32:17.423Z',
                modified_at:'',
                modified_by:'',
                object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            })
        });
        it("Get Error while adding product wishlist", async () => {
            spyOn(wishlistController["wishlistService"], "addWishList").and.rejectWith(Promise.reject("Unable to add product to wishlist"));
            await expectAsync(wishlistController.addWishList(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to add product to wishlist")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Remove wishlist", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                productId:'eea8cfa3-7ced-4810-bd2b-04ad19589d97',
                userId:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            }
        })
        it("Removing product to wishlist", async () => {
            spyOn(wishlistController["wishlistService"], "removeWishList").and.resolveTo({
                address:['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'3-8-1999',
                created_at:'2020-08-10T11:32:17.423Z',
                created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                email:'savishetty18@gmail.com',
                firstName:'Savita',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Shettyar',
                lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                membership_expire:'2020-08-25T11:32:17.423Z',
                modified_at:'',
                modified_by:'',
                object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            })
            await expectAsync(wishlistController.removeWishList(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                address:['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'3-8-1999',
                created_at:'2020-08-10T11:32:17.423Z',
                created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                email:'savishetty18@gmail.com',
                firstName:'Savita',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Shettyar',
                lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                membership_expire:'2020-08-25T11:32:17.423Z',
                modified_at:'',
                modified_by:'',
                object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            })
        });
        it("Get Error while removing product wishlist", async () => {
            spyOn(wishlistController["wishlistService"], "removeWishList").and.rejectWith(Promise.reject("Unable to remove product to wishlist"));
            await expectAsync(wishlistController.removeWishList(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to remove product to wishlist");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get wishlist", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                userId:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            }
        });
        it("wishlist is empty", async () => {
            spyOn(wishlistController["wishlistService"], "getWishList").and.resolveTo([]);
            await expectAsync(wishlistController.getWishList(mockServer, mockRequest, mockReply)).toBeResolvedTo([]);
        });
        it("Having a product in wishlist", async () => {
            spyOn(wishlistController["wishlistService"], "getWishList").and.resolveTo({
                genusSpecie:'Citrus bergamia',
                image:'SEO8',
                name:'Bergamot',
                objectId:'eea8cfa3-7ced-4810-bd2b-04ad19589d97',
                type:'Single'
            })
            await expectAsync(wishlistController.getWishList(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                genusSpecie:'Citrus bergamia',
                image:'SEO8',
                name:'Bergamot',
                objectId:'eea8cfa3-7ced-4810-bd2b-04ad19589d97',
                type:'Single'
            })
        });
        it("Error from wishlist", async () => {
            spyOn(wishlistController["wishlistService"], "getWishList").and.rejectWith(Promise.reject("Unable to get product from wishlist"));
            await expectAsync(wishlistController.getWishList(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get product from wishlist");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });

    })
});