import { HttpHelper } from "./../../../helpers/http.helper";

describe("Wishlist acceptance test: ", () => {
    const httpHelper: HttpHelper = new HttpHelper();
    beforeAll(() => {
    });

    afterAll(() => {
    });

    describe("/add-wishlist: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    productId: "string",
                    userId: "string"
                };
                result = await httpHelper.request("POST", "/add-wishlist", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/remove-wishlist: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    productId: "string",
                    userId: "string"
                };
                result = await httpHelper.request("PUT", "/remove-wishlist", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-wishlist: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const userId: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("GET", `/get-wishlist/${userId}`);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            } 
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

});