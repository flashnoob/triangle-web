import { WishlistService } from "../../../../../src/modules/wishlist/service/wishlist.service";
import { MockServer } from "../../../../helpers/common_mock.helper";

describe("Wishlist service unit test:", () => {
    let wishlistService: WishlistService;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn:any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        wishlistService = new WishlistService();
        spyOn(wishlistService["redis"], "get").and.resolveTo({});
    });

    describe("Add wishlist", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                productId:'04c9861c-ad6f-4467-a037-05c73ea5fe3f',
                userId:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            }
        })
        it("Adding product to wishlist", async () => {
            spyOn(wishlistService["wishlistService"], "addWishlist").and.resolveTo({
                address: ['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'3-8-1999',
                countryCode:'INR',
                created_at:'2020-08-10T11:32:17.423Z',
                created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                email:'savishetty18@gmail.com',
                firstName:'Savita',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Shettyar',
                lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                membership_expire:'2020-08-25T11:32:17.423Z',
                modified_at:'',
                modified_by:'',
                object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            })
            await expectAsync(wishlistService.addWishList(mockServer, mockRequest, mockRequest["body"])).toBeResolvedTo({
                address: ['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'3-8-1999',
                countryCode:'INR',
                created_at:'2020-08-10T11:32:17.423Z',
                created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                email:'savishetty18@gmail.com',
                firstName:'Savita',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Shettyar',
                lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                membership_expire:'2020-08-25T11:32:17.423Z',
                modified_at:'',
                modified_by:'',
                object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            })
        });
        it("Get Error while adding product wishlist", async () => {
            spyOn(wishlistService["wishlistService"], "addWishlist").and.rejectWith("Unable to add product to wishlist");
            await expectAsync(wishlistService.addWishList(mockServer,mockRequest,mockRequest["body"])).toBeRejectedWith("Unable to add product to wishlist")
        });
        afterAll(() => {
            mockRequest["params"] =  {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        })
    });

    describe("Remove wishlist", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                productId:'eea8cfa3-7ced-4810-bd2b-04ad19589d97',
                userId:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            }
        })
        it("Removing product to wishlist", async () => {
            spyOn(wishlistService["wishlistService"], "removeWishlist").and.resolveTo({
                address: ['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'3-8-1999',
                countryCode:'INR',
                created_at:'2020-08-10T11:32:17.423Z',
                created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                email:'savishetty18@gmail.com',
                firstName:'Savita',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Shettyar',
                lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                membership_expire:'2020-08-25T11:32:17.423Z',
                modified_at:'',
                modified_by:'',
                object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            })
            await expectAsync(wishlistService.removeWishList(mockServer, mockRequest, mockRequest["body"])).toBeResolvedTo({
                address: ['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'3-8-1999',
                countryCode:'INR',
                created_at:'2020-08-10T11:32:17.423Z',
                created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                email:'savishetty18@gmail.com',
                firstName:'Savita',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Shettyar',
                lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                membership_expire:'2020-08-25T11:32:17.423Z',
                modified_at:'',
                modified_by:'',
                object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
            })
        });
        it("Get Error while removing product wishlist", async () => {
            spyOn(wishlistService["wishlistService"], "removeWishlist").and.rejectWith("Unable to remove peoduct to wishlist");
            await expectAsync(wishlistService.removeWishList(mockServer, mockRequest, mockRequest["body"])).toBeRejectedWith("Unable to remove peoduct to wishlist");
        });
        afterAll(() => {
            mockRequest["params"] =  {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        })

        describe("Get wishlist", () => {
            beforeAll(() => {
                mockRequest["query"] = {
                    userId:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
                }
            });
            it("wishlist is empty", async () => {
                spyOn(wishlistService["wishlistService"], "getWishList").and.resolveTo([]);
                await expectAsync(wishlistService.getWishList(mockServer, mockRequest, mockRequest["body"])).toBeResolvedTo([]);
            });
            it("Having a product in wishlist", async () => {
                spyOn(wishlistService["wishlistService"], "getWishList").and.resolveTo({
                    address:['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                    birthday:'3-8-1999',
                    countryCode:'INR',
                    created_at:'2020-08-10T11:32:17.423Z',
                    created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                    email:'savishetty18@gmail.com',
                    firstName:'Savita',
                    healthStatus:'',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Shettyar',
                    lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                    membership_expire:'2020-08-25T11:32:17.423Z',
                    modified_at:'',
                    modified_by:'',
                    object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'female',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
                })
                await expectAsync(wishlistService.getWishList(mockServer, mockRequest, mockRequest["body"])).toBeResolvedTo({
                    address:['{"street1":"9167461570","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                    birthday:'3-8-1999',
                    countryCode:'INR',
                    created_at:'2020-08-10T11:32:17.423Z',
                    created_by:'XCvJgS6YVKbQaLVAfnczkNxe37F2',
                    email:'savishetty18@gmail.com',
                    firstName:'Savita',
                    healthStatus:'',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Shettyar',
                    lastSigninTimestamp:'Mon Aug 10 2020 17:00:48 GMT+0530 (IST)',
                    membership_expire:'2020-08-25T11:32:17.423Z',
                    modified_at:'',
                    modified_by:'',
                    object_id:'1af845a8-291e-4f3f-baa9-a84f3839b814',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'female',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'XCvJgS6YVKbQaLVAfnczkNxe37F2'
                })
            });
            it("Error from wishlist", async () => {
                spyOn(wishlistService["wishlistService"], "getWishList").and.rejectWith("Unable to get product from wishlist");
                await expectAsync(wishlistService.getWishList(mockServer,mockRequest,mockRequest["body"])).toBeRejectedWith("Unable to get product from wishlist");
            });
            afterAll(() => {
                mockRequest["params"] =  {} ;
                mockRequest["query"] = {};
                mockRequest["body"] = {};
            });
    
        })

    })

})