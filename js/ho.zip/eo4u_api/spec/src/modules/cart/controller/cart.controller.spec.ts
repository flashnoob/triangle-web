import { CartController } from "../../../../../src/modules/cart/controller/cart.controller";
import { MockReply, MockServer } from "../../../../helpers/common_mock.helper";

describe("Cart controller Unit tests: ", () => {
    let cartController: CartController;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn:any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockReply = new MockReply();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        cartController = new CartController();
    });

    describe("Get Cart Products", () => {
        beforeAll(() => {
            mockRequest["params"] =  {id :"cCQYH0vQsubIVutJ5cbR643ESKk2"} ;
            mockRequest["query"] = { currencyCode:"INR" };
        });
        it ("Cart is empty", async () => {
            spyOn(cartController["cartService"], "getCartProducts").and.resolveTo([]);
            await expectAsync(cartController.getCartProducts(mockServer, mockRequest, mockReply)).toBeResolvedTo([]);
            expect(cartController["cartService"].getCartProducts).toHaveBeenCalled();
        });
        it (" Product 'Bergamot(Melaleuca, 15mL)' having quantity of n, in cart", async () => {
            // n=3
            expectedReturn = [{
                img:"SEO8",
                objectId:"33351f15-8052-471f-81b3-ef94aa678b48",
                price:"₹100",
                productName:"Bergamot",
                quantity:"15 mL",
                sku:"9333",
                supplier:"Melaleuca",
                unit:"3"}];
            spyOn(cartController["cartService"], "getCartProducts").and.resolveTo(expectedReturn);
            await expectAsync(cartController.getCartProducts(mockServer, mockRequest, mockReply)).toBeResolvedTo([{
                img:"SEO8",
                objectId:"33351f15-8052-471f-81b3-ef94aa678b48",
                price:"₹100",
                productName:"Bergamot",
                quantity:"15 mL",
                sku:"9333",
                supplier:"Melaleuca",
                unit:"3"}]);
            expect(cartController["cartService"].getCartProducts).toHaveBeenCalled();

        });
        it ("Error from cart Service", async () => {
            spyOn(cartController["cartService"], "getCartProducts").and.rejectWith(Promise.reject("Error from the cart-service getCartProducts"));
            await expectAsync(cartController.getCartProducts(mockServer, mockRequest, mockReply)).toBeRejectedWith("Error from the cart-service getCartProducts");
            expect(cartController["cartService"].getCartProducts).toHaveBeenCalled();
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update Units", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                EoName:"Bergamot",
                sku:"9333",
                status:"IN_CART",
                supplier:"Melaleuca",
                uid:"cCQYH0vQsubIVutJ5cbR643ESKk2",
                updatedUnits:"2"
            };
        });
        it("Update units of Cart-item to 2", async () => {
            spyOn(cartController["cartService"], "updateUnits").and
            .resolveTo({
                addedProduct:"Bergamot",
                addedUnits:"2",
                sku:"9333",
                supplier:"Melaleuca",
                userId:"cCQYH0vQsubIVutJ5cbR643ESKk2"
            });
            await expectAsync(cartController.updateUnits(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                addedProduct:"Bergamot",
                addedUnits:"2",
                sku:"9333",
                supplier:"Melaleuca",
                userId:"cCQYH0vQsubIVutJ5cbR643ESKk2"
            });
            expect(cartController["cartService"].updateUnits).toHaveBeenCalled();
        });

        it ("Error from cart Service", async () => {
            spyOn(cartController["cartService"], "updateUnits").and.rejectWith(Promise.reject("Error from the cart-service updateUnits"));
            await expectAsync(cartController.updateUnits(mockServer, mockRequest, mockReply)).toBeRejectedWith("Error from the cart-service updateUnits");
            expect(cartController["cartService"].updateUnits).toHaveBeenCalled();
        });

        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get SKU's units", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                EoName:"Bergamot",
                sku:"9333",
                status:"IN_CART",
                supplier:"Melaleuca",
                uid:"cCQYH0vQsubIVutJ5cbR643ESKk2"
            };
        });
        it("Get units for cart item 'Bergamot' with single unit", async () => {
            spyOn(cartController["cartService"], "getSkus").and.resolveTo("1");
            await expectAsync(cartController.getSkuInCart(mockServer, mockRequest, mockReply)).toBeResolvedTo("1");
            expect(cartController["cartService"].getSkus).toHaveBeenCalled();
        });

        it("Get units for 'Bergamot' when cart does not have it", async () => {
            spyOn(cartController["cartService"], "getSkus").and
            .resolveTo("0");
            await expectAsync(cartController.getSkuInCart(mockServer, mockRequest, mockReply)).toBeResolvedTo("0");
            expect(cartController["cartService"].getSkus).toHaveBeenCalled();
        });

        it ("Error from cart Service", async () => {
            spyOn(cartController["cartService"], "getSkus").and.rejectWith(Promise.reject("Error from the cart-service getSkus"));
            await expectAsync(cartController.getSkuInCart(mockServer, mockRequest, mockReply)).toBeRejectedWith("Error from the cart-service getSkus");
            expect(cartController["cartService"].getSkus).toHaveBeenCalled();
        });
    });
});