import { CartService } from "../../../../../src/modules/cart/service/cart.service";
import { MockServer } from "../../../../helpers/common_mock.helper";


describe("Cart Service Unit tests: ", () => {
  let cartService: CartService;
  let mockRequest: any;
  let mockServer: MockServer;
  let expectedReturn:any;
  const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

  beforeAll(() => {
      mockServer = new MockServer();
      mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
      cartService = new CartService();
      spyOn(cartService["redis"], "get").and.resolveTo({uid});
  });

  describe("Get Cart Products in cart-service", () => {
      beforeAll(() => {
          mockRequest["params"] =  {id :"cCQYH0vQsubIVutJ5cbR643ESKk2"} ;
          mockRequest["query"] = { currencyCode:"INR" };
      });
      it ("Cart is empty", async () => {
          spyOn(cartService["commonDbService"], "querySelector").and.resolveTo([]);
          await expectAsync(cartService.getCartProducts(mockServer, mockRequest)).toBeResolvedTo([]);
      });
      it (" Product 'Bergamot(Melaleuca, 15mL)' having quantity of n, in cart service", async () => {
          // n=3
          expectedReturn = [{
              img:"SEO8",
              objectId:"33351f15-8052-471f-81b3-ef94aa678b48",
              price:"₹100",
              productName:"Bergamot",
              quantity:"15 mL",
              sku:"9333",
              supplier:"Melaleuca",
              unit:"3"}];
          spyOn(cartService["commonDbService"], "querySelector").and.resolveTo(expectedReturn);
          await expectAsync(cartService.getCartProducts(mockServer, mockRequest)).toBeResolvedTo([{
              img:"SEO8",
              objectId:"33351f15-8052-471f-81b3-ef94aa678b48",
              price:"₹100",
              productName:"Bergamot",
              quantity:"15 mL",
              sku:"9333",
              supplier:"Melaleuca",
              unit:"3"}]);

      });
      it ("Error from common-db Service", async () => {
          spyOn(cartService["commonDbService"], "querySelector").and.rejectWith("Error from the common-db.service getCartProducts");
          await expectAsync(cartService.getCartProducts(mockServer, mockRequest)).toBeRejectedWith("Error from the common-db.service getCartProducts");
      });
      afterAll(() => {
          mockRequest["params"] =  {} ;
          mockRequest["query"] = {};
          mockRequest["body"] = {};
      });
  });

  describe("Get SKU's units in cart-service", () => {
      beforeAll(() => {
          mockRequest["body"] = {
              EoName:"Bergamot",
              sku:"9333",
              status:"IN_CART",
              supplier:"Melaleuca",
              uid:"cCQYH0vQsubIVutJ5cbR643ESKk2"
          };
      });
      it("Get units for cart item 'Bergamot' with single unit", async () => {
          spyOn(cartService["cartDbService"], "getSkusInCart").and.resolveTo("1");
          await expectAsync(cartService.getSkus(mockServer, mockRequest)).toBeResolvedTo("1");
      });
      it("Get units for 'Bergamot' when cart does not have it", async () => {
        spyOn(cartService["cartDbService"], "getSkusInCart").and.resolveTo("0");
        await expectAsync(cartService.getSkus(mockServer, mockRequest)).toBeResolvedTo("0");
      });
      it ("Error from cart-db Service", async () => {
        spyOn(cartService["cartDbService"], "getSkusInCart").and.rejectWith("Error from the cart-db.service getSkusInCart");
        await expectAsync(cartService.getSkus(mockServer, mockRequest)).toBeRejectedWith("Error from the cart-db.service getSkusInCart");
    });
  });

  describe("Update Units in cart-service", () => {
    beforeAll(() => {
        mockRequest["body"] = {
            EoName:"Bergamot",
            sku:"9333",
            status:"IN_CART",
            supplier:"Melaleuca",
            uid:"cCQYH0vQsubIVutJ5cbR643ESKk2",
            updatedUnits:"2"
        };
    });
    it("Update units of Cart-item to 2", async () => {
        spyOn(cartService["cartDbService"], "updateUnits").and
        .resolveTo({
            addedProduct:"Bergamot",
            addedUnits:"2",
            sku:"9333",
            supplier:"Melaleuca",
            userId:"cCQYH0vQsubIVutJ5cbR643ESKk2"
        });
        await expectAsync(cartService.updateUnits(mockServer, mockRequest)).toBeResolvedTo({
            addedProduct:"Bergamot",
            addedUnits:"2",
            sku:"9333",
            supplier:"Melaleuca",
            userId:"cCQYH0vQsubIVutJ5cbR643ESKk2"
        });
    });
    it ("Error from cart-db Service", async () => {
      spyOn(cartService["cartDbService"], "updateUnits").and.rejectWith("Error from the cart-db.service updateUnits");
      await expectAsync(cartService.updateUnits(mockServer, mockRequest)).toBeRejectedWith("Error from the cart-db.service updateUnits");
    });
    afterAll(() => {
        mockRequest["params"] =  {} ;
        mockRequest["query"] = {};
        mockRequest["body"] = {};
    });
  });

});