import { HttpHelper } from "../../../helpers/http.helper";

describe("Cart acceptance test: ", () => {

    const httpHelper: HttpHelper = new HttpHelper();
    beforeAll(() => {
    });

    afterAll(() => {
    });

    describe("/get-cart-products/:id: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const id: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("GET", `/get-cart-products/${id}`);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/check-sku-in-cart: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    status: "string",
                    EoName: "string",
                    supplier: "string",
                    size: "string",
                    uid: "string"
                };
                result = await httpHelper.request("PUT", "/check-sku-in-cart", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/update-unit: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    EoName: "Bergamot",
                    sku: "E2",
                    status: "IN_CART",
                    supplier: "escents",
                    uid: "cCQYH0vQsubIVutJ5cbR643ESKk2",
                    updatedUnits: "4"
                };
                result = await httpHelper.request("POST", "/update-unit", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });
});
