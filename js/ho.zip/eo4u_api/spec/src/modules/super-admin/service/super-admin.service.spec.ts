import { SuperAdminService } from './../../../../../src/modules/super-admin/service/super-admin.service';
import { MockServer } from "../../../../helpers/common_mock.helper";

describe("Super-admine service unit test:", () => {
    let superAdminService: SuperAdminService;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn:any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        superAdminService = new SuperAdminService();
        spyOn(superAdminService["redis"], "get").and.resolveTo({});
        spyOn(superAdminService["redis"], "set").and.resolveTo(JSON.stringify({uid}));
    });

    describe("Update User", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                firstName:'John',
                lastName:'Smith'
            };
            mockRequest["params"] = {
                uid:'rDHDm1lu7jg3Ad3LuaAtVQ5vo5j2'
            };
        });
        it("Cancel user update", async () => {
            spyOn(superAdminService["superAdminDbService"], "updateUserByUID").and.resolveTo([])
            await expectAsync(superAdminService.updateUser(mockServer,mockRequest)).toBeRejectedWithError("Error while updating user using uid by superadmin.")
        });
        it("Updated user details", async () => {
            spyOn(superAdminService["superAdminDbService"], "updateUserByUID").and.resolveTo({
                address:['{"street1":"Dggg","street2":"Sfff","city":"Dff","state":"Dfg","country":"Canada","countryCode":"CAD","zip":"545465","defaultAddress":true}'],
                birthday:'19-10-1984',
                created_at:'2020-08-24T11:34:51.961Z',
                created_by:'rDHDm1lu7jg3Ad3LuaAtVQ5vo5j2',
                email:'john20@gmail.com',
                firstName:'John',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Smith',
                lastSigninTimestamp:'Mon Aug 24 2020 17:03:52 GMT+0530 (IST)',
                membership_expire:'2020-09-08T11:34:51.962Z',
                modified_at:'2020-08-24T12:00:25.360Z',
                modified_by:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                object_id:'b1864697-b388-400a-b4df-976999e8bd59',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'male',
                status:'active',
                stripeCustomerID:'',
                uid:'rDHDm1lu7jg3Ad3LuaAtVQ5vo5j2'
            })
            await expectAsync(superAdminService.updateUser(mockServer,mockRequest)).toBeResolvedTo({
                address:['{"street1":"Dggg","street2":"Sfff","city":"Dff","state":"Dfg","country":"Canada","countryCode":"CAD","zip":"545465","defaultAddress":true}'],
                birthday:'19-10-1984',
                created_at:'2020-08-24T11:34:51.961Z',
                created_by:'rDHDm1lu7jg3Ad3LuaAtVQ5vo5j2',
                email:'john20@gmail.com',
                firstName:'John',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Smith',
                lastSigninTimestamp:'Mon Aug 24 2020 17:03:52 GMT+0530 (IST)',
                membership_expire:'2020-09-08T11:34:51.962Z',
                modified_at:'2020-08-24T12:00:25.360Z',
                modified_by:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                object_id:'b1864697-b388-400a-b4df-976999e8bd59',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'male',
                status:'active',
                stripeCustomerID:'',
                uid:'rDHDm1lu7jg3Ad3LuaAtVQ5vo5j2'
            })
        });
        it("Error while updating user details", async () => {
            spyOn(superAdminService["superAdminDbService"], "updateUserByUID").and.rejectWith("Unable to update user")
            await expectAsync(superAdminService.updateUser(mockServer,mockRequest)).toBeRejectedWith("Unable to update user")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Disable user", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
            mockRequest["query"] = {
                StatusBoolean:'true'
            };
        });
        it("Cancel to disable user", async () => {
            spyOn(superAdminService["superAdminDbService"], "disableUserByUID").and.resolveTo([])
            await expectAsync(superAdminService.disableUser(mockServer,mockRequest)).toBeRejectedWithError("Error while removing user using uid by superadmin.")
        });
        it("Disable user", async () => {
            spyOn(superAdminService["superAdminDbService"], "disableUserByUID").and.resolveTo({
                updatedUser: {
                    address: ['{"street1":"sdsad","street2":"gjhgjh","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400085","defaultAddress":true}'],
                    birthday:'20-10-1995',
                    created_at:'2020-08-22T08:34:47.383Z',
                    created_by:'U601BYuTyuUArcqPpPt02WafFbm1',
                    email:'user20@gmail.com',
                    firstName:'User',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Twenty',
                    lastSigninTimestamp:'Sat Aug 22 2020 14:00:26 GMT+0530 (IST)',
                    membership_expire:'2020-09-06T08:34:47.384Z',
                    modified_at:'2020-08-22T08:56:08.823Z',
                    modified_by:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                    object_id:'cbe72240-983b-40f6-9794-a4d124648f94',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'male',
                    status:'inactive',
                    stripeCustomerID:'',
                    uid:'U601BYuTyuUArcqPpPt02WafFbm1'
                }
            })
            await expectAsync(superAdminService.disableUser(mockServer,mockRequest)).toBeResolvedTo({
                updatedUser: {
                    address: ['{"street1":"sdsad","street2":"gjhgjh","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400085","defaultAddress":true}'],
                    birthday:'20-10-1995',
                    created_at:'2020-08-22T08:34:47.383Z',
                    created_by:'U601BYuTyuUArcqPpPt02WafFbm1',
                    email:'user20@gmail.com',
                    firstName:'User',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Twenty',
                    lastSigninTimestamp:'Sat Aug 22 2020 14:00:26 GMT+0530 (IST)',
                    membership_expire:'2020-09-06T08:34:47.384Z',
                    modified_at:'2020-08-22T08:56:08.823Z',
                    modified_by:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                    object_id:'cbe72240-983b-40f6-9794-a4d124648f94',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'male',
                    status:'inactive',
                    stripeCustomerID:'',
                    uid:'U601BYuTyuUArcqPpPt02WafFbm1'
                }
            })
        });
        it("Get error while disabling user when user's not in firebase", async () => {
            spyOn(superAdminService["superAdminDbService"], "disableUserByUID").and.rejectWith("Unable to update user")
            await expectAsync(superAdminService.disableUser(mockServer,mockRequest)).toBeRejectedWith("Unable to update user")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Remove User", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                uid:'U601BYuTyuUArcqPpPt02WafFbm1'
            };
        });
        it("Cancel to remove user", async () => {
            spyOn(superAdminService["superAdminDbService"], "removeUserByUID").and.resolveTo([])
            await expectAsync(superAdminService.removeUser(mockServer,mockRequest)).toBeRejectedWithError("Error while removing user using uid by superadmin.")
        });
        it("Remove User", async () => {
            spyOn(superAdminService["superAdminDbService"], "removeUserByUID").and.resolveTo({
                deletedUser: {
                    address: ['{"street1":"sdsad","street2":"gjhgjh","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400085","defaultAddress":true}'],
                    birthday:'20-10-1995',
                    created_at:'2020-08-22T08:34:47.383Z',
                    created_by:'U601BYuTyuUArcqPpPt02WafFbm1',
                    email:'user20@gmail.com',
                    firstName:'User',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Twenty',
                    lastSigninTimestamp:'Sat Aug 22 2020 14:00:26 GMT+0530 (IST)',
                    membership_expire:'2020-09-06T08:34:47.384Z',
                    modified_at:'2020-08-22T08:56:08.823Z',
                    modified_by:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                    object_id:'cbe72240-983b-40f6-9794-a4d124648f94',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'male',
                    status:'inactive',
                    stripeCustomerID:'',
                    uid:'U601BYuTyuUArcqPpPt02WafFbm1'
                }
            })
            await expectAsync(superAdminService.removeUser(mockServer,mockRequest)).toBeResolvedTo({
                deletedUser: {
                    address: ['{"street1":"sdsad","street2":"gjhgjh","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400085","defaultAddress":true}'],
                    birthday:'20-10-1995',
                    created_at:'2020-08-22T08:34:47.383Z',
                    created_by:'U601BYuTyuUArcqPpPt02WafFbm1',
                    email:'user20@gmail.com',
                    firstName:'User',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Twenty',
                    lastSigninTimestamp:'Sat Aug 22 2020 14:00:26 GMT+0530 (IST)',
                    membership_expire:'2020-09-06T08:34:47.384Z',
                    modified_at:'2020-08-22T08:56:08.823Z',
                    modified_by:'f1GrhEpGmVgcnVPRLjnU45lCfzf2',
                    object_id:'cbe72240-983b-40f6-9794-a4d124648f94',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'male',
                    status:'inactive',
                    stripeCustomerID:'',
                    uid:'U601BYuTyuUArcqPpPt02WafFbm1'
                }
            })
        });
        it("Get error while removing user", async () => {
            spyOn(superAdminService["superAdminDbService"], "removeUserByUID").and.rejectWith("Unable to remove user")
            await expectAsync(superAdminService.removeUser(mockServer,mockRequest)).toBeRejectedWith("Unable to remove user")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    // describe("Get server logs", () => {
    //     beforeAll(() => {
    //     });
    //     it("Get server logs successfully", async () => {
    //     });
    //     it("Error while getting server logs", async () => {
    //     });
    //     afterAll(() => {
    //         mockRequest["params"] = {};
    //         mockRequest["query"] = {};
    //         mockRequest["body"] = {};
    //     });
    // });
    describe("Get EO form data list", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'f1GrhEpGmVgcnVPRLjnU45lCfzf2'
            };
        });
        it("Get empty EO data list", async () => {
            spyOn(superAdminService["superAdminDbService"], "getEoFormDataSet").and.resolveTo([])
            await expectAsync(superAdminService.getEoFormDataList(mockServer,mockRequest)).toBeRejectedWithError("Error while getting Eo data list")
        });
        it("Having a EO form data list", async () => {
            spyOn(superAdminService["superAdminDbService"], "getEoFormDataSet").and.resolveTo({
                genus: ['{"id":"1","value":"Pimenta dioica"}'],
                healthConditions:['{"id":"1","value":"Use Alcohol"}'],
                howToUse: ['{"id":"1","value":"Bath"}'],
                origin: ['{"id":"1","value":"Aerial Parts"}'],
                preparation: ['{"id":"1","value":"Cold Pressed/Expressed"}'],
                recommendedUse: ['{"id":"1","value":"Anxiety"}'],
                reference: ['{"id":"V1","value":"Video 1"}'],
                safetyInformation: ['{"id":"100","value":"Phototoxic"}'],
                storage: ['{"id":"1","value":"Cool, dark place"}']
            })
            await expectAsync(superAdminService.getEoFormDataList(mockServer,mockRequest)).toBeResolvedTo({
                genus: ['{"id":"1","value":"Pimenta dioica"}'],
                healthConditions:['{"id":"1","value":"Use Alcohol"}'],
                howToUse: ['{"id":"1","value":"Bath"}'],
                origin: ['{"id":"1","value":"Aerial Parts"}'],
                preparation: ['{"id":"1","value":"Cold Pressed/Expressed"}'],
                recommendedUse: ['{"id":"1","value":"Anxiety"}'],
                reference: ['{"id":"V1","value":"Video 1"}'],
                safetyInformation: ['{"id":"100","value":"Phototoxic"}'],
                storage: ['{"id":"1","value":"Cool, dark place"}']
            })
        });
        it("Error while getting EO form data list", async () => {
            spyOn(superAdminService["superAdminDbService"], "getEoFormDataSet").and.rejectWith("Unable to get EO form data list")
            await expectAsync(superAdminService.getEoFormDataList(mockServer,mockRequest)).toBeRejectedWith("Unable to get EO form data list")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Disable Eo Genus Specie", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                eoId:'23d4b363-dd9c-40a6-a13b-ca50d84ebd30',
                genusSpecie:'Eugenia caryophyllata'
            };
        });
        it("Empty EO Genus-Specie", async () => {
            spyOn(superAdminService["superAdminDbService"], "disableEoGenusSpecie").and.resolveTo([])
            await expectAsync(superAdminService.disableEoGenusSpecie(mockServer,mockRequest)).toBeRejectedWithError("Error while disabling EO")
        });
        it("Disable EO Genus-Specie", async () => {
            spyOn(superAdminService["superAdminDbService"], "disableEoGenusSpecie").and.resolveTo({
                end: ['{"low":"103","high":"0"}'],
                identity: ['{"low":"7","high":"0"}'],
                properties: ['{"word":"68","status":"disable"}'],
                start: ['{"low":"6","high":"0"}'],
                type:'GENUS_SPECIE'
            })
            await expectAsync(superAdminService.disableEoGenusSpecie(mockServer,mockRequest)).toBeResolvedTo({
                end: ['{"low":"103","high":"0"}'],
                identity: ['{"low":"7","high":"0"}'],
                properties: ['{"word":"68","status":"disable"}'],
                start: ['{"low":"6","high":"0"}'],
                type:'GENUS_SPECIE'
            })
        });
        it("Get error while disable EO genus-specie", async () => {
            spyOn(superAdminService["superAdminDbService"], "disableEoGenusSpecie").and.rejectWith("Unable to disable EO Genus-specie")
            await expectAsync(superAdminService.disableEoGenusSpecie(mockServer,mockRequest)).toBeRejectedWith("Unable to disable EO Genus-specie")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get EO Node", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                objectId: 'eff1fc02-ace7-4c80-871f-ee616bc242a5'
            };
        });
        it("Empty EO node", async () => {
            spyOn(superAdminService["superAdminDbService"], "getEoNode").and.resolveTo([])
            await expectAsync(superAdminService.getEoNode(mockServer,mockRequest)).toBeRejectedWithError("Error while getting geo-node details")
        });
        it("Get EO node details", async () => {
            spyOn(superAdminService["superAdminDbService"], "getEoNode").and.resolveTo({
                eoType:'Single',
                genusOrSpecie:'21',
                healthConditions:'NA',
                howToUse:'6;5;10',
                id:'21',
                image:'SEO8',
                name:'Bergamot',
                objectId:'eff1fc02-ace7-4c80-871f-ee616bc242a5',
                origin:'10',
                preparation:'1',
                recommeneduse:'6',
                reference:'B1',
                safetyInformations:'100;101;N1;N2;N3',
                skuNo:'7;8;9;10;11;12;1009',
                storage:'1'
            })
            await expectAsync(superAdminService.getEoNode(mockServer,mockRequest)).toBeResolvedTo({
                eoType:'Single',
                genusOrSpecie:'21',
                healthConditions:'NA',
                howToUse:'6;5;10',
                id:'21',
                image:'SEO8',
                name:'Bergamot',
                objectId:'eff1fc02-ace7-4c80-871f-ee616bc242a5',
                origin:'10',
                preparation:'1',
                recommeneduse:'6',
                reference:'B1',
                safetyInformations:'100;101;N1;N2;N3',
                skuNo:'7;8;9;10;11;12;1009',
                storage:'1'
            })
        });
        it("Error while getting EO node", async () => {
            spyOn(superAdminService["superAdminDbService"], "getEoNode").and.rejectWith("Unable to get EO node")
            await expectAsync(superAdminService.getEoNode(mockServer,mockRequest)).toBeRejectedWith("Unable to get EO node")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
})