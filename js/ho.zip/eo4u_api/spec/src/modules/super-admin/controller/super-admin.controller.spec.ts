import { MockReply, MockServer } from "../../../../helpers/common_mock.helper";
import { SuperAdminController } from "../../../../../src/modules/super-admin/controller/super-admin.controller";

describe("Super Admin controller Unit tests: ", () => {
    let superAdminController: SuperAdminController;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    const uid = "MX1uJN2jZhTvugZa9Iv4BYLDMa53";

    beforeAll(() => {
        mockServer = new MockServer();
        mockReply = new MockReply();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        superAdminController = new SuperAdminController();
    });
    describe("Update User", () => {
        beforeAll(() => {
            mockRequest["params"] = {uid: "g5CSHTMJxUR8xXeM0P6wY9MUpQU2"};
            mockRequest["body"] = {firstName: "Pinchu", lastName: "Panda"};
        });
        it("Update user details", async () => {
            spyOn(superAdminController["superAdminService"], "updateUser").and.resolveTo({
                address:['{"street1":"Devio","street2":"Kiolio","city":"Daase","state":"Keasde","country":"India","countryCode":"INR","zip":"4895649","defaultAddress":true}'],
                birthday:"8-8-1998",
                created_at:"2020-08-08T10:19:51.305Z",
                created_by:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2",
                email:"zokoravqsertaycvhr@awdrt.com",
                firstName:"Pinchu",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Panda",
                lastSigninTimestamp:"Sat Aug 08 2020 15:49:04 GMT+0530 (IST)",
                membership_expire:"2020-08-23T10:19:51.305Z",
                modified_at:"2020-08-10T08:56:05.173Z",
                modified_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                object_id:"cfdab074-4102-4a08-8ba6-cae0f11c9d05",
                phoneNumber:"98987897",
                premiumUser:false,
                role:"MEMBER",
                sex:"male",
                status:"active",
                stripeCustomerID:"",
                uid:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2"

            });
            await expectAsync(superAdminController.updateUser(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                address:['{"street1":"Devio","street2":"Kiolio","city":"Daase","state":"Keasde","country":"India","countryCode":"INR","zip":"4895649","defaultAddress":true}'],
                birthday:"8-8-1998",
                created_at:"2020-08-08T10:19:51.305Z",
                created_by:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2",
                email:"zokoravqsertaycvhr@awdrt.com",
                firstName:"Pinchu",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Panda",
                lastSigninTimestamp:"Sat Aug 08 2020 15:49:04 GMT+0530 (IST)",
                membership_expire:"2020-08-23T10:19:51.305Z",
                modified_at:"2020-08-10T08:56:05.173Z",
                modified_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                object_id:"cfdab074-4102-4a08-8ba6-cae0f11c9d05",
                phoneNumber:"98987897",
                premiumUser:false,
                role:"MEMBER",
                sex:"male",
                status:"active",
                stripeCustomerID:"",
                uid:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2"
            });
        });
        it("Get error while updating user details", async () => {
            spyOn(superAdminController["superAdminService"], "updateUser").and.rejectWith(Promise.reject("Unable to update user."));
            await expectAsync(superAdminController.updateUser(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to update user.");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Disable user", () => {
        beforeAll(() => {
            mockRequest["params"] = {uid: "g5CSHTMJxUR8xXeM0P6wY9MUpQU2"};
            mockRequest["query"] = {StatusBoolean: "true"};
        });
        it("Disable user details", async () => {
            spyOn(superAdminController["superAdminService"], "disableUser").and.resolveTo({
                updatedUser:{
                    address:['{"street1":"Devio","street2":"Kiolio","city":"Daase","state":"Keasde","country":"India","countryCode":"INR","zip":"4895649","defaultAddress":true}'],
                    birthday:"8-8-1998",
                    created_at:"2020-08-08T10:19:51.305Z",
                    created_by:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2",
                    email:"zokoravqsertaycvhr@awdrt.com",
                    firstName:"Pinchu",
                    img_name:"userName.png",
                    isNewUser:true,
                    lastName:"Panda",
                    lastSigninTimestamp:"Sat Aug 08 2020 15:49:04 GMT+0530 (IST)",
                    membership_expire:"2020-08-23T10:19:51.305Z",
                    modified_at:"2020-08-10T08:56:05.173Z",
                    modified_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    object_id:"cfdab074-4102-4a08-8ba6-cae0f11c9d05",
                    phoneNumber:"98987897",
                    premiumUser:false,
                    role:"MEMBER",
                    sex:"male",
                    status:"disabled",
                    stripeCustomerID:"",
                    uid:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2"
                }
            });
            await expectAsync(superAdminController.disableUser(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                updatedUser:{
                    address:['{"street1":"Devio","street2":"Kiolio","city":"Daase","state":"Keasde","country":"India","countryCode":"INR","zip":"4895649","defaultAddress":true}'],
                    birthday:"8-8-1998",
                    created_at:"2020-08-08T10:19:51.305Z",
                    created_by:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2",
                    email:"zokoravqsertaycvhr@awdrt.com",
                    firstName:"Pinchu",
                    img_name:"userName.png",
                    isNewUser:true,
                    lastName:"Panda",
                    lastSigninTimestamp:"Sat Aug 08 2020 15:49:04 GMT+0530 (IST)",
                    membership_expire:"2020-08-23T10:19:51.305Z",
                    modified_at:"2020-08-10T08:56:05.173Z",
                    modified_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    object_id:"cfdab074-4102-4a08-8ba6-cae0f11c9d05",
                    phoneNumber:"98987897",
                    premiumUser:false,
                    role:"MEMBER",
                    sex:"male",
                    status:"disabled",
                    stripeCustomerID:"",
                    uid:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2"
                }
            });
        });
        it("Get error while disabling user when user's not in firebase", async () => {
            spyOn(superAdminController["superAdminService"], "disableUser").and.rejectWith(Promise.reject("There is no user record corresponding to the provided identifier."));
            await expectAsync(superAdminController.disableUser(mockServer, mockRequest, mockReply)).toBeRejectedWith("There is no user record corresponding to the provided identifier.");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Remove User", () => {
        beforeAll(() => {
            mockRequest["params"] = {uid: "g5CSHTMJxUR8xXeM0P6wY9MUpQU2"};
        });
        it("Remove User details", async () => {
            spyOn(superAdminController["superAdminService"], "removeUser").and.resolveTo({
                deletedUser:{
                    address:['{"street1":"Devio","street2":"Kiolio","city":"Daase","state":"Keasde","country":"India","countryCode":"INR","zip":"4895649","defaultAddress":true}'],
                    birthday:"8-8-1998",
                    created_at:"2020-08-08T10:19:51.305Z",
                    created_by:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2",
                    email:"zokoravqsertaycvhr@awdrt.com",
                    firstName:"Pinchu",
                    img_name:"userName.png",
                    isNewUser:true,
                    lastName:"Panda",
                    lastSigninTimestamp:"Sat Aug 08 2020 15:49:04 GMT+0530 (IST)",
                    membership_expire:"2020-08-23T10:19:51.305Z",
                    modified_at:"2020-08-10T08:56:05.173Z",
                    modified_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    object_id:"cfdab074-4102-4a08-8ba6-cae0f11c9d05",
                    phoneNumber:"98987897",
                    premiumUser:false,
                    role:"MEMBER",
                    sex:"male",
                    status:"inactive",
                    stripeCustomerID:"",
                    uid:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2"
                }
            });
            await expectAsync(superAdminController.removeUser(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                deletedUser:{
                    address:['{"street1":"Devio","street2":"Kiolio","city":"Daase","state":"Keasde","country":"India","countryCode":"INR","zip":"4895649","defaultAddress":true}'],
                    birthday:"8-8-1998",
                    created_at:"2020-08-08T10:19:51.305Z",
                    created_by:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2",
                    email:"zokoravqsertaycvhr@awdrt.com",
                    firstName:"Pinchu",
                    img_name:"userName.png",
                    isNewUser:true,
                    lastName:"Panda",
                    lastSigninTimestamp:"Sat Aug 08 2020 15:49:04 GMT+0530 (IST)",
                    membership_expire:"2020-08-23T10:19:51.305Z",
                    modified_at:"2020-08-10T08:56:05.173Z",
                    modified_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    object_id:"cfdab074-4102-4a08-8ba6-cae0f11c9d05",
                    phoneNumber:"98987897",
                    premiumUser:false,
                    role:"MEMBER",
                    sex:"male",
                    status:"inactive",
                    stripeCustomerID:"",
                    uid:"g5CSHTMJxUR8xXeM0P6wY9MUpQU2"
                }
            });
        });
        it("Get error while removing user", async () => {
            spyOn(superAdminController["superAdminService"], "removeUser").and.rejectWith(Promise.reject("Unable to remove user"));
            await expectAsync(superAdminController.removeUser(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to remove user");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Get server logs", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                filterValues:'[{"name":"User","value":[]},{"name":"STATUS","value":[]},{"name":"Dates","value":[]}]',
                limit:10,
                offset:0,
                searchText:'',
                sortByBoolean:'true',
                sortObject:'{"sortByBoolean":true,"alphaNumericSortBooleanMessage":false,"alphaNumericSortBooleanLevel":false,"alphaNumericSortBooleanHostName":false}',
                uid:'RB0rswcyvOVZNI5SpzDrq7rV2O63'
            };
        });
        it("Get server logs", async () => {
            spyOn(superAdminController["superAdminService"], "getServerLogs").and.resolveTo({
                data: ['{"hostname":"savi-Inspiron-15-3565","level":"Success Log","msg":"Get server logs request recieved.","name":"EO4U_api","pid":"26681","time":"8/20/2020","6:04:51 PM","user":"RB0rswcyvOVZNI5SpzDrq7rV2O63""v":"1"}'],
                filterData: {
                    user: ['RB0rswcyvOVZNI5SpzDrq7rV2O63', 'f1GrhEpGmVgcnVPRLjnU45lCfzf2', 'G72JtXPRCuOjYAEwS7X8TazOac33', 'UjogDL4HpkOHhMeI5Im1HtCJcX82', 'mUWxE5sPo8SSLoztJbklZDFbp3N2', '3rMXiyIkm8OLpy0CVRwgNnFAWd42', 'pQ66F4cLcETMfdcj4j9H76VT5Hr2', 'bvXNA0GXVNNtqDifVMqNyv4bN7H3', 'XCvJgS6YVKbQaLVAfnczkNxe37F2', 'C7FN6846i0R6CjJ50cLWf7f1Qvw2', 'bSSK9cbaolfdI83s8djGGjOIrnd2', 'EkoUJxDux1TP6Ezz5QrxOezWmK42', 'Iz3hkOQvWHRtKCnpFZVoi64Xa0r1'],
                    level: ['Success Log', 'Error Log'],
                    month: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
                },
                size:8517
            })
            await expectAsync(superAdminController.getServerLogs(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                data: ['{"hostname":"savi-Inspiron-15-3565","level":"Success Log","msg":"Get server logs request recieved.","name":"EO4U_api","pid":"26681","time":"8/20/2020","6:04:51 PM","user":"RB0rswcyvOVZNI5SpzDrq7rV2O63""v":"1"}'],
                filterData: {
                    user: ['RB0rswcyvOVZNI5SpzDrq7rV2O63', 'f1GrhEpGmVgcnVPRLjnU45lCfzf2', 'G72JtXPRCuOjYAEwS7X8TazOac33', 'UjogDL4HpkOHhMeI5Im1HtCJcX82', 'mUWxE5sPo8SSLoztJbklZDFbp3N2', '3rMXiyIkm8OLpy0CVRwgNnFAWd42', 'pQ66F4cLcETMfdcj4j9H76VT5Hr2', 'bvXNA0GXVNNtqDifVMqNyv4bN7H3', 'XCvJgS6YVKbQaLVAfnczkNxe37F2', 'C7FN6846i0R6CjJ50cLWf7f1Qvw2', 'bSSK9cbaolfdI83s8djGGjOIrnd2', 'EkoUJxDux1TP6Ezz5QrxOezWmK42', 'Iz3hkOQvWHRtKCnpFZVoi64Xa0r1'],
                    level: ['Success Log', 'Error Log'],
                    month: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
                },
                size:8517
            })
        });
        it("Error while getting server logs", async () => {
            spyOn(superAdminController["superAdminService"], "getServerLogs").and.rejectWith(Promise.reject("Unable to remove user"));
            await expectAsync(superAdminController.getServerLogs(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to remove user");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get EO data list", () => {
        beforeAll(() => {

        });
        it("Get empty EO data list", async () => {
            spyOn(superAdminController["superAdminService"], "getEoFormDataList").and.resolveTo([])
            await expectAsync(superAdminController.getEoDataList(mockServer,mockRequest,mockReply)).toBeResolvedTo([])
        });
        it("Having a EO form data list", async () => {
            spyOn(superAdminController["superAdminService"], "getEoFormDataList").and.resolveTo({
                genus: ['{"id":"1","value":"Pimenta dioica"}'],
                healthConditions: ['{"id":"1","value":"Use Alcohol"}'],
                howToUse: ['{"id":"1","value":"Bath"}'],
                origin: ['{"id":"1","value":"Aerial Parts"}'],
                preparation: ['{"id":"1","value":"Cold Pressed/Expressed"}'],
                recommendedUse: ['{"id":"1","value":"Anxiety"}'],
                reference: ['{"id":"V1","value":"Video 1"}'],
                safetyInformation: ['{"id":"100","value":"Phototoxic"}'],
                storage: ['{"id":"1","value":"Cool, dark place"}']
            })
            await expectAsync(superAdminController.getEoDataList(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                genus: ['{"id":"1","value":"Pimenta dioica"}'],
                healthConditions: ['{"id":"1","value":"Use Alcohol"}'],
                howToUse: ['{"id":"1","value":"Bath"}'],
                origin: ['{"id":"1","value":"Aerial Parts"}'],
                preparation: ['{"id":"1","value":"Cold Pressed/Expressed"}'],
                recommendedUse: ['{"id":"1","value":"Anxiety"}'],
                reference: ['{"id":"V1","value":"Video 1"}'],
                safetyInformation: ['{"id":"100","value":"Phototoxic"}'],
                storage: ['{"id":"1","value":"Cool, dark place"}']
            })
        });
        it("Error while getting EO form data list", async () => {
            spyOn(superAdminController["superAdminService"], "getEoFormDataList").and.rejectWith(Promise.reject("Unable to get EO form data list"))
            await expectAsync(superAdminController.getEoDataList(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to get EO form data list")
        })
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Disable Eo GenusSpecie", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                eoId:'5311871e-dbea-4843-9dc3-7d959ad10436',
                genusSpecie:'Cocos nucifera L'
            };
        });
        it("Disable EO Genus-Specie", async () => {
            spyOn(superAdminController["superAdminService"], "disableEoGenusSpecie").and.resolveTo({
                end: ['{"low":"108","high":"0"}'],
                identity: ['{"low":"39","high":"0"}'],
                properties: ['{"word":"73","status":"disable"}'],
                start: ['{"low":"37","high":"0"}'],
                type:'GENUS_SPECIE'
            })
            await expectAsync(superAdminController.disableEoGenusSpecie(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                end: ['{"low":"108","high":"0"}'],
                identity: ['{"low":"39","high":"0"}'],
                properties: ['{"word":"73","status":"disable"}'],
                start: ['{"low":"37","high":"0"}'],
                type:'GENUS_SPECIE'
            })
        });
        it("Get error while disable EO genus-specie", async () => {
            spyOn(superAdminController["superAdminService"], "disableEoGenusSpecie").and.rejectWith(Promise.reject("Unable to disable EO Genus-specie"))
            await expectAsync(superAdminController.disableEoGenusSpecie(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to disable EO Genus-specie")
        })
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    describe("Get Eo Node", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                objectId: 'eff1fc02-ace7-4c80-871f-ee616bc242a5'
            };
        });
        it("Empty EO node", async () => {
            spyOn(superAdminController["superAdminService"], "getEoNode").and.resolveTo([])
            await expectAsync(superAdminController.getEoNode(mockServer,mockRequest,mockReply)).toBeResolvedTo([])
        });
        it("Get EO node details", async () => {
            spyOn(superAdminController["superAdminService"], "getEoNode").and.resolveTo({
                eoType:'Single',
                genusOrSpecie:'21',
                healthConditions:'NA',
                howToUse:'6;5;10',
                id:'21',
                image:'SEO8',
                name:'Bergamot',
                objectId:'eff1fc02-ace7-4c80-871f-ee616bc242a5',
                origin:'10',
                preparation:'1',
                recommeneduse:'6',
                reference:'B1',
                safetyInformations:'100;101;N1;N2;N3',
                skuNo:'7;8;9;10;11;12;1009',
                storage:'1'
            })
            await expectAsync(superAdminController.getEoNode(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                eoType:'Single',
                genusOrSpecie:'21',
                healthConditions:'NA',
                howToUse:'6;5;10',
                id:'21',
                image:'SEO8',
                name:'Bergamot',
                objectId:'eff1fc02-ace7-4c80-871f-ee616bc242a5',
                origin:'10',
                preparation:'1',
                recommeneduse:'6',
                reference:'B1',
                safetyInformations:'100;101;N1;N2;N3',
                skuNo:'7;8;9;10;11;12;1009',
                storage:'1'
            })
        });
        
        it("Error while getting EO node", async () => {
            spyOn(superAdminController["superAdminService"], "getEoNode").and.rejectWith(Promise.reject("Unable to get EO node"))
            await expectAsync(superAdminController.getEoNode(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get EO node")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
});