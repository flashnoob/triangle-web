import { HttpHelper } from "./../../../helpers/http.helper";

describe("Relatives acceptance test:", () => {
    const httpHelper: HttpHelper = new HttpHelper();
    beforeAll(() => {
    });

    afterAll(() => {
    });

    describe("/add-forf: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    label: "string",
                    user_info: {
                        relation: "string",
                        firstName: "string",
                        lastName: "string",
                        phone: "string",
                        birthday: "string",
                        email: "string",
                        street1: "string",
                        street2: "string",
                        zip: "string",
                        city: "string",
                        state: "string",
                        isNewUser: true,
                        created_by: "string"
                    }
                };
                result = await httpHelper.request("POST", "/add-forf", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-relatives/uid: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const uid: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("GET", `/get-relatives/${uid}`);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/update-relative: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    firstName: "string",
                    lastName: "string",
                    phone: "string",
                    birthday: "string",
                    healthStatus: "string",
                    email: "string",
                    street1: "string",
                    street2: "string",
                    zip: "string",
                    city: "string",
                    state: "string",
                    isNewUser: true,
                    relation: "string",
                    created_by: "string",
                    object_id: "string"
                };
                result = await httpHelper.request("PUT", "/update-relative", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/remove-relative/:objectId: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const objectId: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("PUT", `/remove-relative/${objectId}`);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

});