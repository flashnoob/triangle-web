import { MockReply, MockServer } from "./../../../../helpers/common_mock.helper";
import { RelativesController } from "./../../../../../src/modules/relatives/controller/relatives.controller";

describe("Relatives controller Unit tests:", () => {
    let relativesController: RelativesController;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockReply = new MockReply();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        relativesController = new RelativesController();
    });

    describe("Add Relatives", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                label:"FOF",
                uid: "pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            };
        });
        it("Adding relatives details", async () => {
            spyOn(relativesController["relativesService"], "addRelative").and.resolveTo({
                birthday:"12-10-1984",
                city:"Mumbai",
                country:"India",
                created_at:"2020-08-12T15:03:40.705Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user3@gmail.com",
                firstName:"User",
                healthStatus:"Epilepsy,Epilepsy",
                lastName:"3",
                modified_at:"",
                modified_by:"",
                object_id:"2f4c38f4-0bfc-4bf6-ad94-9d3e1c9e59e0",
                phone:"9898989898",
                relation:"Father",
                role:"RELATIVE",
                state:"Maharashtra",
                street1:"Erty",
                street2:"Ert",
                zip:"400067"
            });
            await expectAsync(relativesController.addRelative(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                birthday:"12-10-1984",
                city:"Mumbai",
                country:"India",
                created_at:"2020-08-12T15:03:40.705Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user3@gmail.com",
                firstName:"User",
                healthStatus:"Epilepsy,Epilepsy",
                lastName:"3",
                modified_at:"",
                modified_by:"",
                object_id:"2f4c38f4-0bfc-4bf6-ad94-9d3e1c9e59e0",
                phone:"9898989898",
                relation:"Father",
                role:"RELATIVE",
                state:"Maharashtra",
                street1:"Erty",
                street2:"Ert",
                zip:"400067"
            });
        });
        it("Get Error while adding relatives", async () => {
            spyOn(relativesController["relativesService"], "addRelative").and.rejectWith(Promise.reject("Unable to add relative"));
            await expectAsync(relativesController.addRelative(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to add relative");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get list of all the relatives", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            };
        });
        it("relative list is empty", async () => {
            spyOn(relativesController["relativesService"], "getRelatives").and.resolveTo([]);
            await expectAsync(relativesController.getRelativeList(mockServer, mockRequest, mockReply)).toBeResolvedTo([]);
        });
        it("Having a relative list", async () => {
            spyOn(relativesController["relativesService"], "getRelatives").and.resolveTo({
                birthday:"12-8-1971",
                city:"Mumbai",
                country:"India",
                created_at:"2020-08-12T14:42:26.110Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user1@gmail.com",
                firstName:"User",
                healthStatus:"28",
                lastName:"One",
                modified_at:"",
                modified_by:"",
                object_id:"19ecc0b2-e644-41c2-a190-bb4d9db6d2f4",
                phone:"9595959595",
                relation:"Father",
                role:"RELATIVE",
                sex:"male",
                state:"Maharashtra",
                street1:"Rhds",
                street2:"Dhhd",
                zip:"400067"
            });
            await expectAsync(relativesController.getRelativeList(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                birthday:"12-8-1971",
                city:"Mumbai",
                country:"India",
                created_at:"2020-08-12T14:42:26.110Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user1@gmail.com",
                firstName:"User",
                healthStatus:"28",
                lastName:"One",
                modified_at:"",
                modified_by:"",
                object_id:"19ecc0b2-e644-41c2-a190-bb4d9db6d2f4",
                phone:"9595959595",
                relation:"Father",
                role:"RELATIVE",
                sex:"male",
                state:"Maharashtra",
                street1:"Rhds",
                street2:"Dhhd",
                zip:"400067"
            });
        });
        it("Error in relative list", async () => {
            spyOn(relativesController["relativesService"], "getRelatives").and.rejectWith(Promise.reject("Unable to get relative details"));
            await expectAsync(relativesController.getRelativeList(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to get relative details");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update family member", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                array:[{
                    birthday:"12-8-1971",
                    city:"Mumbai",
                    country:"India",
                    created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                    email:"user1@gmail.com",
                    firstName:"User",
                    healthStatus:"28",
                    lastName:"Two",
                    modified_at:"2020-08-12T15:50:58.032Z",
                    modified_by:"By User",
                    object_id:"19ecc0b2-e644-41c2-a190-bb4d9db6d2f4",
                    phone:"9595959595",
                    relation:"Father",
                    sex:"male",
                    state:"Maharashtra",
                    street1:"Rhds",
                    street2:"Dhhd",
                    zip:"400067"
                }],
                uid: "pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            };
        });
        it("Updating relative details ", async () => {
            spyOn(relativesController["relativesService"], "updateRelative").and.resolveTo({
                birthday:"12-8-1971",
                city:"Mumbai",
                country:"India",
                created_at:"2020-08-12T14:42:26.110Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user1@gmail.com",
                firstName:"User",
                healthStatus:"Sensitive Skin",
                lastName:"Two",
                modified_at:"2020-08-12T15:50:58.032Z",
                modified_by:"By User",
                object_id:"19ecc0b2-e644-41c2-a190-bb4d9db6d2f4",
                phone:"9595959595",
                relation:"Father",
                role:"RELATIVE",
                sex:"male",
                state:"Maharashtra",
                street1:"Rhds",
                street2:"Dhhd",
                zip:"400067"
            });
            await expectAsync(relativesController.updateFamilyMember(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                birthday:"12-8-1971",
                city:"Mumbai",
                country:"India",
                created_at:"2020-08-12T14:42:26.110Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user1@gmail.com",
                firstName:"User",
                healthStatus:"Sensitive Skin",
                lastName:"Two",
                modified_at:"2020-08-12T15:50:58.032Z",
                modified_by:"By User",
                object_id:"19ecc0b2-e644-41c2-a190-bb4d9db6d2f4",
                phone:"9595959595",
                relation:"Father",
                role:"RELATIVE",
                sex:"male",
                state:"Maharashtra",
                street1:"Rhds",
                street2:"Dhhd",
                zip:"400067"
            });
        });
        it("Error while updating relatives detail", async () => {
            spyOn(relativesController["relativesService"], "updateRelative").and.rejectWith(Promise.reject("Unable to update relative details"));
            await expectAsync(relativesController.updateFamilyMember(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to update relative details");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Remove user relation", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                objectId:"19ecc0b2-e644-41c2-a190-bb4d9db6d2f4",
                uid: "pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            };
        });
        it("Removing relative details", async () => {
            spyOn(relativesController["relativesService"], "deleteRelation").and.resolveTo([]);
            await expectAsync(relativesController.removeUserRelation(mockServer, mockRequest, mockReply)).toBeResolvedTo([]);
        });
        it("Get Error while removing relative details", async () => {
            spyOn(relativesController["relativesService"], "deleteRelation").and.rejectWith(Promise.reject("Unable to remove relative detail"));
            await expectAsync(relativesController.removeUserRelation(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to remove relative detail");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
});