import { MockServer } from "./../../../../helpers/common_mock.helper";
import { RelativesService } from "./../../../../../src/modules/relatives/service/relatives.service";

describe("Relatives service Unit tests:", () => {
    let relativesService: RelativesService;
    let mockRequest: any;
    let mockServer: MockServer;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        relativesService = new RelativesService();
        spyOn(relativesService["redis"], "get").and.resolveTo({});
    });

    describe("Add Relatives", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                label:"FOF",
                uid: "pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                user_info: [{
                    birthday:"8-11-1975",
                    city:"Mumbai",
                    country:"India",
                    created_at:"2020-08-13T08:45:09.925Z",
                    created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                    email:"user3@gmail.com",
                    firstName:"User",
                    healthStatus:"13",
                    lastName:"Three",
                    modified_at:"",
                    modified_by:"",
                    object_id:"bf94da69-54d0-4b9f-af19-9143951ad9ef",
                    phone:"9898989898",
                    relation:"Father",
                    role:"RELATIVE",
                    sex:"male",
                    state:"Maharashtra",
                    street1:"Fghj",
                    street2:"Rtyu",
                    zip:"400067",
                }]
            };
        });
        it("Adding relatives details", async () => {
            spyOn(relativesService["relativeDbService"], "addRelative").and.resolveTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"9898989898","street2":"9999999999","zip":"400067"}'],
                birthday:"12-8-1995",
                countryCode:"INR",
                created_at:"2020-08-12T14:22:57.150Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user4@gmail.com",
                firstName:"User",
                healthStatus:"",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Four",
                lastSigninTimestamp:"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)",
                membership_expire:"2020-08-27T14:22:57.151Z",
                modified_at:"",
                modified_by:"",
                object_id:"27e8ed27-c1ac-426a-82f2-0e71933ed406",
                phoneNumber:"9898989898",
                premiumUser:false,
                role:"RELATIVE",
                sex:"female",
                status:"active",
                stripeCustomerID:"",
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            });
            await expectAsync(relativesService.addRelative(mockServer, mockRequest)).toBeResolvedTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"9898989898","street2":"9999999999","zip":"400067"}'],
                birthday:"12-8-1995",
                countryCode:"INR",
                created_at:"2020-08-12T14:22:57.150Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user4@gmail.com",
                firstName:"User",
                healthStatus:"",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Four",
                lastSigninTimestamp:"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)",
                membership_expire:"2020-08-27T14:22:57.151Z",
                modified_at:"",
                modified_by:"",
                object_id:"27e8ed27-c1ac-426a-82f2-0e71933ed406",
                phoneNumber:"9898989898",
                premiumUser:false,
                role:"RELATIVE",
                sex:"female",
                status:"active",
                stripeCustomerID:"",
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            });
        });
        it("Get Error while adding relatives", async () => {
            spyOn(relativesService["relativeDbService"], "addRelative").and.rejectWith("Unable to add relative");
            await expectAsync(relativesService.addRelative(mockServer, mockRequest)).toBeRejectedWith("Unable to add relative");
        });

        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get list of all the relatives", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                label:"FOF"
            };
        });
        it("relative list is empty", async () => {
            spyOn(relativesService["relativeDbService"], "getRelatives").and.resolveTo([]);
            await expectAsync(relativesService.getRelatives(mockRequest, mockRequest, mockServer)).toBeResolvedTo([]);
        });
        it("Having a relative list", async () => {
            spyOn(relativesService["relativeDbService"], "getRelatives").and.resolveTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"9898989898","street2":"9999999999","zip":"400067"}'],
                birthday:"12-8-1995",
                countryCode:"INR",
                created_at:"2020-08-12T14:22:57.150Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user4@gmail.com",
                firstName:"User",
                healthStatus:"",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Four",
                lastSigninTimestamp:"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)",
                membership_expire:"2020-08-27T14:22:57.151Z",
                modified_at:"",
                modified_by:"",
                object_id:"27e8ed27-c1ac-426a-82f2-0e71933ed406",
                phoneNumber:"9898989898",
                premiumUser:false,
                role:"RELATIVE",
                sex:"female",
                status:"active",
                stripeCustomerID:"",
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            });
            await expectAsync(relativesService.getRelatives(mockRequest, mockRequest, mockServer)).toBeResolvedTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"9898989898","street2":"9999999999","zip":"400067"}'],
                birthday:"12-8-1995",
                countryCode:"INR",
                created_at:"2020-08-12T14:22:57.150Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user4@gmail.com",
                firstName:"User",
                healthStatus:"",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Four",
                lastSigninTimestamp:"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)",
                membership_expire:"2020-08-27T14:22:57.151Z",
                modified_at:"",
                modified_by:"",
                object_id:"27e8ed27-c1ac-426a-82f2-0e71933ed406",
                phoneNumber:"9898989898",
                premiumUser:false,
                role:"RELATIVE",
                sex:"female",
                status:"active",
                stripeCustomerID:"",
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            });
        });
        it("Error in relative list", async () => {
            spyOn(relativesService["relativeDbService"], "getRelatives").and.rejectWith("Unable to get relative");
            await expectAsync(relativesService.getRelatives(mockRequest, mockRequest, mockServer)).toBeRejectedWith("Unable to get relative");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update family member details", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                user_info: [{
                    birthday:"28-10-1979",
                    city:"Mumbai",
                    country:"India",
                    created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                    email:"user2@gmail.com",
                    firstName:"User",
                    healthStatus:"28",
                    lastName:"Two",
                    modified_at:"2020-08-13T11:37:25.260Z",
                    modified_by:"By User",
                    object_id:"5149c8ef-974d-4b32-9d14-a922913e057d",
                    phone:"9797979797",
                    relation:"Mother",
                    sex:"female",
                    state:"Maharashtra",
                    street1:"Rty",
                    street2:"Asf",
                    zip:"400067"
                }]
            };
        });
        it("Relative details is empty", async () => {
            spyOn(relativesService["relativeDbService"], "updateRelative").and.resolveTo([])
            await expectAsync(relativesService.updateRelative(mockServer, mockRequest)).toBeResolvedTo([])
        });
        it("Updating Relative details", async () => {
            spyOn(relativesService["relativeDbService"], "updateRelative").and.resolveTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"9898989898","street2":"9999999999","zip":"400067"}'],
                birthday:"12-8-1995",
                countryCode:"INR",
                created_at:"2020-08-12T14:22:57.150Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user4@gmail.com",
                firstName:"User",
                healthStatus:"",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Four",
                lastSigninTimestamp:"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)",
                membership_expire:"2020-08-27T14:22:57.151Z",
                modified_at:"",
                modified_by:"",
                object_id:"27e8ed27-c1ac-426a-82f2-0e71933ed406",
                phoneNumber:"9898989898",
                premiumUser:false,
                role:"RELATIVE",
                sex:"female",
                status:"active",
                stripeCustomerID:"",
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            });
            await expectAsync(relativesService.updateRelative(mockServer, mockRequest)).toBeResolvedTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"9898989898","street2":"9999999999","zip":"400067"}'],
                birthday:"12-8-1995",
                countryCode:"INR",
                created_at:"2020-08-12T14:22:57.150Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user4@gmail.com",
                firstName:"User",
                healthStatus:"",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Four",
                lastSigninTimestamp:"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)",
                membership_expire:"2020-08-27T14:22:57.151Z",
                modified_at:"",
                modified_by:"",
                object_id:"27e8ed27-c1ac-426a-82f2-0e71933ed406",
                phoneNumber:"9898989898",
                premiumUser:false,
                role:"RELATIVE",
                sex:"female",
                status:"active",
                stripeCustomerID:"",
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            });
        });
        it("Error while updating relatives detail", async () => {
            spyOn(relativesService["relativeDbService"], "updateRelative").and.rejectWith("Unable to update relative details");
            await expectAsync(relativesService.updateRelative(mockServer, mockRequest)).toBeRejectedWith("Unable to update relative details");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Remove user relation", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                objectId:"842d82b1-80b5-4a78-96d0-3ce838b5eeac",
                uid: "pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            };
        });
        it("Removing relative details", async () => {
            spyOn(relativesService["relativeDbService"], "deleteRelative").and.resolveTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"9898989898","street2":"9999999999","zip":"400067"}'],
                birthday:"12-8-1995",
                countryCode:"INR",
                created_at:"2020-08-12T14:22:57.150Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user4@gmail.com",
                firstName:"User",
                healthStatus:"",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Four",
                lastSigninTimestamp:"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)",
                membership_expire:"2020-08-27T14:22:57.151Z",
                modified_at:"",
                modified_by:"",
                object_id:"27e8ed27-c1ac-426a-82f2-0e71933ed406",
                phoneNumber:"9898989898",
                premiumUser:false,
                role:"RELATIVE",
                sex:"female",
                status:"active",
                stripeCustomerID:"",
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            });
            await expectAsync(relativesService.deleteRelation(mockServer, mockRequest, mockRequest)).toBeResolvedTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"9898989898","street2":"9999999999","zip":"400067"}'],
                birthday:"12-8-1995",
                countryCode:"INR",
                created_at:"2020-08-12T14:22:57.150Z",
                created_by:"pQ66F4cLcETMfdcj4j9H76VT5Hr2",
                email:"user4@gmail.com",
                firstName:"User",
                healthStatus:"",
                img_name:"userName.png",
                isNewUser:true,
                lastName:"Four",
                lastSigninTimestamp:"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)",
                membership_expire:"2020-08-27T14:22:57.151Z",
                modified_at:"",
                modified_by:"",
                object_id:"27e8ed27-c1ac-426a-82f2-0e71933ed406",
                phoneNumber:"9898989898",
                premiumUser:false,
                role:"RELATIVE",
                sex:"female",
                status:"active",
                stripeCustomerID:"",
                uid:"pQ66F4cLcETMfdcj4j9H76VT5Hr2"
            });
        });
        it("Get Error while removing relative detail", async () => {
            spyOn(relativesService["relativeDbService"], "deleteRelative").and.rejectWith("Unable to remove relative details");
            await expectAsync(relativesService.deleteRelation(mockServer, mockRequest, mockRequest)).toBeRejectedWith("Unable to remove relative details");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
});