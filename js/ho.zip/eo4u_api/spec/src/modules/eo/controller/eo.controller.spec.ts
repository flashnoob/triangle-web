import { EoController } from "../../../../../src/modules/eo/controller/eo.controller";
import { MockReply, MockServer } from "../../../../helpers/common_mock.helper";

describe("EO Controller", () => {
    let eoController: EoController;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";
    // Set-up the mock server, reply and request
    beforeAll(() => {
        mockServer = new MockServer();
        mockReply = new MockReply();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        eoController = new EoController();
    });

    describe("Get Essential Oil", () => {
        beforeAll(() => {
            mockRequest["query"] = { currencyCode:"INR", id:"0bbec948-b5c6-4822-bda0-5687fa09e0b0" };
        });

        it("When essential oil exist with given id", async () => {
            spyOn(eoController["eoService"], "getEo").and.resolveTo({
                "img": "SEO8",
                "references": [
                    "Safety Oil (Tisserand, 2019)"
                ],
                "primaryUses": [
                    "Insomnia"
                ],
                "productId": null,
                "storage": [
                    "Cool",
                    "dark place"
                ],
                "safetyInformation": [
                    "Oxidized Oil",
                    "Phototoxic",
                    "Children/Pets",
                    "Avoid Eyes",
                    "Medication Patch Use"
                ],
                "howToUse": [
                    "Massage",
                    "Apply topically ",
                    "Diffuse"
                ],
                "blendsWellWith": [
                    "Citrus oils",
                    "frankincense",
                    "geranium",
                    "jasmine",
                    "lavender",
                    "sandalwood",
                    "ylang-ylang"
                ],
                "effects": [],
                "basicInformation": {
                    "preparationMethod": [
                        "Cold Pressed/Expressed"
                    ],
                    "origin": [
                        "Peel"
                    ]
                },
                "genusSpecie": [
                    "Citrus bergamia"
                ],
                "wishslisted": false,
                "containsIngredients": [],
                "name": "Bergamot",
                "eoType": "Single",
                "supplierNames": [
                    "escents",
                    "Young Living",
                    "doTERRA",
                    "Melaleuca"
                ],
                "supplierCollection": {
                    "escents": [
                        {
                            "price": "₹100",
                            "size": "10 mL",
                            "skuNumber": "E3",
                            "id": "11",
                            "labels": "sku",
                            "discount": null
                        },
                        {
                            "price": "₹100",
                            "size": "100 mL",
                            "skuNumber": "E2",
                            "id": "10",
                            "labels": "sku",
                            "discount": null
                        },
                        {
                            "price": "₹100",
                            "size": "15 mL",
                            "skuNumber": "E4",
                            "id": "12",
                            "labels": "sku",
                            "discount": null
                        }
                    ],
                    "Young Living": [
                        {
                            "price": "₹100",
                            "size": "15 mL",
                            "skuNumber": "3503",
                            "id": "9",
                            "labels": "sku",
                            "discount": null
                        }
                    ],
                    "doTERRA": [
                        {
                            "price": "₹100",
                            "size": "15 mL",
                            "skuNumber": "30790001",
                            "id": "7",
                            "labels": "sku",
                            "discount": null
                        }
                    ],
                    "Melaleuca": [
                        {
                            "price": "₹100",
                            "size": "15 mL",
                            "skuNumber": "9333",
                            "id": "8",
                            "labels": "sku",
                            "discount": null
                        }
                    ]
                }
            });
            await expectAsync(eoController.getEo(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                "img": "SEO8",
                "references": [
                    "Safety Oil (Tisserand, 2019)"
                ],
                "primaryUses": [
                    "Insomnia"
                ],
                "productId": null,
                "storage": [
                    "Cool",
                    "dark place"
                ],
                "safetyInformation": [
                    "Oxidized Oil",
                    "Phototoxic",
                    "Children/Pets",
                    "Avoid Eyes",
                    "Medication Patch Use"
                ],
                "howToUse": [
                    "Massage",
                    "Apply topically ",
                    "Diffuse"
                ],
                "blendsWellWith": [
                    "Citrus oils",
                    "frankincense",
                    "geranium",
                    "jasmine",
                    "lavender",
                    "sandalwood",
                    "ylang-ylang"
                ],
                "effects": [],
                "basicInformation": {
                    "preparationMethod": [
                        "Cold Pressed/Expressed"
                    ],
                    "origin": [
                        "Peel"
                    ]
                },
                "genusSpecie": [
                    "Citrus bergamia"
                ],
                "wishslisted": false,
                "containsIngredients": [],
                "name": "Bergamot",
                "eoType": "Single",
                "supplierNames": [
                    "escents",
                    "Young Living",
                    "doTERRA",
                    "Melaleuca"
                ],
                "supplierCollection": {
                    "escents": [
                        {
                            "price": "₹100",
                            "size": "10 mL",
                            "skuNumber": "E3",
                            "id": "11",
                            "labels": "sku",
                            "discount": null
                        },
                        {
                            "price": "₹100",
                            "size": "100 mL",
                            "skuNumber": "E2",
                            "id": "10",
                            "labels": "sku",
                            "discount": null
                        },
                        {
                            "price": "₹100",
                            "size": "15 mL",
                            "skuNumber": "E4",
                            "id": "12",
                            "labels": "sku",
                            "discount": null
                        }
                    ],
                    "Young Living": [
                        {
                            "price": "₹100",
                            "size": "15 mL",
                            "skuNumber": "3503",
                            "id": "9",
                            "labels": "sku",
                            "discount": null
                        }
                    ],
                    "doTERRA": [
                        {
                            "price": "₹100",
                            "size": "15 mL",
                            "skuNumber": "30790001",
                            "id": "7",
                            "labels": "sku",
                            "discount": null
                        }
                    ],
                    "Melaleuca": [
                        {
                            "price": "₹100",
                            "size": "15 mL",
                            "skuNumber": "9333",
                            "id": "8",
                            "labels": "sku",
                            "discount": null
                        }
                    ]
                }
            });
        });

        it("When essential oil doesn't exist with given id", async() => {
            const errorMessage = "Product not found";
            spyOn(eoController["eoService"], "getEo").and.rejectWith(Promise.reject(errorMessage));
            await expectAsync(eoController.getEo(mockServer, mockRequest, mockReply)).toBeRejectedWith(errorMessage);
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get Eo List", () => {
        beforeAll(() => {
            mockRequest["query"] = { eoFilter:"{}", filter:"{}", limit:10, offset:0, search:"", sortByAlphaBoolean:"false", uid:"jyHpMqYWQqPj3c49DOF66Csbv2M2" };
        });

        it("Get eo list without any filter or sorting", async () => {
            spyOn(eoController["eoService"], "getEoList").and.resolveTo([
                {
                    "userHealth": "",
                    "genusSpecie": "Citrus bergamia",
                    "imageId": "SEO8",
                    "recommeneduse": "6",
                    "name": "Bergamot",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "0bbec948-b5c6-4822-bda0-5687fa09e0b0",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Picea mariana",
                    "imageId": "SEO11",
                    "recommeneduse": "2;5",
                    "name": "Black Spruce;Spruce;Northern Lights Spruce",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "1de4931c-1545-4f06-b7a6-b93f8c5f2795",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Matricaria recutita",
                    "imageId": "SEO46",
                    "recommeneduse": "5",
                    "name": "Chamomile German;Chamomile Blue",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "e97dec48-b377-476c-96a5-ec64ebc37bf1",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Anthemis nobilis",
                    "imageId": "SEO87",
                    "recommeneduse": "1;3;5",
                    "name": "Chamomile Roman",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "776a8e9c-59e2-43f0-905f-aed2d763e3d7",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Chamaemelum nobile",
                    "imageId": "SEO87",
                    "recommeneduse": "1;3;5",
                    "name": "Chamomile Roman",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "776a8e9c-59e2-43f0-905f-aed2d763e3d7",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cinnamomum verum",
                    "imageId": "SEO23",
                    "recommeneduse": "4",
                    "name": "Cinnamon Bark",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "3fa34f75-d5ed-4b8a-9884-881532970b81",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cinnamomum zeylanicum",
                    "imageId": "SEO24",
                    "recommeneduse": "4",
                    "name": "Cinnamon Bark",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "72ef48c7-a72c-4ff0-8d54-54e3ebab9b24",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Eugenia caryophyllata",
                    "imageId": "SEO29",
                    "recommeneduse": "7",
                    "name": "Clove",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "6df2bb4a-c86f-49e0-8ff1-48cf0bd3b4f1",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cocos nucifera L",
                    "imageId": "NA",
                    "recommeneduse": "NA",
                    "name": "Coconut Oil",
                    "eoType": "Carrier Oil",
                    "caution": false,
                    "objectId": "0ec27065-c1ad-41b4-a2c6-70adfb07c4f2",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Copaifera officinalis",
                    "imageId": "SEO30",
                    "recommeneduse": "1;5;7",
                    "name": "Copaiba",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "6c77f535-8fc5-41fc-91dd-c98140bcda2f",
                    "status": "active"
                }
            ]);
            await expectAsync(eoController.getEoList(mockServer, mockRequest, mockReply)).toBeResolvedTo([
                {
                    "userHealth": "",
                    "genusSpecie": "Citrus bergamia",
                    "imageId": "SEO8",
                    "recommeneduse": "6",
                    "name": "Bergamot",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "0bbec948-b5c6-4822-bda0-5687fa09e0b0",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Picea mariana",
                    "imageId": "SEO11",
                    "recommeneduse": "2;5",
                    "name": "Black Spruce;Spruce;Northern Lights Spruce",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "1de4931c-1545-4f06-b7a6-b93f8c5f2795",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Matricaria recutita",
                    "imageId": "SEO46",
                    "recommeneduse": "5",
                    "name": "Chamomile German;Chamomile Blue",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "e97dec48-b377-476c-96a5-ec64ebc37bf1",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Anthemis nobilis",
                    "imageId": "SEO87",
                    "recommeneduse": "1;3;5",
                    "name": "Chamomile Roman",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "776a8e9c-59e2-43f0-905f-aed2d763e3d7",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Chamaemelum nobile",
                    "imageId": "SEO87",
                    "recommeneduse": "1;3;5",
                    "name": "Chamomile Roman",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "776a8e9c-59e2-43f0-905f-aed2d763e3d7",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cinnamomum verum",
                    "imageId": "SEO23",
                    "recommeneduse": "4",
                    "name": "Cinnamon Bark",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "3fa34f75-d5ed-4b8a-9884-881532970b81",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cinnamomum zeylanicum",
                    "imageId": "SEO24",
                    "recommeneduse": "4",
                    "name": "Cinnamon Bark",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "72ef48c7-a72c-4ff0-8d54-54e3ebab9b24",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Eugenia caryophyllata",
                    "imageId": "SEO29",
                    "recommeneduse": "7",
                    "name": "Clove",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "6df2bb4a-c86f-49e0-8ff1-48cf0bd3b4f1",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cocos nucifera L",
                    "imageId": "NA",
                    "recommeneduse": "NA",
                    "name": "Coconut Oil",
                    "eoType": "Carrier Oil",
                    "caution": false,
                    "objectId": "0ec27065-c1ad-41b4-a2c6-70adfb07c4f2",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Copaifera officinalis",
                    "imageId": "SEO30",
                    "recommeneduse": "1;5;7",
                    "name": "Copaiba",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "6c77f535-8fc5-41fc-91dd-c98140bcda2f",
                    "status": "active"
                }
            ]);
        });

        it("Get error while fetching eo-list", async () => {
            spyOn(eoController["eoService"], "getEoList").and.rejectWith(Promise.reject("Product not found"));
            await expectAsync(eoController.getEoList(mockServer, mockRequest, mockReply)).toBeRejectedWith("Product not found");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add eo", () => {
        beforeAll(() => {
            mockRequest["body"] = { eoInfo:'{"name":"Mikel","eoType":"Single","genusOrSpecie":"264","healthConditions":"3;2","safetyInformations":"100","storage":"1","preparation":"1","reference":"V1","origin":"8;14","howToUse":"1;9","image":"","skuNo":"","recommeneduse":"5","createdBy":"MX1uJN2jZhTvugZa9Iv4BYLDMa53"}',
                                    label:"EO" };
            // mockRequest["file"] = new File();
        });
        it("Added EO details", async () => {
            spyOn(eoController["eoService"], "addEo").and.resolveTo({
                eo:{
                    created_at:"2020-08-04T13:52:54.631Z",
                    created_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    eo_type:"Single",
                    genus_or_specie:"264",
                    health_conditions:"3;2",
                    how_to_use:"1;9",
                    image:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg",
                    name:"Mikel",
                    object_id:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6",
                    origin:"8;14",
                    preparation:"1",
                    recommeneduse:"5"
                },
                realtionsCreated:12
            });
            await expectAsync(eoController.addEo(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                eo:{
                    created_at:"2020-08-04T13:52:54.631Z",
                    created_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    eo_type:"Single",
                    genus_or_specie:"264",
                    health_conditions:"3;2",
                    how_to_use:"1;9",
                    image:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg",
                    name:"Mikel",
                    object_id:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6",
                    origin:"8;14",
                    preparation:"1",
                    recommeneduse:"5"
                },
                realtionsCreated:12
            });
        });
        it("Get error while adding EO", async () => {
            spyOn(eoController["eoService"], "addEo").and.rejectWith(Promise.reject("Unable to add EO"));
            await expectAsync(eoController.addEo(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to add EO");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update EO", () => {
        beforeAll(() => {
            mockRequest["body"] = { eoInfo:'{"name":"Mikel","eoType":"Single","genusOrSpecie":"264","healthConditions":"3;4","safetyInformations":"100","storage":"1","preparation":"1","reference":"V1","origin":"8;14","howToUse":"1;3","image":"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg","skuNo":"","recommeneduse":"5","modifiedBy":"MX1uJN2jZhTvugZa9Iv4BYLDMa53","objectId":"44dfaf90-a5d0-4f89-96e4-f9796821d2a6"}',
                                    label:"EO" };
        });
        it("Update EO(44dfaf90-a5d0-4f89-96e4-f9796821d2a6)", async () => {
                spyOn(eoController["eoService"], "updateEo").and.resolveTo({
                    eoType:"Single",
                    genusOrSpecie:"264",
                    healthConditions:"3;4",
                    howToUse:"1;3",
                    image:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg",
                    modifiedAt:"2020-08-04T14:55:48.526Z",
                    modifiedBy:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    name:"Mikel",
                    objectId:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6",
                    origin:"8;14",
                    preparation:"1",
                    recommeneduse:"5",
                    reference:"V1",
                    safetyInformations:"100",
                    skuNo:"",
                    storage:"1",
                });
                await expectAsync(eoController.updateEo(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                    eoType:"Single",
                    genusOrSpecie:"264",
                    healthConditions:"3;4",
                    howToUse:"1;3",
                    image:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg",
                    modifiedAt:"2020-08-04T14:55:48.526Z",
                    modifiedBy:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    name:"Mikel",
                    objectId:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6",
                    origin:"8;14",
                    preparation:"1",
                    recommeneduse:"5",
                    reference:"V1",
                    safetyInformations:"100",
                    skuNo:"",
                    storage:"1",
                });
        });

        it("Get error while updating EO", async () => {
            spyOn(eoController["eoService"], "updateEo").and.rejectWith(Promise.reject("Unable to add EO"));
            await expectAsync(eoController.updateEo(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to add EO");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
});