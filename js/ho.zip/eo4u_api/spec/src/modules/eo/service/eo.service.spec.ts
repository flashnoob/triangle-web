import { EoService } from "../../../../../src/modules/eo/service/eo.service";
import { MockServer } from "../../../../helpers/common_mock.helper";


describe("EO Service unit test:", () => {
    let eoService: EoService;
    let mockRequest: any;
    let mockServer: MockServer;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}, headers:{authorization:""}};
        eoService = new EoService();
        spyOn(eoService["redis"], "get").and.resolveTo({uid, role: "MEMBER"});
    });

    describe("Get Essential Oil", () => {
        beforeAll(() => {
            mockRequest["query"] = { currencyCode:"INR", id:"0bbec948-b5c6-4822-bda0-5687fa09e0b0" };
        });
        // it("When essential oil exist with given id and without shopify skus", async () => {
        //     spyOn(eoService["eoDbService"], "getEo").and.resolveTo({
        //         eo:{
        //             basicInformation:{
        //                 origin: ["Peel"],
        //                 preparationMethod: ["Cold Pressed/Expressed"]
        //             },
        //             blendsWellWith: ["Citrus oils;frankincense;geranium;jasmine;lavender;sandalwood;and ylang-ylang"],
        //             containsIngredients: [],
        //             effects: [],
        //             eoType:"Single",
        //             genusSpecie:["Citrus bergamia"],
        //             howToUse:  ["Massage", "Apply topically ", "Diffuse"],
        //             img:"SEO8",
        //             name:"Bergamot",
        //             primaryUses: ["Insomnia"],
        //             productId:null,
        //             references: ["Safety Oil (Tisserand, 2019)"],
        //             safetyInformation: ["Oxidized Oil", "Phototoxic", "Children/Pets", "Avoid Eyes", "Medication Patch Use"],
        //             skus: [{
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"11",
        //                 skuNumber:"E3",
        //                 skuPrice:"₹100",
        //                 skuSize:"10 mL",
        //                 supplierName:"escents"
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"10",
        //                 skuNumber:"E2",
        //                 skuPrice:"₹100",
        //                 skuSize:"100 mL",
        //                 supplierName:"escents",
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"9",
        //                 skuNumber:"3503",
        //                 skuPrice:"₹100",
        //                 skuSize:"15 mL",
        //                 supplierName:"Young Living"
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"7",
        //                 skuNumber:"30790001",
        //                 skuPrice:"₹100",
        //                 skuSize:"15 mL",
        //                 supplierName:"doTERRA"
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"8",
        //                 skuNumber:"9333",
        //                 skuPrice:"₹100",
        //                 skuSize:"15 mL",
        //                 supplierName:"Melaleuca"
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"12",
        //                 skuNumber:"E4",
        //                 skuPrice:"₹100",
        //                 skuSize:"15 mL",
        //                 supplierName:"escents"
        //             }],
        //             storage: ["Cool, dark place"],
        //             wishslisted:false
        //         },
        //         shopifySkus:[],
        //         suppliers:[{objectId:"90798119-eb55-43eb-8132-1a61cf6c1c31", supplier:"Young Living"}]
        //     });
        //     await expectAsync(eoService.getEo(mockServer, mockRequest)).toBeResolvedTo({
        //         basicInformation:{
        //             origin: ["Peel"],
        //             preparationMethod: ["Cold Pressed/Expressed"]
        //         },
        //         blendsWellWith: ["Citrus oils", "frankincense", "geranium", "jasmine", "lavender", "sandalwood", "ylang-ylang"],
        //         containsIngredients: [],
        //         effects: [],
        //         eoType:"Single",
        //         genusSpecie:["Citrus bergamia"],
        //         howToUse:  ["Massage", "Apply topically ", "Diffuse"],
        //         img:"SEO8",
        //         name:"Bergamot",
        //         primaryUses: ["Insomnia"],
        //         productId:null,
        //         references: ["Safety Oil (Tisserand, 2019)"],
        //         safetyInformation: ["Oxidized Oil", "Phototoxic", "Children/Pets", "Avoid Eyes", "Medication Patch Use"],
        //         storage: ["Cool", "dark place"],
        //         supplierCollection:{
        //             doTERRA: [
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"7",
        //                 skuNumber:"30790001",
        //                 price:"₹100",
        //                 size:"15 mL",
        //                 }
        //             ],
        //             escents: [
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"11",
        //                 skuNumber:"E3",
        //                 price:"₹100",
        //                 size:"10 mL",
        //                 },
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"10",
        //                 skuNumber:"E2",
        //                 price:"₹100",
        //                 size:"100 mL",
        //                 },
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"12",
        //                 skuNumber:"E4",
        //                 price:"₹100",
        //                 size:"15 mL",
        //                 }
        //             ],
        //             Melaleuca: [
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"8",
        //                 skuNumber:"9333",
        //                 price:"₹100",
        //                 size:"15 mL",
        //                 }
        //             ],
        //             "Young Living": [
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"9",
        //                 skuNumber:"3503",
        //                 price:"₹100",
        //                 size:"15 mL",
        //                 }
        //             ]
        //         },
        //         supplierNames: ["escents", "Young Living", "doTERRA", "Melaleuca"],
        //         wishslisted:false
        //     });
        // });

        // it("When essential oil doesn't have skus or skus withtout necessary details", async () => {
        //     mockRequest["query"] = { currencyCode:"INR", id:"1de4931c-1545-4f06-b7a6-b93f8c5f2795" };
        //     spyOn(eoService["eoDbService"], "getEo").and.resolveTo({
        //         eo:{
        //             basicInformation:{
        //                 origin: ["Twig", "Needles"],
        //                 preparationMethod: ["Steam Distillation"]
        //             },
        //             blendsWellWith: [],
        //             containsIngredients: [],
        //             effects: [],
        //             eoType:"Single",
        //             genusSpecie:["Picea mariana"],
        //             howToUse:   ["Diffuse", "Apply topically ", "Dilute in a carrier oil"],
        //             img:"SEO11",
        //             name: "Black Spruce;Spruce;Northern Lights Spruce",
        //             primaryUses: ["Cleaning", "Inflammation"],
        //             productId:null,
        //             references: ["Safety Oil (Tisserand, 2019)"],
        //             safetyInformation: ["Children/Pets", "Medication Patch Use", "Oxidized Oil", "Avoid Eyes"],
        //             skus: [],
        //             storage: ["Cool, dark place"],
        //             wishslisted:false
        //         },
        //         shopifySkus:[],
        //         suppliers:[]
        //     });
        //     await expectAsync(eoService.getEo(mockServer, mockRequest)).toBeResolvedTo({
        //         basicInformation:{
        //             origin: ["Twig", "Needles"],
        //             preparationMethod: ["Steam Distillation"]
        //         },
        //         blendsWellWith: [],
        //         containsIngredients: [],
        //         effects: [],
        //         eoType:"Single",
        //         genusSpecie:["Picea mariana"],
        //         howToUse:   ["Diffuse", "Apply topically ", "Dilute in a carrier oil"],
        //         img:"SEO11",
        //         name: "Black Spruce;Spruce;Northern Lights Spruce",
        //         primaryUses: ["Cleaning", "Inflammation"],
        //         productId:null,
        //         references: ["Safety Oil (Tisserand, 2019)"],
        //         safetyInformation: ["Children/Pets", "Medication Patch Use", "Oxidized Oil", "Avoid Eyes"],
        //         supplierCollection: {},
        //         supplierNames: [],
        //         storage: ["Cool", "dark place"],
        //         wishslisted:false
        //     });
        // });

        // it("When essential oil haves shopify skus", async () => {
        //     spyOn(eoService["eoDbService"], "getEo").and.resolveTo({
        //         eo:{
        //             basicInformation:{
        //                 origin: ["Peel"],
        //                 preparationMethod: ["Cold Pressed/Expressed"]
        //             },
        //             blendsWellWith: ["Citrus oils;frankincense;geranium;jasmine;lavender;sandalwood;and ylang-ylang"],
        //             containsIngredients: [],
        //             effects: [],
        //             eoType:"Single",
        //             genusSpecie:["Citrus bergamia"],
        //             howToUse:  ["Massage", "Apply topically ", "Diffuse"],
        //             img:"SEO8",
        //             name:"Bergamot",
        //             primaryUses: ["Insomnia"],
        //             productId:"5323419091101",
        //             references: ["Safety Oil (Tisserand, 2019)"],
        //             safetyInformation: ["Oxidized Oil", "Phototoxic", "Children/Pets", "Avoid Eyes", "Medication Patch Use"],
        //             skus: [{
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"11",
        //                 skuNumber:"E3",
        //                 skuPrice:"₹100",
        //                 skuSize:"10 mL",
        //                 supplierName:"escents"
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"10",
        //                 skuNumber:"E2",
        //                 skuPrice:"₹100",
        //                 skuSize:"100 mL",
        //                 supplierName:"escents",
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"9",
        //                 skuNumber:"3503",
        //                 skuPrice:"₹100",
        //                 skuSize:"15 mL",
        //                 supplierName:"Young Living"
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"7",
        //                 skuNumber:"30790001",
        //                 skuPrice:"₹100",
        //                 skuSize:"15 mL",
        //                 supplierName:"doTERRA"
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"8",
        //                 skuNumber:"9333",
        //                 skuPrice:"₹100",
        //                 skuSize:"15 mL",
        //                 supplierName:"Melaleuca"
        //                 }, {
        //                 labels:"sku",
        //                 percentDiscount:null,
        //                 skuId:"12",
        //                 skuNumber:"E4",
        //                 skuPrice:"₹100",
        //                 skuSize:"15 mL",
        //                 supplierName:"escents"
        //             }],
        //             storage: ["Cool, dark place"],
        //             wishslisted:false
        //         },
        //         shopifySkus:["34882694054045"],
        //         suppliers:[{objectId:"90798119-eb55-43eb-8132-1a61cf6c1c31", supplier:"Young Living"}]
        //     });
        //     spyOn(eoService["httpHelper"], "requestConnector").and.resolveTo('[{"skuNumber":"568987","skuPrice":"US$400.00","skuSize":"15 mL","supplierName":"Young Living","skuId":"34882694054045","labels":"shopify:sku","percentDiscount":null}]');
        //     await expectAsync(eoService.getEo(mockServer, mockRequest)).toBeResolvedTo({
        //         basicInformation:{
        //             origin: ["Peel"],
        //             preparationMethod: ["Cold Pressed/Expressed"]
        //         },
        //         blendsWellWith: ["Citrus oils", "frankincense", "geranium", "jasmine", "lavender", "sandalwood", "ylang-ylang"],
        //         containsIngredients: [],
        //         effects: [],
        //         eoType:"Single",
        //         genusSpecie:["Citrus bergamia"],
        //         howToUse:  ["Massage", "Apply topically ", "Diffuse"],
        //         img:"SEO8",
        //         name:"Bergamot",
        //         primaryUses: ["Insomnia"],
        //         productId: "5323419091101",
        //         references: ["Safety Oil (Tisserand, 2019)"],
        //         safetyInformation: ["Oxidized Oil", "Phototoxic", "Children/Pets", "Avoid Eyes", "Medication Patch Use"],
        //         storage: ["Cool", "dark place"],
        //         supplierCollection:{
        //             doTERRA: [
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"7",
        //                 skuNumber:"30790001",
        //                 price:"₹100",
        //                 size:"15 mL",
        //                 }
        //             ],
        //             escents: [
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"11",
        //                 skuNumber:"E3",
        //                 price:"₹100",
        //                 size:"10 mL",
        //                 },
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"10",
        //                 skuNumber:"E2",
        //                 price:"₹100",
        //                 size:"100 mL",
        //                 },
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"12",
        //                 skuNumber:"E4",
        //                 price:"₹100",
        //                 size:"15 mL",
        //                 }
        //             ],
        //             Melaleuca: [
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"8",
        //                 skuNumber:"9333",
        //                 price:"₹100",
        //                 size:"15 mL",
        //                 }
        //             ],
        //             "Young Living": [
        //                 {
        //                 labels:"sku",
        //                 discount:null,
        //                 id:"9",
        //                 skuNumber:"3503",
        //                 price:"₹100",
        //                 size:"15 mL",
        //                 }, {
        //                 discount:null,
        //                 id:"34882694054045",
        //                 labels:"shopify:sku",
        //                 price:"US$400.00",
        //                 size:"15 mL",
        //                 skuNumber:"568987"
        //                 }
        //             ]
        //         },
        //         supplierNames: ["escents", "Young Living", "doTERRA", "Melaleuca"],
        //         wishslisted:false
        //     });
        // });

        it("When essential oil doesn't exist for given object-id", async () => {
            mockRequest["query"] = { currencyCode:"INR", id:"fake-object-id" };
            spyOn(eoService["eoDbService"], "getEo").and.rejectWith("Product not found");
            await expectAsync(eoService.getEo(mockServer, mockRequest)).toBeRejectedWith("Product not found");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get Eo List", () => {
        const eoFilter = "{}";
        const filter = "{}";
        const limit = 10;
        const offset = 0;
        const search = "";
        const sortByAlphaBoolean = false;
        const supplierName = "Nascents";

        it("Get eo list without any filter or sorting in Mobile App", async () => {
            spyOn(eoService["eoDbService"], "getEoList").and.resolveTo({
                eoList:[
                {
                    "userHealth": [],
                    "genusSpecie": "Citrus bergamia",
                    "imageId": "SEO8",
                    "recommeneduse": "6",
                    "name": "Bergamot",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "0bbec948-b5c6-4822-bda0-5687fa09e0b0",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Picea mariana",
                    "imageId": "SEO11",
                    "recommeneduse": "2;5",
                    "name": "Black Spruce;Spruce;Northern Lights Spruce",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "1de4931c-1545-4f06-b7a6-b93f8c5f2795",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Matricaria recutita",
                    "imageId": "SEO46",
                    "recommeneduse": "5",
                    "name": "Chamomile German;Chamomile Blue",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "e97dec48-b377-476c-96a5-ec64ebc37bf1",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Anthemis nobilis",
                    "imageId": "SEO87",
                    "recommeneduse": "1;3;5",
                    "name": "Chamomile Roman",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "776a8e9c-59e2-43f0-905f-aed2d763e3d7",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Chamaemelum nobile",
                    "imageId": "SEO87",
                    "recommeneduse": "1;3;5",
                    "name": "Chamomile Roman",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "776a8e9c-59e2-43f0-905f-aed2d763e3d7",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Cinnamomum verum",
                    "imageId": "SEO23",
                    "recommeneduse": "4",
                    "name": "Cinnamon Bark",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "3fa34f75-d5ed-4b8a-9884-881532970b81",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Cinnamomum zeylanicum",
                    "imageId": "SEO24",
                    "recommeneduse": "4",
                    "name": "Cinnamon Bark",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "72ef48c7-a72c-4ff0-8d54-54e3ebab9b24",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Eugenia caryophyllata",
                    "imageId": "SEO29",
                    "recommeneduse": "7",
                    "name": "Clove",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "6df2bb4a-c86f-49e0-8ff1-48cf0bd3b4f1",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Cocos nucifera L",
                    "imageId": "NA",
                    "recommeneduse": "NA",
                    "name": "Coconut Oil",
                    "eoType": "Carrier Oil",
                    "caution": false,
                    "objectId": "0ec27065-c1ad-41b4-a2c6-70adfb07c4f2",
                    "status": "active"
                },
                {
                    "userHealth": [],
                    "genusSpecie": "Copaifera officinalis",
                    "imageId": "SEO30",
                    "recommeneduse": "1;5;7",
                    "name": "Copaiba",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "6c77f535-8fc5-41fc-91dd-c98140bcda2f",
                    "status": "active"
                }
                ],
                eoCount:40
            });
            await expectAsync(eoService.getEoList(offset, limit, uid, search, filter, eoFilter, sortByAlphaBoolean, supplierName, mockServer)).toBeResolvedTo([
                {
                    "userHealth": "",
                    "genusSpecie": "Citrus bergamia",
                    "imageId": "SEO8",
                    "recommeneduse": "6",
                    "name": "Bergamot",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "0bbec948-b5c6-4822-bda0-5687fa09e0b0",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Picea mariana",
                    "imageId": "SEO11",
                    "recommeneduse": "2;5",
                    "name": "Black Spruce;Spruce;Northern Lights Spruce",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "1de4931c-1545-4f06-b7a6-b93f8c5f2795",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Matricaria recutita",
                    "imageId": "SEO46",
                    "recommeneduse": "5",
                    "name": "Chamomile German;Chamomile Blue",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "e97dec48-b377-476c-96a5-ec64ebc37bf1",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Anthemis nobilis",
                    "imageId": "SEO87",
                    "recommeneduse": "1;3;5",
                    "name": "Chamomile Roman",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "776a8e9c-59e2-43f0-905f-aed2d763e3d7",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Chamaemelum nobile",
                    "imageId": "SEO87",
                    "recommeneduse": "1;3;5",
                    "name": "Chamomile Roman",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "776a8e9c-59e2-43f0-905f-aed2d763e3d7",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cinnamomum verum",
                    "imageId": "SEO23",
                    "recommeneduse": "4",
                    "name": "Cinnamon Bark",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "3fa34f75-d5ed-4b8a-9884-881532970b81",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cinnamomum zeylanicum",
                    "imageId": "SEO24",
                    "recommeneduse": "4",
                    "name": "Cinnamon Bark",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "72ef48c7-a72c-4ff0-8d54-54e3ebab9b24",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Eugenia caryophyllata",
                    "imageId": "SEO29",
                    "recommeneduse": "7",
                    "name": "Clove",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "6df2bb4a-c86f-49e0-8ff1-48cf0bd3b4f1",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Cocos nucifera L",
                    "imageId": "NA",
                    "recommeneduse": "NA",
                    "name": "Coconut Oil",
                    "eoType": "Carrier Oil",
                    "caution": false,
                    "objectId": "0ec27065-c1ad-41b4-a2c6-70adfb07c4f2",
                    "status": "active"
                },
                {
                    "userHealth": "",
                    "genusSpecie": "Copaifera officinalis",
                    "imageId": "SEO30",
                    "recommeneduse": "1;5;7",
                    "name": "Copaiba",
                    "eoType": "Single",
                    "caution": false,
                    "objectId": "6c77f535-8fc5-41fc-91dd-c98140bcda2f",
                    "status": "active"
                }
            ]);
        });

        it("Get error while fetching eo-list", async () => {
            spyOn(eoService["eoDbService"], "getEoList").and.rejectWith("Product(s) not found");
            await expectAsync(eoService.getEoList(offset, limit, uid, search, filter, eoFilter, sortByAlphaBoolean, supplierName, mockServer)).toBeRejectedWith("Product(s) not found");
        });
    });

    describe("Add Eo", () => {
        beforeAll(() => {
            mockRequest["body"] = { eoInfo:'{"name":"Mikel","eoType":"Single","genusOrSpecie":"264","healthConditions":"3;2","safetyInformations":"100","storage":"1","preparation":"1","reference":"V1","origin":"8;14","howToUse":"1;9","image":"","skuNo":"","recommeneduse":"5","createdBy":"MX1uJN2jZhTvugZa9Iv4BYLDMa53"}',
                                    label:"EO" };
        });
        it("Adding eo details", async () => {
            spyOn(eoService["eoDbService"], "addEo").and.resolveTo({
                eo:{
                    created_at:"2020-08-04T13:52:54.631Z",
                    created_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    eo_type:"Single",
                    genus_or_specie:"264",
                    health_conditions:"3;2",
                    how_to_use:"1;9",
                    image:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg",
                    name:"Mikel",
                    object_id:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6",
                    origin:"8;14",
                    preparation:"1",
                    recommeneduse:"5"
                },
                realtionsCreated:12
            });
            spyOn(eoService, "uploadImageToBlob").and.resolveTo("");
            await expectAsync(eoService.addEo(mockServer, mockRequest)).toBeResolvedTo({
                eo:{
                    created_at:"2020-08-04T13:52:54.631Z",
                    created_by:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                    eo_type:"Single",
                    genus_or_specie:"264",
                    health_conditions:"3;2",
                    how_to_use:"1;9",
                    image:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg",
                    name:"Mikel",
                    object_id:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6",
                    origin:"8;14",
                    preparation:"1",
                    recommeneduse:"5"
                },
                realtionsCreated:12
            });
        });
        it("Get error while adding EO", async () => {
            spyOn(eoService["eoDbService"], "addEo").and.rejectWith("Unable to add EO");
            await expectAsync(eoService.addEo(mockServer, mockRequest)).toBeRejectedWith("Unable to add EO");
        });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update Eo", () => {
        beforeAll(() => {
            mockRequest["body"] = { eoInfo:'{"name":"Mikel","eoType":"Single","genusOrSpecie":"264","healthConditions":"3;4","safetyInformations":"100","storage":"1","preparation":"1","reference":"V1","origin":"8;14","howToUse":"1;3","image":"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg","skuNo":"","recommeneduse":"5","modifiedBy":"MX1uJN2jZhTvugZa9Iv4BYLDMa53","objectId":"44dfaf90-a5d0-4f89-96e4-f9796821d2a6"}',
                                    label:"EO" };
        });

        it("Update EO(44dfaf90-a5d0-4f89-96e4-f9796821d2a6)", async () => {
            spyOn(eoService["eoDbService"], "updateEo").and.resolveTo({
                eoType:"Single",
                genusOrSpecie:"264",
                healthConditions:"3;4",
                howToUse:"1;3",
                image:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg",
                modifiedAt:"2020-08-04T14:55:48.526Z",
                modifiedBy:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                name:"Mikel",
                objectId:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6",
                origin:"8;14",
                preparation:"1",
                recommeneduse:"5",
                reference:"V1",
                safetyInformations:"100",
                skuNo:"",
                storage:"1",
            });
            await expectAsync(eoService.updateEo(mockRequest, mockServer)).toBeResolvedTo({
                eoType:"Single",
                genusOrSpecie:"264",
                healthConditions:"3;4",
                howToUse:"1;3",
                image:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6.jpg",
                modifiedAt:"2020-08-04T14:55:48.526Z",
                modifiedBy:"MX1uJN2jZhTvugZa9Iv4BYLDMa53",
                name:"Mikel",
                objectId:"44dfaf90-a5d0-4f89-96e4-f9796821d2a6",
                origin:"8;14",
                preparation:"1",
                recommeneduse:"5",
                reference:"V1",
                safetyInformations:"100",
                skuNo:"",
                storage:"1",
            });
        });

        // it("Get error while updating EO", async () => {
        //     spyOn(eoService["eoDbService"], "updateEo").and.rejectWith("Unable to update EO");
        //     await expectAsync(eoService.updateEo(mockServer, mockRequest)).toBeRejectedWith("Unable to update EO");
        // });
        afterAll(() => {
            mockRequest["params"] =  {} ;
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    })
});