import { HttpHelper } from "./../../../helpers/http.helper";

describe("eo acceptance test: ", () => {
    const httpHelper: HttpHelper = new HttpHelper();
    beforeAll(() => {
    });

    afterAll(() => {
    });

    describe("/get-eo: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    id: "6b1f6f2b-9a77-4ab7-b249-65a9eaacf4ed",
                    uid: "string"
                };
                result = await httpHelper.request("GET", "/get-eo", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-eo-image/imageName: ", () => {
        let result: any = {};
        it("If image exists, status code should be 200", async (done) => {
            try {
                const content = {
                    imageName: "SEO6"
                };
                result = await httpHelper.request("GET", `/get-eo-image/${content.imageName}`, content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
            expect(result.res["statusCode"]).toEqual(200);
        });
        it("If image doesn't exist, status code should be 404", async (done) => {
            try {
                const content = {
                    imageName: "DummyName"
                };
                result = await httpHelper.request("GET", `/get-eo-image/${content.imageName}`, content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
            expect(result.res["statusCode"]).toEqual(404);
        });
    });

    describe("/add-eo: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    label: "string",
                    eo_info: {
                        created_by: "string",
                        key_constituents: "string",
                        precautions: "string",
                        blends_well_with: "string",
                        origin: "string",
                        storage: "string",
                        how_to_use: "string",
                        preparation: "string",
                        reference: "string",
                        sku_no: "string",
                        effect: "string",
                        name: "string",
                        body_systems_affected: "string",
                        common_primary_use: "string",
                        genus_or_specie: "string",
                        properties: "string",
                        eo_type: "string"
                    }
                };
                result = await httpHelper.request("POST", "/add-eo", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-all-eo: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    limit: "number",
                    offset: "number",
                    uid: "string",
                    search: "string",
                    filter: "string"
                };
                result = await httpHelper.request("GET", "/get-all-eo", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/update-eo/object_id: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    label: "string",
                    eo_info: {
                        object_id: "string",
                        key_constituents: "string",
                        precautions: "string",
                        blends_well_with: "string",
                        origin: "string",
                        storage: "string",
                        how_to_use: "string",
                        preparation: "string",
                        reference: "string",
                        sku_no: "string",
                        effect: "string",
                        name: "string",
                        body_systems_affected: "string",
                        common_primary_use: "string",
                        genus_or_specie: "string",
                        properties: "string",
                        eo_type: "string"
                    }
                };
                const object_id: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("PUT", `/update-eo/${object_id}`, content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });


});