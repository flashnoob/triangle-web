import { HttpHelper } from "../../../helpers/http.helper";

describe("User acceptance test: ", () => {

    const httpHelper: HttpHelper = new HttpHelper();
    beforeAll(() => {
    });

    afterAll(() => {
    });

    describe("/get-users/userRole: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    userRole: "string"
                };
                result = await httpHelper.request("GET", `/get-users/${content.userRole}`, content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-users-image/imageName: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    imageName: "string"
                };
                result = await httpHelper.request("GET", `/get-users-image/${content.imageName}`, content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-user/id: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const id: string = "cCQYH0vQsubIVutJ5cbR643ESKk2";
                result = await httpHelper.request("GET", `/get-user/${id}`);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/add-user: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    role: "string",
                    user_info: {
                        firstName: "string",
                        lastName: "string",
                        phoneNumber: "string",
                        birthday: "string",
                        email: "string",
                        address: [
                            {
                                street1: "string",
                                street2: "string",
                                zip: "string",
                                city: "string",
                                state: "string"
                            }
                        ],
                        healthStatus: "string",
                        isNewUser: true,
                        lastSigninTimestamp: "string",
                        uid: "string"
                    }
                };
                result = await httpHelper.request("POST", "/add-user", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/add-item: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    status: "string",
                    EoName: "string",
                    supplier: "string",
                    sku: "string",
                    uid: "string"
                };
                result = await httpHelper.request("POST", "/add-item", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/remove-item: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    status: "string",
                    EoName: "string",
                    supplier: "string",
                    sku: "string",
                    uid: "string"
                };
                result = await httpHelper.request("PUT", "/remove-item", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-health-conditions: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                result = await httpHelper.request("GET", "/get-health-conditions");
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-filters: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                result = await httpHelper.request("GET", "/get-filters");
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/get-eo-filters: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                result = await httpHelper.request("GET", "/get-eo-filters");
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

    describe("/update-address: ", () => {
        let result: any = {};
        beforeAll(async (done) => {
            try {
                const content = {
                    "userDetails": {}
                }
                result = await httpHelper.request("POST", "/update-address", content);
                done();
            } catch (err) {
                console.log(err);
                return err;
                done();
            }
        });
        it("Status code should be 200", async () => {
            expect(result.res["statusCode"]).toEqual(200);
        });
    });

});