import * as urlHttpClient from "urllib";
import { MockReply, MockServer } from "../../../../helpers/common_mock.helper";
import { UserService } from "./../../../../../src/modules/user/service/user.service";

describe("User service unit test:", () => {
    let userService: UserService;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn:any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        userService = new UserService();
        spyOn(userService["redis"], "get").and.resolveTo({uid, membership_expire:"2020-09-05T15:17:26.966Z"});
        spyOn(userService["redis"], "set").and.resolveTo(JSON.stringify({uid}));

    });

    describe("Get User info", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                id:'dINclyo0hMOzRMGJ8tPuyqIE4E62'  
            }
        });
        it("Get user Info empty", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo([])
            await expectAsync(userService.getUser(mockServer, mockRequest)).toBeRejectedWithError("User Not Found.")
        });
        it("Having a user info", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"ggdf","street2":"ffdfsd","zip":"400080"}'],
                birthday:'21-8-2018',
                countryCode:'INR',
                created_at:'2020-08-21T15:17:26.966Z',
                created_by:'dINclyo0hMOzRMGJ8tPuyqIE4E62',
                email:'user20@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Twenty',
                lastSigninTimestamp:'Fri Aug 21 2020 20:09:31 GMT+0530 (IST)',
                membership_expire:'2020-09-05T15:17:26.966Z',
                modified_at:'',
                modified_by:'',
                object_id:'25df6350-e9dc-4e7b-8324-60d6c7b72e3f',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'male',
                status:'active',
                stripeCustomerID:'',
                uid:'dINclyo0hMOzRMGJ8tPuyqIE4E62'
            })
            await expectAsync(userService.getUser(mockServer, mockRequest)).toBeResolvedTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"ggdf","street2":"ffdfsd","zip":"400080"}'],
                birthday:'21-8-2018',
                countryCode:'INR',
                created_at:'2020-08-21T15:17:26.966Z',
                created_by:'dINclyo0hMOzRMGJ8tPuyqIE4E62',
                email:'user20@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Twenty',
                lastSigninTimestamp:'Fri Aug 21 2020 20:09:31 GMT+0530 (IST)',
                membership_expire:'2020-09-05T15:17:26.966Z',
                modified_at:'',
                modified_by:'',
                object_id:'25df6350-e9dc-4e7b-8324-60d6c7b72e3f',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'male',
                status:'active',
                stripeCustomerID:'',
                uid:'dINclyo0hMOzRMGJ8tPuyqIE4E62'
            })
        });
        it("Error while getting user info", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.rejectWith("Unable to get user info")
            await expectAsync(userService.getUser(mockServer,mockRequest)).toBeRejectedWith("Unable to get user info")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    // describe("Get User profile Image", () => {
    //     beforeAll(() => {
        
    //     });
    //     afterAll(() => {
    //         mockRequest["params"] = {};
    //         mockRequest["query"] = {};
    //         mockRequest["body"] = {};
    //     });
    // });

    // describe("Get user by label", () => {
    //     beforeAll(() => {
        
    //     });
    //     afterAll(() => {
    //         mockRequest["params"] = {};
    //         mockRequest["query"] = {};
    //         mockRequest["body"] = {};
    //     });
    // });

    describe("Add User", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                label:'MEMBER_USER_NL',
                user_info: {
                    address: ['{"street1":"ggdf","street2":"ffdfsd","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400080","defaultAddress":true}'],
                    birthday:'21-8-2018',
                    created_at:'2020-08-21T14:47:58.407Z',
                    created_by:'dINclyo0hMOzRMGJ8tPuyqIE4E62',
                    email:'user20@gmail.com',
                    firstName:'User',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Twenty',
                    lastSigninTimestamp:'Fri Aug 21 2020 20:09:31 GMT+0530 (IST)',
                    membership_expire:'2020-09-05T14:47:58.407Z',
                    modified_at:'',
                    modified_by:'',
                    object_id:'6f20edd5-c3be-4873-8d1e-59877620428f',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'male',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'dINclyo0hMOzRMGJ8tPuyqIE4E62'
                },
                uid:'3rMXiyIkm8OLpy0CVRwgNnFAWd42'
            };
        });
        it("Add user info successfully", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo({
                address: ['{"street1":"ggdf","street2":"ffdfsd","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400080","defaultAddress":true}'],
                    birthday:'21-8-2018',
                    created_at:'2020-08-21T14:47:58.407Z',
                    created_by:'dINclyo0hMOzRMGJ8tPuyqIE4E62',
                    email:'user20@gmail.com',
                    firstName:'User',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Twenty',
                    lastSigninTimestamp:'Fri Aug 21 2020 20:09:31 GMT+0530 (IST)',
                    membership_expire:'2020-09-05T14:47:58.407Z',
                    modified_at:'',
                    modified_by:'',
                    object_id:'6f20edd5-c3be-4873-8d1e-59877620428f',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'male',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'dINclyo0hMOzRMGJ8tPuyqIE4E62'
            })
            await expectAsync(userService.addUser(mockRequest)).toBeResolvedTo({
                address: ['{"street1":"ggdf","street2":"ffdfsd","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400080","defaultAddress":true}'],
                    birthday:'21-8-2018',
                    created_at:'2020-08-21T14:47:58.407Z',
                    created_by:'dINclyo0hMOzRMGJ8tPuyqIE4E62',
                    email:'user20@gmail.com',
                    firstName:'User',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Twenty',
                    lastSigninTimestamp:'Fri Aug 21 2020 20:09:31 GMT+0530 (IST)',
                    membership_expire:'2020-09-05T14:47:58.407Z',
                    modified_at:'',
                    modified_by:'',
                    object_id:'6f20edd5-c3be-4873-8d1e-59877620428f',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'male',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'dINclyo0hMOzRMGJ8tPuyqIE4E62'
            })
        });
        it("Error while adding user", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.rejectWith("Unable to add user")
            await expectAsync(userService.addUser(mockRequest)).toBeRejectedWith("Unable to add user")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update User", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                label:'MEMBER_USER_NL',
                user_info:'{"uid":"G72JtXPRCuOjYAEwS7X8TazOac33","email":"savi20@gmail.com","phoneNumber":"9898989898","lastSigninTimestamp":"Mon Aug 17 2020 17:45:01 GMT+0530 (IST)","isNewUser":true,"firstName":"Abc","healthStatus":"28","lastName":"Xyz","birthday":"18-8-1990","sex":"female","address":[{"street1":"Dfg","street2":"Dffg","city":"Mumbai ","state":"Maharashtra ","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}],"img_name":"userName.png"}'
            };
            mockRequest["params"] = {
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Update empty user Info", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo([])
            await expectAsync(userService.updateUser(mockServer, mockRequest)).toBeRejectedWithError("User Not Found.")
        });
        it("Update user details", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo({
                address:['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Dfg","street2":"Dffg","zip":"400067"}'],
                birthday:'18-8-1990',
                created_at:'2020-08-17T12:16:28.903Z',
                created_by:'G72JtXPRCuOjYAEwS7X8TazOac33',
                email:'savi20@gmail.com',
                firstName:'Abc',
                healthStatus:'Sensitive Skin',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Xyz',
                lastSigninTimestamp:'Mon Aug 17 2020 17:45:01 GMT+0530 (IST)',
                membership_expire:'2020-09-01T12:16:28.904Z',
                modified_at:'2020-08-18T12:02:16.552Z',
                modified_by:'By User',
                object_id:'5e3d07e3-82fa-4938-850d-707ca60b771b',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
            await expectAsync(userService.updateUser(mockServer,mockRequest)).toBeResolvedTo({
                address:['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Dfg","street2":"Dffg","zip":"400067"}'],
                birthday:'18-8-1990',
                created_at:'2020-08-17T12:16:28.903Z',
                created_by:'G72JtXPRCuOjYAEwS7X8TazOac33',
                email:'savi20@gmail.com',
                firstName:'Abc',
                healthStatus:'Sensitive Skin',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Xyz',
                lastSigninTimestamp:'Mon Aug 17 2020 17:45:01 GMT+0530 (IST)',
                membership_expire:'2020-09-01T12:16:28.904Z',
                modified_at:'2020-08-18T12:02:16.552Z',
                modified_by:'By User',
                object_id:'5e3d07e3-82fa-4938-850d-707ca60b771b',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
        });
        it("Update user details with image", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo({
                address:['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Dfg","street2":"Dffg","zip":"400067"}'],
                birthday:'18-8-1990',
                created_at:'2020-08-17T12:16:28.903Z',
                created_by:'G72JtXPRCuOjYAEwS7X8TazOac33',
                email:'savi20@gmail.com',
                firstName:'Abc',
                healthStatus:'Sensitive Skin',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Xyz',
                lastSigninTimestamp:'Mon Aug 17 2020 17:45:01 GMT+0530 (IST)',
                membership_expire:'2020-09-01T12:16:28.904Z',
                modified_at:'2020-08-18T12:02:16.552Z',
                modified_by:'By User',
                object_id:'5e3d07e3-82fa-4938-850d-707ca60b771b',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
            await expectAsync(userService.updateUser(mockServer,mockRequest)).toBeResolvedTo({
                address:['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Dfg","street2":"Dffg","zip":"400067"}'],
                birthday:'18-8-1990',
                created_at:'2020-08-17T12:16:28.903Z',
                created_by:'G72JtXPRCuOjYAEwS7X8TazOac33',
                email:'savi20@gmail.com',
                firstName:'Abc',
                healthStatus:'Sensitive Skin',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Xyz',
                lastSigninTimestamp:'Mon Aug 17 2020 17:45:01 GMT+0530 (IST)',
                membership_expire:'2020-09-01T12:16:28.904Z',
                modified_at:'2020-08-18T12:02:16.552Z',
                modified_by:'By User',
                object_id:'5e3d07e3-82fa-4938-850d-707ca60b771b',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
        });
        it("Error while updating user details", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.rejectWith("Unable to update the user details")
            await expectAsync(userService.updateUser(mockServer,mockRequest)).toBeRejectedWith("Unable to update the user details")
        })
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update address", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                addressArray:['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Dfg","street2":"Ffgg","zip":"400067"}'],
                userId:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Update user address", async () => {
            spyOn(userService["commonDbService"], "updateAddress").and.resolveTo({
                address:['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Dfg","street2":"Ffgg","zip":"400067"}'],
                birthday:'17-8-1991',
                created_at:'2020-08-17T12:16:28.903Z',
                created_by:'G72JtXPRCuOjYAEwS7X8TazOac33',
                email:'savi20@gmail.com',
                firstName:'Abc',
                healthStatus:'28',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Xyz',
                lastSigninTimestamp:'Mon Aug 17 2020 17:45:01 GMT+0530 (IST)',
                membership_expire:'2020-09-01T12:16:28.904Z',
                modified_at:'2020-08-17T15:29:47.569Z',
                modified_by:'By User',
                object_id:'5e3d07e3-82fa-4938-850d-707ca60b771b',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
            await expectAsync(userService.updateAddress(mockServer,mockRequest,mockRequest["body"])).toBeResolvedTo({
                address:['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Dfg","street2":"Ffgg","zip":"400067"}'],
                birthday:'17-8-1991',
                created_at:'2020-08-17T12:16:28.903Z',
                created_by:'G72JtXPRCuOjYAEwS7X8TazOac33',
                email:'savi20@gmail.com',
                firstName:'Abc',
                healthStatus:'28',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Xyz',
                lastSigninTimestamp:'Mon Aug 17 2020 17:45:01 GMT+0530 (IST)',
                membership_expire:'2020-09-01T12:16:28.904Z',
                modified_at:'2020-08-17T15:29:47.569Z',
                modified_by:'By User',
                object_id:'5e3d07e3-82fa-4938-850d-707ca60b771b',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
        });
        it("Error while updating user details", async () => {
            spyOn(userService["commonDbService"], "updateAddress").and.rejectWith(Promise.reject("Unable to update user address"))
            await expectAsync(userService.updateAddress(mockServer,mockRequest,mockRequest["body"])).toBeRejectedWith("Unable to update user address")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update user properties", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                label:'MEMBER_USER_NL',
                user_info:'{"uid":"pQ66F4cLcETMfdcj4j9H76VT5Hr2","email":"user4@gmail.com","phoneNumber":"9898989898","lastSigninTimestamp":"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)","isNewUser":true,"firstName":"User","healthStatus":"13","lastName":"Four","birthday":"12-8-1995","sex":"female","address":[{"street1":"Ghjj","street2":"Rtty","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}],"img_name":"userName.png"}'
            };
            mockRequest["params"] = {
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            };
        });
        it("Update user property details", async () => {
            spyOn(userService["commonDbService"], "updateUserProperties").and.resolveTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Ghjj","street2":"Rtty","zip":"400067"}'],
                birthday:'12-8-1995',
                created_at:'2020-08-12T14:22:57.150Z',
                created_by:'pQ66F4cLcETMfdcj4j9H76VT5Hr2',
                email:'user4@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Four',
                lastSigninTimestamp:'Wed Aug 12 2020 19:51:46 GMT+0530 (IST)',
                membership_expire:'2020-08-27T14:22:57.151Z',
                modified_at:'2020-08-14T16:15:15.731Z',
                modified_by:'By User',
                object_id:'27e8ed27-c1ac-426a-82f2-0e71933ed406',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
            await expectAsync(userService.updateUserProperties(mockServer,mockRequest,mockRequest["body"])).toBeResolvedTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Ghjj","street2":"Rtty","zip":"400067"}'],
                birthday:'12-8-1995',
                created_at:'2020-08-12T14:22:57.150Z',
                created_by:'pQ66F4cLcETMfdcj4j9H76VT5Hr2',
                email:'user4@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Four',
                lastSigninTimestamp:'Wed Aug 12 2020 19:51:46 GMT+0530 (IST)',
                membership_expire:'2020-08-27T14:22:57.151Z',
                modified_at:'2020-08-14T16:15:15.731Z',
                modified_by:'By User',
                object_id:'27e8ed27-c1ac-426a-82f2-0e71933ed406',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
        });
        it("Error while updating user properties", async () => {
            spyOn(userService["commonDbService"], "updateUserProperties").and.rejectWith(Promise.reject("Unable to update user properties"))
            await expectAsync(userService.updateUserProperties(mockServer,mockRequest,mockRequest["body"])).toBeRejectedWith("Unable to update user properties")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add product", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                EoName:'Bergamot',
                sku:'30790001',
                status:'IN_CART',
                supplier:'doTERRA',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Add product to cart", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo({
                addedProduct:'Bergamot',
                addedUnits:'6',
                sku:'30790001',
                supplier:'doTERRA',
                userId:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
            await expectAsync(userService.addProduct(mockServer,mockRequest)).toBeResolvedTo({
                addedProduct:'Bergamot',
                addedUnits:'6',
                sku:'30790001',
                supplier:'doTERRA',
                userId:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
        });
        it("Error while adding product", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.rejectWith("Unable to add product")
            await expectAsync(userService.addProduct(mockServer,mockRequest)).toBeRejectedWith("Unable to add product")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Remove product", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                EoName:'Bergamot',
                sku:'9333',
                status:'IN_CART',
                supplier:'Melaleuca',
                uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
        });
        it("Removed product successfully", async () => {
            spyOn(userService["commonDbService"], "removeSkuRelation").and.resolveTo({
                identity:['{"low":"1281","high":"0"}'],
                labels: ['{"User","Member"}'],
                properties:{
                    address: ['{"street1":"Sgsg","street2":"Sfsg","city":"Mumbai","state":"Dhhs","country":"India","countryCode":"INR","zip":"400092","defaultAddress":true}'],
                    birthday:'21-8-1990',
                    created_at:'2020-08-21T10:32:57.575Z',
                    created_by:'WhINEC05c2T0rAgqE5jnyUmo5NG2',
                    email:'savi20@gmail.com',
                    firstName:'Abc',
                    healthStatus:'28;13',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Xyz',
                    lastSigninTimestamp:'Fri Aug 21 2020 16:01:51 GMT+0530 (IST)',
                    membership_expire:'2020-09-05T10:32:57.575Z',
                    modified_at:'2020-08-21T12:03:33.794Z',
                    modified_by:'By User',
                    object_id:'e6c55e90-1956-4155-9d6e-4125b119efca',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'female',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
                }
            })
            await expectAsync(userService.removeProduct(mockServer,mockRequest)).toBeResolvedTo({
                identity:['{"low":"1281","high":"0"}'],
                labels: ['{"User","Member"}'],
                properties:{
                    address: ['{"street1":"Sgsg","street2":"Sfsg","city":"Mumbai","state":"Dhhs","country":"India","countryCode":"INR","zip":"400092","defaultAddress":true}'],
                    birthday:'21-8-1990',
                    created_at:'2020-08-21T10:32:57.575Z',
                    created_by:'WhINEC05c2T0rAgqE5jnyUmo5NG2',
                    email:'savi20@gmail.com',
                    firstName:'Abc',
                    healthStatus:'28;13',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Xyz',
                    lastSigninTimestamp:'Fri Aug 21 2020 16:01:51 GMT+0530 (IST)',
                    membership_expire:'2020-09-05T10:32:57.575Z',
                    modified_at:'2020-08-21T12:03:33.794Z',
                    modified_by:'By User',
                    object_id:'e6c55e90-1956-4155-9d6e-4125b119efca',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'female',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
                }
            })
        });
        it("Error while removing product", async () => {
            spyOn(userService["commonDbService"], "removeSkuRelation").and.rejectWith("Unable to remove product")
            await expectAsync(userService.removeProduct(mockServer,mockRequest)).toBeRejectedWith("Unable to remove product")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get health conditions", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid: 'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
        });
        it("Getting an empty health condition", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo([])
            await expectAsync(userService.getHealthConditions(mockServer,mockRequest)).toBeResolvedTo([])
        });
        it("Get health conditions list", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.resolveTo({
                health_condition:['Use Alcohol','Asthma'],
                id:['1','2']
            })
            await expectAsync(userService.getHealthConditions(mockServer,mockRequest)).toBeResolvedTo({
                health_condition:['Use Alcohol','Asthma'],
                id:['1','2']
            })
        });
        it("Error while getting health conditions", async () => {
            spyOn(userService["commonDbService"], "querySelector").and.rejectWith("Unable to get health conditions")
            await expectAsync(userService.getHealthConditions(mockServer,mockRequest)).toBeRejectedWith("Unable to get health conditions")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    // describe("Get filter object", () => {
    //     beforeAll(() => {
    //         mockRequest["body"] = {
    //             uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
    //         };
    //     });
    //     it("Getting an empty filter", async () => {
    //         spyOn(userService["commonDbService"], "getRecommendedFilter").and.resolveTo([])
    //         await expectAsync(userService.getRecommendedFilter(mockServer,mockRequest)).toBeResolvedTo([])
    //     });
    //     it("Having a filter objects", async () => {
    //         spyOn(userService["commonDbService"], "getRecommendedFilter").and.resolveTo({
    //             array: {
    //                 id: ['1', '2', '3', '4', '5', '6', '7'],
    //                 name:'Recommended use',
    //                 values: ['Anxiety', 'Cleaning', 'Headache', 'Immune System Booster', 'Inflammation', 'Insomnia', 'Pain']
    //             }
    //         })
    //         await expectAsync(userService.getRecommendedFilter(mockServer,mockRequest)).toBeResolvedTo({
    //             array: {
    //                 id: ['1', '2', '3', '4', '5', '6', '7'],
    //                 name:'Recommended use',
    //                 values: ['Anxiety', 'Cleaning', 'Headache', 'Immune System Booster', 'Inflammation', 'Insomnia', 'Pain']
    //             }
    //         })
    //     });
    //     it("Error while getting filters", async () => {
    //         spyOn(userService["commonDbService"], "getRecommendedFilter").and.rejectWith("Unable to get filter objects")
    //         await expectAsync(userService.getRecommendedFilter(mockServer,mockRequest)).toBeRejectedWith("Unable to get filter objects")
    //     });
    //     afterAll(() => {
    //         mockRequest["params"] = {};
    //         mockRequest["query"] = {};
    //         mockRequest["body"] = {};
    //     });
    // });

    describe("Get EO filter object", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
        });
        it("Getting an empty EO filter", async () => {
            spyOn(userService["commonDbService"], "getEOFilter").and.resolveTo([])
            await expectAsync(userService.getEOFilter(mockServer,mockRequest)).toBeResolvedTo([])
        });
        it("Having a EO filter objects", async () => {
            spyOn(userService["commonDbService"], "getEOFilter").and.resolveTo({
                array: {
                    id: ['Single', 'Blend', 'Carrier Oil'],
                    name: 'Essential oil type',
                    values: ['Single', 'Blend', 'Carrier Oil']
                },
                array1: {
                    id: ['doTERRA', 'Young Living', 'Saje', 'NA', 'escents', 'Melaleuca', 'Plant Thearpy', 'doTerra', 'esence'],
                    name: 'Supplier list',
                    values: ['doTERRA', 'Young Living', 'Saje', 'NA', 'escents', 'Melaleuca', 'Plant Thearpy', 'doTerra', 'esence']
                }
            })
            await expectAsync(userService.getEOFilter(mockServer,mockRequest)).toBeResolvedTo({
                array: {
                    id: ['Single', 'Blend', 'Carrier Oil'],
                    name: 'Essential oil type',
                    values: ['Single', 'Blend', 'Carrier Oil']
                },
                array1: {
                    id: ['doTERRA', 'Young Living', 'Saje', 'NA', 'escents', 'Melaleuca', 'Plant Thearpy', 'doTerra', 'esence'],
                    name: 'Supplier list',
                    values: ['doTERRA', 'Young Living', 'Saje', 'NA', 'escents', 'Melaleuca', 'Plant Thearpy', 'doTerra', 'esence']
                }
            })
        });
        it("Error while getting EO filters", async () => {
            spyOn(userService["commonDbService"], "getEOFilter").and.rejectWith("Unable to get EO filter objects")
            await expectAsync(userService.getEOFilter(mockServer,mockRequest)).toBeRejectedWith("Unable to get EO filter objects")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Check User Membership", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
        });
        // it("Membership Active", async () => {
        //     await expectAsync(userService.checkUserMembership(mockServer, mockRequest)).toBeResolvedTo(true);
        // });
        // it("Membership Expired", async () => {
        //     await expectAsync(userService.checkUserMembership(mockServer, mockRequest)).toBeResolvedTo(false);
        // });
        // it("Error while checking user membership details", async () => {
        //     await expectAsync(userService.checkUserMembership(mockServer,mockRequest)).toBeRejectedWith("Unable to view user membership details");
        // });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    // describe("Upload Image To Blob", () => {
    //     beforeAll(() => {
        
    //     });
    //     afterAll(() => {
    //         mockRequest["params"] = {};
    //         mockRequest["query"] = {};
    //         mockRequest["body"] = {};
    //     });
    // });

    describe("Swagger login", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                user_info:{email: 'mhtsharma948@gmail.com', password: 'mohit.1234'},
            };
        });
        // it("Successfully logged into swagger", async () => {
        //     spyOn(urlHttpClient, "request").and.resolveTo({
        //         kind:'identitytoolkit#VerifyCustomTokenResponse',
        //         idToken:'eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ5ZTg4YzUzNzYxOTk2YTczNjIzZjE5MWQ1MTJkMmI0N2RmODAyYTEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZW80dS1mZGU5YiIsImF1ZCI6ImVvNHUtZmRlOWIiLCJhdXRoX3RpbWUiOjE1OTc3NTY0NjAsInVzZXJfaWQiOiJlZWZlMzM2My0xOWY2LTRiYTgtYWZlOC0zNWE0OWI1ZTM4MDEiLCJzdWIiOiJlZWZlMzM2My0xOWY2LTRiYTgtYWZlOC0zNWE0OWI1ZTM4MDEiLCJpYXQiOjE1OTc3NTY0NjAsImV4cCI6MTU5Nzc2MDA2MCwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6e30sInNpZ25faW5fcHJvdmlkZXIiOiJjdXN0b20ifX0.iwfUVCCHxgnODT1oT-Ou-tXpOn0S24GfMqB1xACxI3irlwh4I0JhjFTt2UHzVUbr23x89jbgxX8gbnG94psIzgixsOI9MyssuQkHWMb1_9Qd7ApqLOzVSjGC2_2ZPNWSuXjE7FsadUpOMxhMA550kksC7vJmEsRr39rZl4lxZVtF4iCWJ8KWWySGjnB5wuPJpR1f8gTRL-Z7wPxnhI4W2BDYdGh2yisBwj-UnsJeR4dxkwNaChuvuO_DJbnDdKvhmq_IttD9XPl6vFIkh_YEk91cr9nycEE-FNy7AHmTF-mr0rTw68nhesmskEChlBqWo_2t1bksNXLr8PO2wE2Crw',
        //         refreshToken:'AE0u-NdHAyGTTW0LOA4T5Jc81rl7rHlNf7Qpi9h2dJJ-h8UO7IJ2yqOYbTWmi4a3eyxaPd9bBkQzihl6_DFZZyuH1dxWVXUTzYsUGKA3a3E8viUVIlpzNAvkJ8O_ATzlLGWyBfctNjgfWhN8FlLPCR_5_d_ICWLu3g48PpI0bTg6f2RO2OIkTIY',
        //         expiresIn:'3600',
        //         isNewUser:true
        //     });
        //     await expectAsync(userService.swaggerLogin(mockServer, mockRequest)).toBeResolvedTo({
        //         kind:'identitytoolkit#VerifyCustomTokenResponse',
        //         idToken:'eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ5ZTg4YzUzNzYxOTk2YTczNjIzZjE5MWQ1MTJkMmI0N2RmODAyYTEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZW80dS1mZGU5YiIsImF1ZCI6ImVvNHUtZmRlOWIiLCJhdXRoX3RpbWUiOjE1OTc3NTY0NjAsInVzZXJfaWQiOiJlZWZlMzM2My0xOWY2LTRiYTgtYWZlOC0zNWE0OWI1ZTM4MDEiLCJzdWIiOiJlZWZlMzM2My0xOWY2LTRiYTgtYWZlOC0zNWE0OWI1ZTM4MDEiLCJpYXQiOjE1OTc3NTY0NjAsImV4cCI6MTU5Nzc2MDA2MCwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6e30sInNpZ25faW5fcHJvdmlkZXIiOiJjdXN0b20ifX0.iwfUVCCHxgnODT1oT-Ou-tXpOn0S24GfMqB1xACxI3irlwh4I0JhjFTt2UHzVUbr23x89jbgxX8gbnG94psIzgixsOI9MyssuQkHWMb1_9Qd7ApqLOzVSjGC2_2ZPNWSuXjE7FsadUpOMxhMA550kksC7vJmEsRr39rZl4lxZVtF4iCWJ8KWWySGjnB5wuPJpR1f8gTRL-Z7wPxnhI4W2BDYdGh2yisBwj-UnsJeR4dxkwNaChuvuO_DJbnDdKvhmq_IttD9XPl6vFIkh_YEk91cr9nycEE-FNy7AHmTF-mr0rTw68nhesmskEChlBqWo_2t1bksNXLr8PO2wE2Crw',
        //         refreshToken:'AE0u-NdHAyGTTW0LOA4T5Jc81rl7rHlNf7Qpi9h2dJJ-h8UO7IJ2yqOYbTWmi4a3eyxaPd9bBkQzihl6_DFZZyuH1dxWVXUTzYsUGKA3a3E8viUVIlpzNAvkJ8O_ATzlLGWyBfctNjgfWhN8FlLPCR_5_d_ICWLu3g48PpI0bTg6f2RO2OIkTIY',
        //         expiresIn:'3600',
        //         isNewUser:true
        //     })
        // });
        it("Error while login into swagger", async () => {
            spyOn(userService, "swaggerLogin").and.rejectWith("Unable to login into swagger")
            await expectAsync(userService.swaggerLogin(mockServer,mockRequest)).toBeRejectedWith("Unable to login into swagger")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add a product review", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                eo_id:'04c9861c-ad6f-4467-a037-05c73ea5fe3f',
                review:'Soften my skin',
                star:4,
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Adding product review", async () => {
            spyOn(userService["commonDbService"], "addProductReview").and.resolveTo({
                identity:['{"high":"0","low":"1307"}'],
                labels:['{"0":"Review","length":"1"}'],
                properties:[{"star":"4","review":"Soften my skin"}]
            })
            await expectAsync(userService.addProductReview(mockServer,mockRequest)).toBeResolvedTo({
                identity:['{"high":"0","low":"1307"}'],
                labels:['{"0":"Review","length":"1"}'],
                properties:[{"star":"4","review":"Soften my skin"}]
            })
        });
        it("Error while adding product review", async () => {
            spyOn(userService["commonDbService"], "addProductReview").and.rejectWith("Unable to add product review")
            await expectAsync(userService.addProductReview(mockServer,mockRequest)).toBeRejectedWith("Unable to add product review")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update a product review", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                eo_id:'eea8cfa3-7ced-4810-bd2b-04ad19589d97',
                review:'Soften my skin and glow',
                star:4
            };
        });
        it("Updating product review", async () => {
            spyOn(userService["commonDbService"], "updateProductReview").and.resolveTo({
                identity:['{"high":"0","low":"1305"}'],
                labels:['{"0":"Review","length":"1"}'],
                properties:[{"star":"4","review":"Soften my skin and glow"}]
            })
            await expectAsync(userService.updateProductReview(mockServer,mockRequest)).toBeResolvedTo({
                identity:['{"high":"0","low":"1305"}'],
                labels:['{"0":"Review","length":"1"}'],
                properties:[{"star":"4","review":"Soften my skin and glow"}]
            })
        });
        it("Error while updating product review", async () => {
            spyOn(userService["commonDbService"], "updateProductReview").and.rejectWith("Unable to update product review")
            await expectAsync(userService.updateProductReview(mockServer,mockRequest)).toBeRejectedWith("Unable to update product review")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get a User product review", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                eoId:'eea8cfa3-7ced-4810-bd2b-04ad19589d97'
            };
        });
        it("Get user product review", async () => {
            spyOn(userService["commonDbService"], "getUserProductReview").and.resolveTo({
                review:'Soften my skin and glow',
                star:4,
                userImg:'userName.png',
                userName:'Abc Xyz'
            })
            await expectAsync(userService.getUserProductReview(mockRequest["query"],mockServer,mockRequest)).toBeResolvedTo({
                review:'Soften my skin and glow',
                star:4,
                userImg:'userName.png',
                userName:'Abc Xyz'
            })
        });
        it("Error while getting user product review details", async () => {
            spyOn(userService["commonDbService"], "getUserProductReview").and.rejectWith("Unable to get user product review")
            await expectAsync(userService.getUserProductReview(mockRequest["query"],mockServer,mockRequest)).toBeRejectedWith("Unable to get user product review")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get a product reviews", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                eoId:'62bb056d-e632-4ce8-97b6-1e97ba0dee30',
                limit:10,
                offset:0,
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Get product review", async () => {
            spyOn(userService["commonDbService"], "getProductReviews").and.resolveTo([])
            await expectAsync(userService.getProductReviews(mockRequest["query"],mockServer,mockRequest)).toBeResolvedTo([])
        });
        it("Error while getting product review", async () => {
            spyOn(userService["commonDbService"], "getProductReviews").and.rejectWith("Unable to get product review details")
            await expectAsync(userService.getProductReviews(mockRequest["query"],mockServer,mockRequest)).toBeRejectedWith("Unable to get product review details")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
});