import { MockReply, MockServer } from "./../../../../helpers/common_mock.helper";
import { UserController } from "./../../../../../src/modules/user/controller/user.controller";

describe("User controller Unit tests:", () => {
    let userController: UserController;
    let mockRequest: any;
    let mockReply: any;
    let mockServer: MockServer;
    let expectedReturn:any;
    const uid = "cCQYH0vQsubIVutJ5cbR643ESKk2";

    beforeAll(() => {
        mockServer = new MockServer();
        mockReply = new MockReply();
        mockRequest =  {req:{user:{uid}}, params : {}, query : {}, body: {}};
        userController = new UserController();
    });

    describe("Get User info", () => {
        beforeAll(() => {
            mockRequest["params"] = {
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'  
            }
        });
        it("Get user Info empty", async () => {
            spyOn(userController["userService"], "getUser").and.resolveTo([])
            await expectAsync(userController.getUser(mockServer, mockRequest, mockReply)).toBeResolvedTo([])
        });
        it("Having a user info", async () => {
            spyOn(userController["userService"], "getUser").and.resolveTo({
                address:['{"street1":"9898989898","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'12-8-1995',
                countryCode:'INR',
                created_at:'2020-08-12T14:22:57.150Z',
                created_by:'pQ66F4cLcETMfdcj4j9H76VT5Hr2',
                email:'user4@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Four',
                lastSigninTimestamp:'Wed Aug 12 2020 19:51:46 GMT+0530 (IST)',
                membership_expire:'2020-08-27T14:22:57.151Z',
                modified_at:'',
                modified_by:'',
                object_id:'27e8ed27-c1ac-426a-82f2-0e71933ed406',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
            await expectAsync(userController.getUser(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                address:['{"street1":"9898989898","street2":"9999999999","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'12-8-1995',
                countryCode:'INR',
                created_at:'2020-08-12T14:22:57.150Z',
                created_by:'pQ66F4cLcETMfdcj4j9H76VT5Hr2',
                email:'user4@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Four',
                lastSigninTimestamp:'Wed Aug 12 2020 19:51:46 GMT+0530 (IST)',
                membership_expire:'2020-08-27T14:22:57.151Z',
                modified_at:'',
                modified_by:'',
                object_id:'27e8ed27-c1ac-426a-82f2-0e71933ed406',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
        });
        it("Error while getting user info", async () => {
            spyOn(userController["userService"], "getUser").and.rejectWith(Promise.reject("Unable to get user info"));
            await expectAsync(userController.getUser(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to get user info");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    
    // describe("Get User profile Image", () => {
    //     beforeAll(() => {
    //     });
        
    //     afterAll(() => {
    //         mockRequest["params"] = {};
    //         mockRequest["query"] = {};
    //         mockRequest["body"] = {};
    //     });
    // });

    describe("Add User", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                label:'MEMBER_USER_NL',
                uid: 'bvXNA0GXVNNtqDifVMqNyv4bN7H3'
            };
        });
        it("Add user info", async () =>{
            spyOn(userController["userService"], "addUser").and.resolveTo({
                address:['{"street1":"Dhdh","street2":"Ryr","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'26-12-1986',
                created_at:'2020-08-14T11:30:02.565Z',
                created_by:'bvXNA0GXVNNtqDifVMqNyv4bN7H3',
                email:'user5@gmail.com',
                firstName:'User',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Five',
                lastSigninTimestamp:'Fri Aug 14 2020 16:55:15 GMT+0530 (IST)',
                membership_expire:'2020-08-29T11:30:02.565Z',
                modified_at:'',
                modified_by:'',
                object_id:'1e6deea0-541d-4196-9453-104d43cfce2b',
                phoneNumber:'9696969696',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'bvXNA0GXVNNtqDifVMqNyv4bN7H3'
            })
            await expectAsync(userController.addUser(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                address:['{"street1":"Dhdh","street2":"Ryr","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'26-12-1986',
                created_at:'2020-08-14T11:30:02.565Z',
                created_by:'bvXNA0GXVNNtqDifVMqNyv4bN7H3',
                email:'user5@gmail.com',
                firstName:'User',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Five',
                lastSigninTimestamp:'Fri Aug 14 2020 16:55:15 GMT+0530 (IST)',
                membership_expire:'2020-08-29T11:30:02.565Z',
                modified_at:'',
                modified_by:'',
                object_id:'1e6deea0-541d-4196-9453-104d43cfce2b',
                phoneNumber:'9696969696',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'bvXNA0GXVNNtqDifVMqNyv4bN7H3'
            })
        });
        it("Error while adding user", async () => {
            spyOn(userController["userService"], "addUser").and.rejectWith(Promise.reject("Unable to add user"));
            await expectAsync(userController.addUser(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to add user");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update User", async () => {
        beforeAll(() => {
            mockRequest["body"] = {
                label:'MEMBER_USER_NL',
                user_info:'{"uid":"G72JtXPRCuOjYAEwS7X8TazOac33","email":"savi20@gmail.com","phoneNumber":"9898989898","lastSigninTimestamp":"Mon Aug 17 2020 17:45:01 GMT+0530 (IST)","isNewUser":true,"firstName":"Abc","healthStatus":"28","lastName":"Xyz","birthday":"17-8-1991","sex":"female","address":[{"street1":"Dfg","street2":"Dffg","city":"Mumbai ","state":"Maharashtra ","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}]}'
            };
            mockRequest["params"] = {
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
            mockRequest["files"] = []
        });
        it("user details is empty", async () => {
            spyOn(userController["userService"], "updateUser").and.resolveTo(undefined);
            await expectAsync(userController.updateUser(mockServer,mockRequest,mockReply)).toBeResolvedTo(undefined);
        })
        it("Update user details", async () => {
            spyOn(userController["userService"], "updateUser").and.resolveTo({
                address:['{"street1":"Dfg","street2":"Dffg","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'17-8-1991',
                created_at:'2020-08-17T12:16:28.903Z',
                created_by:'G72JtXPRCuOjYAEwS7X8TazOac33',
                email:'savi20@gmail.com',
                firstName:'Abc',
                healthStatus:'Sensitive Skin',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Xyz',
                lastSigninTimestamp:'Mon Aug 17 2020 17:45:01 GMT+0530 (IST)',
                membership_expire:'2020-09-01T12:16:28.904Z',
                modified_at:'2020-08-17T15:16:10.943Z',
                modified_by:'By User',
                object_id:'5e3d07e3-82fa-4938-850d-707ca60b771b',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
            await expectAsync(userController.updateUser(mockServer, mockRequest, mockReply)).toBeResolvedTo({
                address:['{"street1":"Dfg","street2":"Dffg","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}'],
                birthday:'17-8-1991',
                created_at:'2020-08-17T12:16:28.903Z',
                created_by:'G72JtXPRCuOjYAEwS7X8TazOac33',
                email:'savi20@gmail.com',
                firstName:'Abc',
                healthStatus:'Sensitive Skin',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Xyz',
                lastSigninTimestamp:'Mon Aug 17 2020 17:45:01 GMT+0530 (IST)',
                membership_expire:'2020-09-01T12:16:28.904Z',
                modified_at:'2020-08-17T15:16:10.943Z',
                modified_by:'By User',
                object_id:'5e3d07e3-82fa-4938-850d-707ca60b771b',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            })
        });
        it("Error while updating user details", async () => {
            spyOn(userController["userService"], "updateUser").and.rejectWith(Promise.reject("Unable to update the user details"));
            await expectAsync(userController.updateUser(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to update the user details");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add product", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                EoName:'Bergamot',
                sku:'30790001',
                status:'IN_CART',
                supplier:'doTERRA',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            };
        });
        it("Add product to cart", async () => {
            spyOn(userController["userService"], "addProduct").and.resolveTo({
                addedProduct:'Bergamot',
                addedUnits:'1',
                sku:'30790001',
                supplier:'doTERRA',
                userId:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
            await expectAsync(userController.addProduct(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                addedProduct:'Bergamot',
                addedUnits:'1',
                sku:'30790001',
                supplier:'doTERRA',
                userId:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
        });
        it("Error while adding product", async () => {
            spyOn(userController["userService"], "addProduct").and.rejectWith(Promise.reject("Unable to add product"))
            await expectAsync(userController.addProduct(mockServer, mockRequest, mockReply)).toBeRejectedWith("Unable to add product")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Remove product", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                EoName:'Bergamot',
                sku:'9333',
                status:'IN_CART',
                supplier:'Melaleuca',
                uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
        });
        it("Remove product", async () => {
            spyOn(userController["userService"], "removeProduct").and.resolveTo({
                identity:['{"low":"1281","high":"0"}'],
                labels: ['{"User","Member"}'],
                properties:{
                    address: ['{"street1":"Sgsg","street2":"Sfsg","city":"Mumbai","state":"Dhhs","country":"India","countryCode":"INR","zip":"400092","defaultAddress":true}'],
                    birthday:'21-8-1990',
                    created_at:'2020-08-21T10:32:57.575Z',
                    created_by:'WhINEC05c2T0rAgqE5jnyUmo5NG2',
                    email:'savi20@gmail.com',
                    firstName:'Abc',
                    healthStatus:'28;13',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Xyz',
                    lastSigninTimestamp:'Fri Aug 21 2020 16:01:51 GMT+0530 (IST)',
                    membership_expire:'2020-09-05T10:32:57.575Z',
                    modified_at:'2020-08-21T12:03:33.794Z',
                    modified_by:'By User',
                    object_id:'e6c55e90-1956-4155-9d6e-4125b119efca',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'female',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
                }
            })
            await expectAsync(userController.removeProduct(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                identity:['{"low":"1281","high":"0"}'],
                labels: ['{"User","Member"}'],
                properties:{
                    address: ['{"street1":"Sgsg","street2":"Sfsg","city":"Mumbai","state":"Dhhs","country":"India","countryCode":"INR","zip":"400092","defaultAddress":true}'],
                    birthday:'21-8-1990',
                    created_at:'2020-08-21T10:32:57.575Z',
                    created_by:'WhINEC05c2T0rAgqE5jnyUmo5NG2',
                    email:'savi20@gmail.com',
                    firstName:'Abc',
                    healthStatus:'28;13',
                    img_name:'userName.png',
                    isNewUser:true,
                    lastName:'Xyz',
                    lastSigninTimestamp:'Fri Aug 21 2020 16:01:51 GMT+0530 (IST)',
                    membership_expire:'2020-09-05T10:32:57.575Z',
                    modified_at:'2020-08-21T12:03:33.794Z',
                    modified_by:'By User',
                    object_id:'e6c55e90-1956-4155-9d6e-4125b119efca',
                    phoneNumber:'9898989898',
                    premiumUser:false,
                    role:'MEMBER',
                    sex:'female',
                    status:'active',
                    stripeCustomerID:'',
                    uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
                }
            })
        });
        it("Error while removing product", async () => {
            spyOn(userController["userService"], "removeProduct").and.rejectWith(Promise.reject("Unable to remove product"))
            await expectAsync(userController.removeProduct(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to remove product")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get health conditions", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid: 'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            };
        });
        it("Getting an empty health condition", async () => {
            spyOn(userController["userService"], "getHealthConditions").and.resolveTo([])
            await expectAsync(userController.getHealthConditions(mockServer,mockRequest,mockReply)).toBeResolvedTo([])
        });
        it("Get health conditions list", async () => {
            spyOn(userController["userService"], "getHealthConditions").and.resolveTo({
                health_condition:'Use Alcohol',
                id:'1'
            })
            await expectAsync(userController.getHealthConditions(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                health_condition:'Use Alcohol',
                id:'1'
            })
        });
        it("Error while getting health conditions", async () => {
            spyOn(userController["userService"], "getHealthConditions").and.rejectWith(Promise.reject("Unable to get health conditions"));
            await expectAsync(userController.getHealthConditions(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get health conditions");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get filter object", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'WhINEC05c2T0rAgqE5jnyUmo5NG2'
            };
        });
        it("Getting an empty filter", async () => {
            spyOn(userController["userService"], "getRecommendedFilter").and.resolveTo([])
            await expectAsync(userController.getRecommendFilterObject(mockServer,mockRequest,mockReply)).toBeResolvedTo([])
        });
        it("Having a filter objects", async () => {
            spyOn(userController["userService"], "getRecommendedFilter").and.resolveTo({
                array: {
                    id: ['1', '2', '3', '4', '5', '6', '7'],
                    name:'Recommended use',
                    values: ['Anxiety', 'Cleaning', 'Headache', 'Immune System Booster', 'Inflammation', 'Insomnia', 'Pain']
                }
            })
            await expectAsync(userController.getRecommendFilterObject(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                array: {
                    id: ['1', '2', '3', '4', '5', '6', '7'],
                    name:'Recommended use',
                    values: ['Anxiety', 'Cleaning', 'Headache', 'Immune System Booster', 'Inflammation', 'Insomnia', 'Pain']
                }
            })
        });
        it("Error while getting filters", async () => {
            spyOn(userController["userService"], "getRecommendedFilter").and.rejectWith(Promise.reject("Unable to get filter objects"));
            await expectAsync(userController.getRecommendFilterObject(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get filter objects");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get EO filter object", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            };
        });
        it("Getting an empty EO filter objects", async () => {
            spyOn(userController["userService"], "getEOFilter").and.resolveTo([])
            await expectAsync(userController.getEOFilterObject(mockServer,mockRequest,mockReply)).toBeResolvedTo([])
        });
        it("Having an EO filter objects", async () => {
            spyOn(userController["userService"], "getEOFilter").and.resolveTo({
                values: ['{"0":"Single","1":"Blend","2":"Carrier Oil","name":"Essential oil type"}']
            })
            await expectAsync(userController.getEOFilterObject(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                values: ['{"0":"Single","1":"Blend","2":"Carrier Oil","name":"Essential oil type"}']
            })
        });
        it("Error while getting EO filters", async () => {
            spyOn(userController["userService"], "getEOFilter").and.rejectWith(Promise.reject("Unable to get EO filter objects"));
            await expectAsync(userController.getEOFilterObject(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get EO filter objects");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Check User Membership", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            };
        });
        it("View user membership details", async () => {
            spyOn(userController["userService"], "checkUserMembership").and.resolveTo([true])
            await expectAsync(userController.checkUserMembership(mockServer,mockRequest,mockReply)).toBeResolvedTo([true])
        });
        it("Error while checking user membership details", async () => {
            spyOn(userController["userService"], "checkUserMembership").and.rejectWith(Promise.reject("Unable to view user membership details"));
            await expectAsync(userController.checkUserMembership(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to view user membership details");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update address", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                addressArray: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Ghjj","street2":"Rtty","zip":"400067"}'],
                userId:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            };
        });
        it("Update user address", async () => {
            spyOn(userController["userService"], "updateAddress").and.resolveTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Ghjj","street2":"Rtty","zip":"400067"}'],
                birthday:'12-8-1995',
                created_at:'2020-08-12T14:22:57.150Z',
                created_by:'pQ66F4cLcETMfdcj4j9H76VT5Hr2',
                email:'user4@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Four',
                lastSigninTimestamp:'Wed Aug 12 2020 19:51:46 GMT+0530 (IST)',
                membership_expire:'2020-08-27T14:22:57.151Z',
                modified_at:'2020-08-14T16:15:15.731Z',
                modified_by:'By User',
                object_id:'27e8ed27-c1ac-426a-82f2-0e71933ed406',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
            await expectAsync(userController.updateAddress(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Ghjj","street2":"Rtty","zip":"400067"}'],
                birthday:'12-8-1995',
                created_at:'2020-08-12T14:22:57.150Z',
                created_by:'pQ66F4cLcETMfdcj4j9H76VT5Hr2',
                email:'user4@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Four',
                lastSigninTimestamp:'Wed Aug 12 2020 19:51:46 GMT+0530 (IST)',
                membership_expire:'2020-08-27T14:22:57.151Z',
                modified_at:'2020-08-14T16:15:15.731Z',
                modified_by:'By User',
                object_id:'27e8ed27-c1ac-426a-82f2-0e71933ed406',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
        });
        it("Error while updating user address", async () => {
            spyOn(userController["userService"], "updateAddress").and.rejectWith(Promise.reject("Unable to update user address"));
            await expectAsync(userController.updateAddress(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to update user address");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
    
    describe("Swagger login", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                user_info:{email: 'mhtsharma948@gmail.com', password: 'mohit.1234'},
            };
        });
        it("Login into swagger", async () => {
            spyOn(userController["userService"], "swaggerLogin").and.resolveTo({
                expiresIn:'3600',
                idToken:'eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ5ZTg4YzUzNzYxOTk2YTczNjIzZjE5MWQ1MTJkMmI0N2RmODAyYTEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZW80dS1mZGU5YiIsImF1ZCI6ImVvNHUtZmRlOWIiLCJhdXRoX3RpbWUiOjE1OTc2NzU3MDgsInVzZXJfaWQiOiIzNjM5MDkyNy00YTQ2LTQxZGQtYjM3OS0yMzExMDBmOTk4ZGMiLCJzdWIiOiIzNjM5MDkyNy00YTQ2LTQxZGQtYjM3OS0yMzExMDBmOTk4ZGMiLCJpYXQiOjE1OTc2NzU3MDgsImV4cCI6MTU5NzY3OTMwOCwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6e30sInNpZ25faW5fcHJvdmlkZXIiOiJjdXN0b20ifX0.V1QlK0B8uU2cnipbt333h-aKz4bk1Lc-8tSWLVXYYGkftNsKmW0zAwKk1yw8u-_IuyH7JO07viFOnzUTMIlhY9cJdkmAJqD9_Jdz_vWFovUfVXk3cQWoLVmQwJcEdciNbGdbg67N0HyM7o58WS3ypvmhFuR2KwntQ7CzB04Vb5znbUNs98T3OqNJUy4KuuAnkMzSq_38nE3pSq1lMGVDB2FIXsemBQHiTsvIgKco8tUUSpmdEGJN3m9ZwZ0jOigbT8lNnz6rvMV4dIs7N93VottOBf6skN8Vri3pzJv24AO7KD7NUarDR87nbkCsYjK3dkzWofXg0kQHMsSgFRIbEQ',
                isNewUser:true,
                kind:'identitytoolkit#VerifyCustomTokenResponse',
                refreshToken:'AE0u-NfpwCtElFTYJhWHy4DHoJo9UJS32jMAMapZG1xMX1K2grb9i879PYiRwwXt3y9b3IriAQ965JfcH_5zNJTRlfq6hR2gPMQKDtKDnu2ZHzVKb9sepZ5fJWSX44Td_Z1f825ml0aBIDQ0p79mVE6MdJoHclxptJmc4XdrqBMTeWtFnyLNxhg'
            })
            await expectAsync(userController.swaggerLogin(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                expiresIn:'3600',
                idToken:'eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ5ZTg4YzUzNzYxOTk2YTczNjIzZjE5MWQ1MTJkMmI0N2RmODAyYTEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZW80dS1mZGU5YiIsImF1ZCI6ImVvNHUtZmRlOWIiLCJhdXRoX3RpbWUiOjE1OTc2NzU3MDgsInVzZXJfaWQiOiIzNjM5MDkyNy00YTQ2LTQxZGQtYjM3OS0yMzExMDBmOTk4ZGMiLCJzdWIiOiIzNjM5MDkyNy00YTQ2LTQxZGQtYjM3OS0yMzExMDBmOTk4ZGMiLCJpYXQiOjE1OTc2NzU3MDgsImV4cCI6MTU5NzY3OTMwOCwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6e30sInNpZ25faW5fcHJvdmlkZXIiOiJjdXN0b20ifX0.V1QlK0B8uU2cnipbt333h-aKz4bk1Lc-8tSWLVXYYGkftNsKmW0zAwKk1yw8u-_IuyH7JO07viFOnzUTMIlhY9cJdkmAJqD9_Jdz_vWFovUfVXk3cQWoLVmQwJcEdciNbGdbg67N0HyM7o58WS3ypvmhFuR2KwntQ7CzB04Vb5znbUNs98T3OqNJUy4KuuAnkMzSq_38nE3pSq1lMGVDB2FIXsemBQHiTsvIgKco8tUUSpmdEGJN3m9ZwZ0jOigbT8lNnz6rvMV4dIs7N93VottOBf6skN8Vri3pzJv24AO7KD7NUarDR87nbkCsYjK3dkzWofXg0kQHMsSgFRIbEQ',
                isNewUser:true,
                kind:'identitytoolkit#VerifyCustomTokenResponse',
                refreshToken:'AE0u-NfpwCtElFTYJhWHy4DHoJo9UJS32jMAMapZG1xMX1K2grb9i879PYiRwwXt3y9b3IriAQ965JfcH_5zNJTRlfq6hR2gPMQKDtKDnu2ZHzVKb9sepZ5fJWSX44Td_Z1f825ml0aBIDQ0p79mVE6MdJoHclxptJmc4XdrqBMTeWtFnyLNxhg'
            })
        });
        it("Error while login into swagger", async () => {
            spyOn(userController["userService"], "swaggerLogin").and.rejectWith(Promise.reject("Unable to login into swagger"));
            await expectAsync(userController.swaggerLogin(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to login into swagger");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update user properties", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                label:'MEMBER_USER_NL',
                user_info:'{"uid":"pQ66F4cLcETMfdcj4j9H76VT5Hr2","email":"user4@gmail.com","phoneNumber":"9898989898","lastSigninTimestamp":"Wed Aug 12 2020 19:51:46 GMT+0530 (IST)","isNewUser":true,"firstName":"User","healthStatus":"13","lastName":"Four","birthday":"12-8-1995","sex":"female","address":[{"street1":"Ghjj","street2":"Rtty","city":"Mumbai","state":"Maharashtra","country":"India","countryCode":"INR","zip":"400067","defaultAddress":true}],"img_name":"userName.png"}'
            };
            mockRequest["params"] = {
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            };
        });
        it("Update user property details", async () => {
            spyOn(userController["userService"], "updateUserProperties").and.resolveTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Ghjj","street2":"Rtty","zip":"400067"}'],
                birthday:'12-8-1995',
                created_at:'2020-08-12T14:22:57.150Z',
                created_by:'pQ66F4cLcETMfdcj4j9H76VT5Hr2',
                email:'user4@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Four',
                lastSigninTimestamp:'Wed Aug 12 2020 19:51:46 GMT+0530 (IST)',
                membership_expire:'2020-08-27T14:22:57.151Z',
                modified_at:'2020-08-14T16:15:15.731Z',
                modified_by:'By User',
                object_id:'27e8ed27-c1ac-426a-82f2-0e71933ed406',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
            await expectAsync(userController.updateUserProperties(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                address: ['{"city":"Mumbai","country":"India","countryCode":"INR","defaultAddress":"true","state":"Maharashtra","street1":"Ghjj","street2":"Rtty","zip":"400067"}'],
                birthday:'12-8-1995',
                created_at:'2020-08-12T14:22:57.150Z',
                created_by:'pQ66F4cLcETMfdcj4j9H76VT5Hr2',
                email:'user4@gmail.com',
                firstName:'User',
                healthStatus:'',
                img_name:'userName.png',
                isNewUser:true,
                lastName:'Four',
                lastSigninTimestamp:'Wed Aug 12 2020 19:51:46 GMT+0530 (IST)',
                membership_expire:'2020-08-27T14:22:57.151Z',
                modified_at:'2020-08-14T16:15:15.731Z',
                modified_by:'By User',
                object_id:'27e8ed27-c1ac-426a-82f2-0e71933ed406',
                phoneNumber:'9898989898',
                premiumUser:false,
                role:'MEMBER',
                sex:'female',
                status:'active',
                stripeCustomerID:'',
                uid:'pQ66F4cLcETMfdcj4j9H76VT5Hr2'
            })
        });
        it("Error while updating user properties", async () => {
            spyOn(userController["userService"], "updateUserProperties").and.rejectWith(Promise.reject("Unable to update user properties"));
            await expectAsync(userController.updateUserProperties(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to update user properties");
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Add a product review", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                eo_id:'62bb056d-e632-4ce8-97b6-1e97ba0dee30',
                review:'Soften my skin',
                star:4,
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Adding product review", async () => {
            spyOn(userController["userService"], "addProductReview").and.resolveTo({
                identity:['{"high":"0","low":"1322"}'],
                labels:['{"0":"Review","length":"1"}'],
                properties:[{"star":"4","review":"Soften my skin"}]
            })
            await expectAsync(userController.addProductReview(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                identity:['{"high":"0","low":"1322"}'],
                labels:['{"0":"Review","length":"1"}'],
                properties:[{"star":"4","review":"Soften my skin"}]
            })
        });
        it("Error while adding product review", async () => {
            spyOn(userController["userService"], "addProductReview").and.rejectWith(Promise.reject("Unable to add product review"))
            await expectAsync(userController.addProductReview(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to add product review")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Update a product review", () => {
        beforeAll(() => {
            mockRequest["body"] = {
                eo_id:'62bb056d-e632-4ce8-97b6-1e97ba0dee30',
                review:'Soften my skin and glow.',
                star:3,
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Updating product review ", async () => {
            spyOn(userController["userService"], "updateProductReview").and.resolveTo({
                identity:['{"high":"0","low":"1322"}'],
                labels:['{"0":"Review","length":"1"}'],
                properties:['{"star":"3","review":"Soften my skin and glow."}']
            })
            await expectAsync(userController.updateProductReview(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                identity:['{"high":"0","low":"1322"}'],
                labels:['{"0":"Review","length":"1"}'],
                properties:['{"star":"3","review":"Soften my skin and glow."}']
            })
        });
        it("Error while updating product review", async () => {
            spyOn(userController["userService"], "updateProductReview").and.rejectWith(Promise.reject("Unable to update product review"))
            await expectAsync(userController.updateProductReview(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to update product review")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get a User product review", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                eoId:'eea8cfa3-7ced-4810-bd2b-04ad19589d97',
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Get user product review", async () => {
            spyOn(userController["userService"], "getUserProductReview").and.resolveTo({
                review:"It's soften my skin",
                star:4,
                userImg:'userName.png',
                userName:'Abc Xyz'
            })
            await expectAsync(userController.getUserProductReview(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                review:"It's soften my skin",
                star:4,
                userImg:'userName.png',
                userName:'Abc Xyz'
            })
        });
        it("Error while getting user product review details", async () => {
            spyOn(userController["userService"], "getUserProductReview").and.rejectWith(Promise.reject("Unable to get user product review"))
            await expectAsync(userController.getUserProductReview(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get user product review")
        });
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });

    describe("Get a product reviews", () => {
        beforeAll(() => {
            mockRequest["query"] = {
                uid:'G72JtXPRCuOjYAEwS7X8TazOac33'
            };
        });
        it("Get product review", async () => {
            spyOn(userController["userService"], "getProductReviews").and.resolveTo({
                eoId:'0cf1fbba-d971-448a-a82b-ef4a8e67a96b',
                limit:10,
                offset:0,
                length:0
            })
            await expectAsync(userController.getProductReviews(mockServer,mockRequest,mockReply)).toBeResolvedTo({
                eoId:'0cf1fbba-d971-448a-a82b-ef4a8e67a96b',
                limit:10,
                offset:0,
                length:0
            })
        });
        it("Error while getting product review", async () => {
            spyOn(userController["userService"], "getProductReviews").and.rejectWith(Promise.reject("Unable to get product review details"));
            await expectAsync(userController.getProductReviews(mockServer,mockRequest,mockReply)).toBeRejectedWith("Unable to get product review details");
        }); 
        afterAll(() => {
            mockRequest["params"] = {};
            mockRequest["query"] = {};
            mockRequest["body"] = {};
        });
    });
});